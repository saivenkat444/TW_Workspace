// function occurences(pickedCards, target) {
//   let count = 0;
//   for (let index = 0; index < pickedCards.length; index++){
//     if (pickedCards[index] === target) {
//       count = count + 1;
//     }
//   }

//   return "" + count;
// }

// function countTheCards(pickedCards) {
//   const taco = occurences(pickedCards, "1");
//   const god = occurences(pickedCards, "2");
//   const caterMelon = occurences(pickedCards, "4");
//   const hairyPotato = occurences(pickedCards, "5");
//   const rainbow = occurences(pickedCards, "6");

//   return taco + god + caterMelon + hairyPotato + rainbow;
// }

// console.log(countTheCards("12234256"));


// //13111

function sliceIfInRange(text , currentIndex, endIndex) {
  if (currentIndex > endIndex) {
    return ""; 
  }

  return text[currentIndex] + slice(text, currentIndex + 1, endIndex);
}

function slice(text, start, end) {
  const startIndex = start < 0 ? 0 : start;
  const endIndex = text.length <= end ? text.length - 1 : end;

  return sliceIfInRange(text, startIndex, endIndex);
}

let result = slice ("122345", -2, 1) + slice("122345", 3, 5);
console.log(result);