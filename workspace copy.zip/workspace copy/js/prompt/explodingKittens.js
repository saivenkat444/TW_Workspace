function action(cardPicked) {
  if (cardPicked === 0) {
    if (confirm("Use the diffuse if there are any?")) {
      return 0;
    }
  }
  return 1;
}

function displayPickedCard(card) {
  if (card === 3) {
    console.log("\nOH NOOO..... you picked a BOMB CARD 💣💣💣💥💥💥\n");
    return action(0);
  }

  switch (card) {
    case 1 :
      console.log("\nLUCKY FELLOW you picked TACOCAT 🌮🌮\n");
      break;
    case 2 :
      console.log("\nLUCKY FELLOW you picked GODCAT 🐱🐱\n");
      break;
    case 4 :
      console.log("\nLUCKY FELLOW you picked CATERMELON 🍉🍉\n");
      break;
    case 5 :
      console.log("\nLUCKY FELLOW you picked HAIRY POTATOCAT 🥔🥔\n");
      break;
    case 6 :
      console.log("\nLUCKY FELLOW you picked RAINBOWCAT 🌈🌈\n");
      break;
  }

  return action(card);
}

function isBombExploded(card, ndif, cardsPicked) {
  if (player === 1){}
    if (card <= 0) {
      if (ndif - 1 < 0 || card < 0) {
        return "GAME OVER\nplayer unable to diffuse so kitten died";
      }
    return explodingKittens(ndif - 1, cardsPicked);
  }
  return explodingKittens(ndif, cardsPicked);
}

function occurences(pickedCards, target) {
  let count = 0;
  for (let index = 0; index < pickedCards.length; index++){
    if (pickedCards[index] === target) {
      count = count + 1;
    }
  }

  return "" + count;
}

function countTheCards(pickedCards, useDefuse) {
  const taco = occurences(pickedCards, "1");
  const god = occurences(pickedCards, "2");
  const caterMelon = occurences(pickedCards, "4");
  const hairyPotato = occurences(pickedCards, "5");
  const rainbow = occurences(pickedCards, "6");

  return taco + god + caterMelon + hairyPotato + rainbow;
}

function explodingKittens(ndif, pickedCards) {
  const nCards = countTheCards(pickedCards);
  console.log("______________________________________________________________");
  let message = player1 + " HAVE DIFFUSE : " + ndif;
  message = message + " TACOCAT 🌮 : " + nCards[0];
  message = message + " GODCAT 🐱 : " + nCards[1];
  message = message + " CATERMELON 🍉 : " + nCards[2];
  message = message + " HAIRY POTATOCAT 🥔 : " + nCards[3];
  message = message + " RAINBOWCAT 🌈 : " + nCards[4];
  console.log(message);
  
  if (prompt("pick next card", "✅") === "✅") {
    let card = Math.ceil((Math.random() * 10) % 6);
    const cardsPicked = pickedCards + ("" + card);
    return cardsPicked;
    // let lastCard = displayPickedCard(card);
    // return isBombExploded(card, player1, ndif, cardsPicked);
  }
}

const player1 = prompt("enter player 1 name : ");
const player2 = prompt("enter player 2 name :");

function play(cardsPicked, card) {
  // let lastCard = displayPickedCard(card);
  // isBombExploded(card, ndif, cardsPicked);
  let player1Cards = "30000";
  let player2Cards = "30000";

  let player1Diffuse = 1;
  let player2Diffuse = 1;

  while (player1Cards !== "0" || player2Cards !== "0") {
    const cardPickedBy1 = explodingKittens(player1Diffuse, player1Cards);
    isBombExploded(card, )
    const cardsPickedBy2 = explodingKittens(player2Diffuse, player2Cards);



  }
}

explodingKittens(player1, 1, "30000");
explodingKittens(player2, 1, "30000");
// console.log(explodingKittensPlayer1(prompt("enter player 1 name:"), 1 , "30000"));