const mul = (num1, num2) => num1 * num2;
const add = (num1, num2) => num1 + num2;

const performMul = (functionCall) => {
  const numbers = functionCall.match(/\d+/g);

  return mul(+numbers[0], +numbers[1]);
};

export const part1 = (memory) => {
  const allMulFunctions = memory.match(/mul\(\d{1,3},\d{1,3}\)/g);

  if (!allMulFunctions) return 0;

  const resultOfMuls = allMulFunctions.map(performMul);

  return resultOfMuls.reduce(add, 0);
};

export const part2 = (memory) => {
  // const allDos = memory.match(/(^|do\(\)|\n).*?(don\'t\(\)|$)/g);
  const allDos = memory.match(/(^|do\(\)).*?(don\'t\(\)|$)/gm);
  return allDos.map(part1).reduce(add, 0);
  // const resultsOfValids = allDos.map((string) => part1(string));
  // return resultsOfValids.reduce(add, 0);
};
