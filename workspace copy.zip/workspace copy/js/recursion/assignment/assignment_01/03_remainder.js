function remainder(dividend, divisor) {
  if (dividend < divisor) {
    return dividend;
  }

  return remainder(dividend - divisor, divisor);
}

function makeMessage(dividend, divisor, expected, actual) {
  let message = "the dividend is " + dividend;

  message = message + " the divisor is " + divisor;
  message = message + " expected to be " + expected;
  message = message + " and it is " + actual;

  return message;
}

function testRemainder(dividend, divisor, expected) {
  const actual = remainder(dividend, divisor);
  const getMark  = actual === expected ? '✅' : '❌';
  
  console.log(getMark + makeMessage(dividend, divisor, expected, actual));
}

function testAll() {
  testRemainder(2, 1, 0);
  testRemainder(2, 3, 2);
  testRemainder(0, 2, 0);
  testRemainder(11, 2, 1);
  testRemainder(2, 2, 0);
  testRemainder(15, 5, 0);
  testRemainder(225, 15, 0);
}

testAll();