import { fetchContent } from "./fetch_content.js";
// export const tail = (count, filePath, separator) => {
//   try {
//     const lastTenLines = readFile(filePath, separator).slice(0 - count);
//     return lastTenLines.join(separator);
//   } catch (errorMSG) {
//     return `tail: ${errorMSG}`;
//   }
// };

export const tail = (parsedArgs) => {
  if (parsedArgs.isError) {
    return [parsedArgs];
  }

  const { filepaths, option, count } = parsedArgs;

  const contents = filepaths.map((filePath) =>
    fetchContent(option, count, filePath, false)
  );

  return contents;
};
