export const peoplesData = [
  {
    name: "Rahul",
    age: 45,
    employment: { isEmployed: true, profession: "software Engineer" },
    city: "Pune",
    hobbies: [
      { hobby: "gardening", specification: [""] },
      { hobby: "game", specification: ["chess"] },
    ],
    vehicle: [{ type: "car", usage: "going for trips in the weekends" }],
    degreesOwned: ["computer science"],

    pets: [
      {
        name: "Max",
        type: "Dog",
        breed: "golden retriever",
        age: 4,
        isVaccinated: true,
        activities: ["playing fetch in the park"],
      },
    ],
  },

  {
    name: "Ananya",
    age: 30,
    employment: { isEmployed: false, profession: "" },
    city: "Bangalore",
    hobbies: [
      {
        hobby: "cooking",
        specification: ["often experiments with Italian recipes"],
      },
    ],
    vehicle: [{}],
    degreesOwned: ["computer science", "graphic design"],
    pets: [
      {
        type: "Parrot",
        name: "Kiwi",
        breed: "",
        age: 0,
        isVaccinated: true,
        activities: ["knows over 20 phrases", "mimics her voice"],
      },
    ],
  },

  {
    name: "Ramesh",
    age: 45,
    employment: { isEmployed: true, profession: "business Owner" },
    city: "Jaipur",
    hobbies: [
      { hobby: "gardening", specification: ["tending at rose garden"] },
      { hobby: "reading", specification: ["historical fiction"] },
    ],
    vehicle: [{}],
    degreesOwned: ["computer science", "graphic design"],
    pets: [
      {
        type: "cat",
        name: "Bella",
        breed: "Persian",
        age: 3,
        isVaccinated: true,
        activities: ["lounging in the sun"],
      },
      {
        type: "cat",
        name: "Leo",
        breed: "",
        age: 3,
        isVaccinated: true,
        activities: ["lounging in the sun"],
      },
    ],
  },

  {
    name: "Kavya",
    age: 28,
    employment: { isEmployed: false, profession: "professional dancer" },
    city: "Chennai",
    hobbies: [
      { hobby: "reading", specification: ["fantasy Novels"] },
      { hobby: "binge-watching sci-fi shows", specification: [""] },
    ],
    vehicle: [{}],
    degreesOwned: [""],
    pets: [
      {
        type: "rescue rabbit",
        name: "snowy",
        breed: "",
        age: 2,
        isVaccinated: true,
        activities: ["hopping around her backyard", "nibbling on carrots"],
      },
    ],
  },
];
