import { assertEquals } from "jsr:@std/assert";
import {
  errorMessagesFormats,
  fileContent,
  invalidCount,
  invalidFile,
  invalidOption,
} from "../src/print.js";
import { describe, it } from "jsr:@std/testing/bdd";

describe("invalidCount(token, segementType) for head", () => {
  it("should give error message when the token is a number", () => {
    const actual = invalidCount(0, "head");
    const expected = `head: illegal line count -- 0`;
    assertEquals(actual, expected);
  });
  it("should give error message when the token is a string", () => {
    const actual = invalidCount("something", "head");
    const expected = `head: illegal line count -- something`;
    assertEquals(actual, expected);
  });
});

describe("invalidFile(token, segmentType) for head", () => {
  it("should give error message when the token is a number", () => {
    const actual = invalidFile(0, "head");
    const expected = "head: 0 no such file or directory";
    assertEquals(actual, expected);
  });
  it("should give error message when the token is a string", () => {
    const actual = invalidFile("something.js", "head");
    const expected = "head: something.js no such file or directory";
    assertEquals(actual, expected);
  });
});

describe("invalidOption(token, segmenentType) for head", () => {
  it("should give error message when the token is a number", () => {
    const actual = invalidOption(0, "head");
    const expected =
      "head: invalid option -- 0\nusage: head [-n lines | -c bytes] [file ...]";
    assertEquals(actual, expected);
  });
  it("should give error message when the token is a string", () => {
    const actual = invalidOption("something", "head");
    const expected =
      "head: invalid option -- something\nusage: head [-n lines | -c bytes] [file ...]";
    assertEquals(actual, expected);
  });
});

describe("invalidCount(token, segmentType) for tail", () => {
  it("should give error message when the token is a number", () => {
    const actual = invalidCount(0, "tail");
    const expected = `tail: illegal line count -- 0`;
    assertEquals(actual, expected);
  });
  it("should give error message when the token is a string", () => {
    const actual = invalidCount("something", "tail");
    const expected = `tail: illegal line count -- something`;
    assertEquals(actual, expected);
  });
});

describe("invalidFile(token, segementType) for tail", () => {
  it("should give error message when the token is a number", () => {
    const actual = invalidFile(0, "tail");
    const expected = "tail: 0 no such file or directory";
    assertEquals(actual, expected);
  });
  it("should give error message when the token is a string", () => {
    const actual = invalidFile("something.js", "tail");
    const expected = "tail: something.js no such file or directory";
    assertEquals(actual, expected);
  });
});

describe("invalidOption(token, segementType) for tail", () => {
  it("should give error message when the token is a number", () => {
    const actual = invalidOption(0, "tail");
    const expected =
      "tail: invalid option -- 0\nusage: tail [-n lines | -c bytes] [file ...]";
    assertEquals(actual, expected);
  });
  it("should give error message when the token is a string", () => {
    const actual = invalidOption("something", "tail");
    const expected =
      "tail: invalid option -- something\nusage: tail [-n lines | -c bytes] [file ...]";
    assertEquals(actual, expected);
  });
});

describe("errorMessagesFormat(type, token) for head", () => {
  it("should give the error format for invalid option", () => {
    const actual = errorMessagesFormats(
      {
        type: "invalid option",
        token: "something",
      },
      "head"
    );
    const expected =
      "head: invalid option -- something\nusage: head [-n lines | -c bytes] [file ...]";
    assertEquals(actual, expected);
  });
  it("should give the error format for invalid File", () => {
    const actual = errorMessagesFormats(
      {
        type: "invalid file",
        token: "something.js",
      },
      "head"
    );
    const expected = "head: something.js no such file or directory";
    assertEquals(actual, expected);
  });
  it("should give the error format for invalid count", () => {
    const actual = errorMessagesFormats(
      {
        type: "invalid count",
        token: "something",
      },
      "head"
    );
    const expected = "head: illegal line count -- something";
    assertEquals(actual, expected);
  });
});

describe("errorMessagesFormat(type, token) for tail", () => {
  it("should give the error format for invalid option", () => {
    const actual = errorMessagesFormats(
      {
        type: "invalid option",
        token: "something",
      },
      "tail"
    );
    const expected =
      "tail: invalid option -- something\nusage: tail [-n lines | -c bytes] [file ...]";
    assertEquals(actual, expected);
  });
  it("should give the error format for invalid File", () => {
    const actual = errorMessagesFormats(
      {
        type: "invalid file",
        token: "something.js",
      },
      "tail"
    );
    const expected = "tail: something.js no such file or directory";
    assertEquals(actual, expected);
  });
  it("should give the error format for invalid count", () => {
    const actual = errorMessagesFormats(
      {
        type: "invalid count",
        token: "something",
      },
      "tail"
    );
    const expected = "tail: illegal line count -- something";
    assertEquals(actual, expected);
  });
});

describe("fileContent({filecontent})", () => {
  const actual = fileContent({
    fileName: "something.js",
    content: "there is something",
  });
  const expected = `==>something.js<==
there is something`;
  assertEquals(actual, expected);
});
