const array = [103, 101, 102];

const maxOf2 = function ([num1, num2]) {
  if (num1 > num2) {
    return [num1, num2];
  }

  return [num2, num1];
}

const maximum = function ([num1, num2], element) {
  if (num2 > element) {
    return [num1, num2];
  }

  if (num1 > element) {
    return [num1, element];
  }

  return [element, num1];
}

const find2ndHighest = function (array) {
  const initialValue = maxOf2(array[0], array[1]);
  const maximumArray = array.reduce(maximum, initialValue);

  return maximumArray[1];
}

console.log(find2ndHighest(array));