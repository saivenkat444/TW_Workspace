const player1 = prompt("enter the player1 name :");
const player2 = prompt("enter the player2 name :");

function addition(num1, num2) {
  return num1 + num2
}

function getNumber() {
  return +prompt("Enter the number: ");
}

function play() {
  let player1Score = 0;
  let player2Score = 0;

  for (let times = 1; times < 6; times++) {
  const player1Num = getNumber();
  const player2Num = getNumber();

  player1Score = addition(player1Score, player1Num);
  player2Score = addition(player2Score, player2Num);
  }

  if (player1Score > player2Score) {
    return "player1 won"
  }

  return "player2 won";
}

console.log(play());
//