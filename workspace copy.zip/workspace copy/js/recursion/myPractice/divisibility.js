function divisibility(dividend, divisor) {
  if (dividend < divisor || divisor === 0) {
    return dividend === 0;
  }

  return divisibility(dividend - divisor, divisor);
}

console.log(divisibility(4, 2));
console.log(divisibility(3, 2));
console.log(divisibility(2, 3));
console.log(divisibility(4, 0));
console.log(divisibility(0, 4));
console.log(divisibility(2, 2));
console.log(divisibility(0, 0));