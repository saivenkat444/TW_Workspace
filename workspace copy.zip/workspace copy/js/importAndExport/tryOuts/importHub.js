import { incrementBy10 } from "./concat.js";

console.log(incrementBy10(2));
// const anothernumber = 5;
console.log();
// console.log(test);
// console.log(test);
// console.log(test);
