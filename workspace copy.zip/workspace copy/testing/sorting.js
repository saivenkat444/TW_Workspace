const array = [1, 63, 9,22, 42, 0];

array.sort(function(a, b) {
  console.log(a, b, array)
  return -1;
}); 

console.log(array);


1 -1 2 -2
-1 1 2 -2
-1 2 1 -2
2 -1 1 -2
2 -1 -2 1
2 -2 -1 1
-2 2 -1 1

1 -1 2 -2 a > b return 1
-1 1 2 -2
-1 2 1 -2
2 -1 1 -2
2 -1 -2 1
2 -2 -1 1
