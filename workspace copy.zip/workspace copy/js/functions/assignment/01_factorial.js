/*
  Implement the below function to calculate the factorial of `number`.
  Examples:
    factorial(3) => 6
    factorial(5) => 120
    factorial(0) => 1

  *Your function must return a value*

  It's not necessary to print the result on screen, 
  however to test your function you are free to print the result
*/

function factorial(number) {
  let factorialResult = 1;

  for (let multiplyWith = 2; multiplyWith <= number; multiplyWith++) {
    factorialResult = factorialResult * multiplyWith;
  }

  return factorialResult;
}


function message(number, expect, evaluatingTo) {
  const isPassing = evaluatingTo === expect ? "✅" : "❌";
  const context = " factorial of " + number;
  const expected = " should be " + expect;
  const actual = " but it is " + evaluatingTo;
  
  return isPassing + context + expected + actual;
}

function testFactorial(number, expect) {
  const evaluatingTo = factorial(number);
  console.log(message(number, expect, evaluatingTo));
}

function testCases() {
  testFactorial(0, 1);
  testFactorial(1, 1);
  testFactorial(2, 2);
  testFactorial(4, 24);
  testFactorial(3, 6);
}

testCases();