import { describe, it } from "jsr:@std/testing/bdd";
import { assertEquals } from "jsr:@std/assert";

class something {
  constructor() {
    this.somehting = "something";
  }
}

class Reactangle {
  constructor(width, length) {
    this.width = width; //should we call them properties as they are required data or they are possessed by our thing
    this.length = length;
  }

  area() {
    return this.width * this.length;
  }

  perimeter() {
    return 2 * (this.width + this.length);
  }

  different() {
    return new something;
  }
}

describe("verifying whether we can test", () => {
  it("should test area", () => {
    const template = new Reactangle(20, 10);//should we mock new or the class just leave it like that but leaving it like that doesnot make sense

    //does it know whether it is called from the class???
    //opinion : when there is something from the class then only its method can be called will you call array methods for strings?????
    const actual = template.area();
    const expected = 200;
    assertEquals(actual, expected);
  });
});

const r1 = new Reactangle(3, 4);
const area1 = r1.area();
const r2 = new Reactangle(4, 3);
const area2 = r2.area();
console.log(r1, r2, area1, area2);
console.log(r1, r2);
const per1 = r1.perimeter();
const per2 = r2.perimeter();
console.log(per1, per2);
console.log()