import { Ratio } from "../src/ratio.js";
import { describe, it } from "jsr:@std/testing/bdd";
import { assertEquals } from "jsr:@std/assert";

describe("toString() will give the in a fraction format ", () => {
  it("should give num/den, when both numerator and denominator are positive", () => {
    const sampleValue = new Ratio(2, 3);
    const actual = sampleValue.toString();
    const expected = `2/3`;
    assertEquals(actual, expected);
  });
  it("should give num/den, when numerator is negative", () => {
    const sampleValue = new Ratio(-2, 3);
    const actual = sampleValue.toString();
    const expected = `-2/3`;
    assertEquals(actual, expected);
  });
  it("should give num/den, when denominator is negative", () => {
    const sampleValue = new Ratio(2, -3);
    const actual = sampleValue.toString();
    const expected = `2/-3`;
    assertEquals(actual, expected);
  });
  it("should give num/den, when both numerator and denominator are negative", () => {
    const sampleValue = new Ratio(-2, -3);
    const actual = sampleValue.toString();
    const expected = `-2/-3`;
    assertEquals(actual, expected);
  });
});
describe("add(ratio) will give me the addition of ratios", () => {
  it("should give new instance when, both addends are positive ratios", () => {
    const sample = new Ratio(1, 2);
    const anotherSample = new Ratio(1, 3);
    const actual = sample.add(anotherSample);
    const expected = new Ratio(5, 6);
    assertEquals(actual, expected);
  });
  it("should give new instance when, second addend is a negative ratio", () => {
    const sample = new Ratio(1, 2);
    const anotherSample = new Ratio(-1, 3);
    const actual = sample.add(anotherSample);
    const expected = new Ratio(1, 6);
    assertEquals(actual, expected);
  });
  it("should give new instance when, first addend is a negative ratio", () => {
    const sample = new Ratio(-1, 2);
    const anotherSample = new Ratio(1, 3);
    const actual = sample.add(anotherSample);
    const expected = new Ratio(-1, 6);
    assertEquals(actual, expected);
  });
  it("should give new instance when, both addends are negative ratios", () => {
    const sample = new Ratio(-1, 2);
    const anotherSample = new Ratio(-1, 3);
    const actual = sample.add(anotherSample);
    const expected = new Ratio(-5, 6);
    assertEquals(actual, expected);
  });
});
