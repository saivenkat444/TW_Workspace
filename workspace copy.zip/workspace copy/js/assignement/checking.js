const a = [];
while (true) {
  a.push(2);
  console.log(a.lastIndexOf(2));
}