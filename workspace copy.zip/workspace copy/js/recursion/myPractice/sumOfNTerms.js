function sum(number) {
  if (number === 0) {
    return 0;
  }
  return number + sum(number - 1);
}

console.log(sum(0));
console.log(sum(1));
console.log(sum(2));
console.log(sum(3));
console.log(sum(4));