function addition(number1, number2) {
  if (number1 === 0) {
    return number2;
  }

  return addition(number1 - 1, number2 + 1);
}

console.log(addition(0, 0));
console.log(addition(1, 1));
console.log(addition(0, 2));
console.log(addition(2, 0));
console.log(addition(928, 976));
console.log(addition(8, 6));