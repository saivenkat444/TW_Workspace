const a = new Promise((resolve) => {
  setTimeout(() => {
    resolve(2);
  }, 1000);
});

const b = new Promise((resolve) => {
  setTimeout(() => {
    resolve(3);
  }, 1000);
});

const c = Promise.all([a, b]);
console.log(c);
