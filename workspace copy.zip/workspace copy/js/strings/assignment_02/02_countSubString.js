// Do not rename string, use it as input for your program.
// While testing we will change it's value.
const string = " ";
const subString = "";
// Print the count of occurences of a substring in the given string
// If string = "duplicate substring statement" and subString = "ate", then print 2
// START YOUR CODE AFTER THIS LINE. DO NOT REMOVE THIS LINE

let countOfSubString = 0;

const indexOfString = subString.length === 0 ? string.length : 0;

for (let stringIndex = indexOfString; stringIndex < string.length; stringIndex++) {
    let checkString = "";

    for (let subStringIndex = 0; subStringIndex < subString.length; subStringIndex++) {
        let indexOfCheck = stringIndex;
        checkString = checkString + string[indexOfCheck];
        indexOfCheck = indexOfCheck + 1;
    }

    if (checkString === subString) {
        countOfSubString = countOfSubString + 1;
    }

}

console.log(countOfSubString);