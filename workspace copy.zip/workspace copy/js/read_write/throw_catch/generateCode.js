import testCases from "./template.json" with {type: "json"};

// const giveParameters = (args) => args.join(", ");

const extractTest = (testCase) => `test("${testCase.type}", () => assertEquals(${testCase.function}(${testCase.args}), ${testCase.expected}))`

const prepareCode = (groupType, group) => {
  return `describe("${groupType}", () => {
  ${group.map(extractTest).join("\n")};
  }
)`
}

const main = () => {
  const typesOfGroups = Object.keys(testCases.groups);
  const code = `${testCases.import}
  ${typesOfGroups.map((group) => prepareCode(group, testCases.groups[group]))}`;
  Deno.writeTextFileSync("./double_test.js", code);
}
main();
// describe("add function", () => {
  // it("adds two numbers correctly", () => {