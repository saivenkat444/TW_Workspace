let num=0
let armstrong=0
let lastdigit=0

while(num>0) {
lastdigit=num%10
    armstrong= armstrong+(lastdigit*lastdigit*lastdigit);
    num=(num-lastdigit)/10;
}
console.log(armstrong)
