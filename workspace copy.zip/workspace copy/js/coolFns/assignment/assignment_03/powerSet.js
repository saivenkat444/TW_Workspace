function clone(array) {
  const copyOfArray = [];

  for (let index = 0; index < array.length; index++) {
    copyOfArray.push(array[index]);
  }

  return copyOfArray;
}

function concat(array1, array2) {
  const concatenated = clone(array1);

  for (let index = 0; index < array2.length; index++) {
    concatenated.push(array2[index]);
  }

  return concatenated;
}

function elementsFromIndex(arr, terms, index) {
  const set = [];
  let arrIndex = index;

  if (index + terms > arr.length) {
    return set;
  }

  for (let time = terms; time > 0; time--) {
    set.push(arr[arrIndex]);
    arrIndex = arrIndex + 1;
  }

  return set;
}


function sliceTheSet(arr, terms, startIndex) {
  let array = [];
  
  for (let index = startIndex; index < (arr.length); index++) {
    // array = concat(array, elementsFromIndex(arr, terms, index));
    array.push(elementsFromIndex(arr, terms, index));

  }
  return array;
}


function getSubSet(arr, terms, powerSet) {
  let subset = clone(powerSet);

  if (terms >= arr.length) {
    return subset;
  }

  for (let index = 0; index < arr.length; index++) {
    subset = concat(subset, sliceTheSet(arr, terms, index));
  }

  return getSubSet(arr, terms + 1, subset)
}

function generatePowerSet(arr) {
  let termsInSubset = 1;
  const subset = getSubSet(arr, termsInSubset, [[], arr]);
  
  return subset;
}

// function makeMessage(array1, expected, actual) {
//   let message = "the array: '" + array1;

//   message = message + "' are '" + expected;
//   message = message + "' and it is '" + actual + "'";

//   return message;
// }

// function testGeneratePowerSet(array, expected) {
//   const actual = generatePowerSet(array);
//   const getMark = areEqual(actual, expected) ? '✅' : '❌';

//   console.log(getMark + makeMessage(array, expected, actual));
// }

// function testAll() {
//   testGeneratePowerSet();
// //   testGeneratePowerSet([], [], []);
// //   testGeneratePowerSet([1], [], [1]);
// //   testGeneratePowerSet([], [1], [1]);
// //   testGeneratePowerSet([1], [1], [1, 1]);
// }

// // testAll();

console.log(generatePowerSet([1, 2]));