// 1st program
// const addition = function (num1) {
//   return function (num2) {
//     return num1 + num2;
//   }
// }

// const addWith2 = addition(2);

//_____________________________________________________________________________
// 2nd program
const addition = function (step) {
    let oldStep = step;
  
    return function (number) {
        return (oldStep++) + number;
      }
    }
    
    const increment = addition(5);
    
    // console.log(increment(9));
    
//____________________________________________________________________________

const people = ["ram saran", "sai venkat", "pavani", "ankita", "sujoy"];
const appication = ["insta", "shadow fight", "candy crush", "whatsapp"];

const nextApp = function (appication) {
  let i = -1;

  return function (people) {
    i ++;

    if (i > appication.length - 1) {
      i = 0;
    }

    return appication[i] + " " + people; 
  }
}

const application = nextApp(appication);

console.log(people.map(application));