// function addElements(array, index, number) {
//   if (confirm("do you want to add someting in " + number)) {
//     array[index] = prompt("enter the something");
//     return addElements(array, index + 1, number);
//   }
//   return array;
// }

// const array1 = addElements([], 0, 1);
// const array2 = addElements([], 0, 2);

// console.log(array1 + array2);

const array1 = [1,2,3];
const array2 = [4,5,6];

function add(index) {
  if (index >= array2.length) {
    return array1;
  }
  array1[array1.length] = array2[index];
  return add(index + 1);
}

console.log(add(0));