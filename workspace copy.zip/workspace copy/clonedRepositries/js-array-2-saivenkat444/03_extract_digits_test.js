import * as Assertion from "jsr:@std/assert";
import { extractDigits } from "./03_extract_digits.js";

Deno.test("postive Number extractiob of digits", () =>
  Assertion.assertEquals(extractDigits(123), [1, 2, 3])
);
Deno.test("negative Number extractiob of digits", () =>
  Assertion.assertEquals(extractDigits(-123), [1, 2, 3])
);
Deno.test("repeated digits in the number", () =>
  Assertion.assertEquals(extractDigits(1020), [1, 0, 2, 0])
);
Deno.test("single digit", () =>
  Assertion.assertEquals(extractDigits(0), [0])
);
