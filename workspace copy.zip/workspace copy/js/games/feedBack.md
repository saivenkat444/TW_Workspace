- write range of and map and remo   ve for loop
- distribute cards -> players names, map and object
map the player names as keys and their cards

-> not removing cards when bomb is used