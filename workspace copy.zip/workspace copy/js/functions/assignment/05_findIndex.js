/*
  Implement the below function to find the first index of a character
  Return -1 if the target character is absent 

  Examples:
    findIndex('hello world', 'o') => 4
    findIndex('repeating iiiiiiii', 'i') => 6
    findIndex('not found', 'z') => -1

  **Your function must return a value**

  It's not necessary to print the result on screen, 
  however to test your function you are free to print the result
*/

function findIndex(text, target) {
  for (let index = 0; index < text.length; index++) {
    if (text[index] === target) {
      return index;
    }
  }

  return -1;
}

function message(text, expect, evaluatingTo) {
  const isPassing = evaluatingTo === expect ? "✅" : "❌";

  const context = " Index of " + text;
  const expected = " string " + expect;
  const actual = " is " + evaluatingTo;

  return isPassing + context + expected + actual;
}

function testFIndIndex(text, target, expect) {
  const evaluatingTo = findIndex(text, target);
  console.log(message(text, expect, evaluatingTo));
}

function testCases() {
  testFIndIndex("hello world", "l", 2);
  testFIndIndex("hello world ", "d", 10);
  testFIndIndex("hello world", "", -1);
  testFIndIndex("hello world", " ", 5);
  testFIndIndex("hello world", "z", -1);
}

testCases();