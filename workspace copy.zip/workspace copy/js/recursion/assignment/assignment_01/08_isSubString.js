function sliceSubStirng(string, index, subLength) {
  if (subLength === 0) {
    return "";
  }
  
  return string[index] + sliceSubStirng(string, index + 1, subLength - 1);
}

function isSubStringFound(string, otherString, index) {
  if (index === string.length) {
    return false; 
  }
  
  const subStringCandidate = sliceSubStirng (string, index, otherString.length);

  if (subStringCandidate === otherString) {
    return true;
  }

  return isSubStringFound(string, otherString, index + 1);
}

function isSubString(string, otherString) {
  if (string === "" || otherString === "") {
    return false;
  }

  return isSubStringFound(string, otherString, 0);
}

function makeMessage(otherString, expected, actual) {
  let message = "the string " + otherString;
  
  message = message + " expected to be " + expected;
  message = message + " and it is " + actual;

  return message;
}

function testIsSubString(string, otherString, expected) {
  const actual = isSubString(string, otherString, 0);
  const getMark  = actual === expected ? '✅' : '❌';
  
  console.log(getMark + makeMessage(otherString, expected, actual));
}

function testAll() {
  testIsSubString("MOM", "MO", true);
  testIsSubString("hello world", "ld", true);
  testIsSubString("hello world", "zzzz", false);
  testIsSubString("MOM", "", false);
  testIsSubString("MOM", " ", false);
  testIsSubString("MOM", "MOM", true);
  testIsSubString(" ", " ", true);
  testIsSubString("      ", " ", true);
  testIsSubString("hello", "hello world", false);
}

testAll();