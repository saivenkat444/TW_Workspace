const commonLoopForAllElements = function (array, operation) {
  const resultantArray = [];

  for (let index = 0; index < array.length; index++) {
    resultantArray.push(operation(array[index]));
  }

  return resultantArray;
}

const getSquareRoot = function (number) {
  return Math.sqrt(number);
}

const getHalf = function (number) {
  return number / 2;
}

const changeToUpperCase = function (string) {
  return string.toUpperCase();
}

const commonLoopToFilterElements = function (array, operation) {
  const resultantArray = [];

  for (let index = 0; index < array.length; index++) {
    if (operation(array[index])) {
      resultantArray.push(array[index]);
    }
  }

  return resultantArray;
}

const isOdd = function (number) {
  return (number & 1) === 1;
}

const isMoreThan5char = function (string) {
  return string.length > 5;
}

const commonLoopToGetAllElements = function (array, operation, result) {
  let resultantValue = result;

  for (let index = 0; index < array.length; index++) {
    resultantValue = operation(resultantValue, array[index]);
  } 

  return resultantValue;
}

const isLarger = function (candidate, longestElement) {
  if (candidate.length > longestElement.length) {
    return candidate;
  }

  return longestElement;
}

const concatStrings = function (string1, string2) {
  return string1 + string2;
}

const multiply = function (multiplicand, multiplier) {
  return multiplier * multiplicand;
}

const countOdd = function (count, number) {
  if (isOdd(number)) {
    return count + 1;
  }

  return count;
}

const getSquareRootForAll = function (array) {
  return commonLoopForAllElements(array, getSquareRoot);
}

const getHalfOfEveryElement = function (array) {
  return commonLoopForAllElements(array, getHalf);
}

const getUpperCaseForAll = function (array) {
  return commonLoopForAllElements(array, changeToUpperCase);
}

const getOddNumbersInTheArray = function (array) {
  return commonLoopToFilterElements(array, isOdd);
}

const getMoreThan5Char = function (array) {
  return commonLoopToFilterElements(array, isMoreThan5char);
}

const getlongestElement = function (array) {
  return (commonLoopToGetAllElements(array, isLarger, ""));
}

const getArrayIntoString = function (array) {
  return commonLoopToGetAllElements(array, concatStrings, "");  
}

const getProductOfElements = function (array){
  return commonLoopToGetAllElements(array, multiply, 1);
}

const getCountOdds = function (array) {
  return commonLoopToGetAllElements(array, countOdd, 0);
}

const array1 = [1, 4, 9, 16];
const array2 = [1, 2, 3, 4];
const array3 = ["hi", "possible"];
const array4 = ["ab","so","lu","te"];
const array5 = ["this","amazing", "assignment", "rocks"];

console.log(getSquareRootForAll(array1));
console.log(getOddNumbersInTheArray(array1));
console.log(getHalfOfEveryElement(array2));
console.log(getMoreThan5Char(array3));
console.log(getUpperCaseForAll(array3));
console.log(getlongestElement(array5));
console.log(getArrayIntoString(array4));
console.log(getProductOfElements(array2));
console.log(getCountOdds(array2));