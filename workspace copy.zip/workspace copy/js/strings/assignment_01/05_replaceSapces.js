// Do not rename string, use it as input for your program.
// While testing we will change it's value.
const string = " ";
// Replace all spaces with underscore "_"
// If string = "statement with spaces"
// Then print "statement_with_spaces"
// START YOUR CODE AFTER THIS LINE. DO NOT REMOVE THIS LINE

let replacedString = "";
const UNDERSCORE = "_";
const SPACE = " ";

for (let index = 0; index < string.length; index++) {
    const nextcharachter = (string[index] === SPACE) ? UNDERSCORE : string[index]
    replacedString = replacedString + nextcharachter;
}

console.log(replacedString);