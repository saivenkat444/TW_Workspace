const performAddition = function (x, y) {
  return x + y;
}

const performSubtraction = function (x, y) {
  return x - y;
}

const performMultiplication = function (x, y) {
  return x * y;
}

const performDivision = function (x, y) {
  return x / y;
}

const giveSquareRoot = function (x) {
  return Math.sqrt(x);
}

const giveAbsoluteValue = function (x) {
  return Math.abs(x);
}

const performRoundOffTillDecimlas = function (number, decimalDigits) {
  const num = Math.round(number * Math.pow(10, decimalDigits));

  return num / Math.pow(10, decimalDigits);
}

const convertDegreesToRadiants = function (degrees) {
  const radiants = degrees * (Math.PI / 180);

  return (performRoundOffTillDecimlas(radiants, 4));
}

const performSine = function (degrees) {
  const sin = Math.sin(convertDegreesToRadiants(degrees));

  return performRoundOffTillDecimlas(sin, 5);
}

const performCosine = function (degrees) {
  const cos = Math.cos(convertDegreesToRadiants(degrees));

  return performRoundOffTillDecimlas(cos, 5);
}

const giveExit = function () {
  return "THANK YOU SEE YOU AGAIN";
}
{
// const performCalculation = function (operation, operand1, operand2) {
//   return operation(operand1, operand2);
// }

// function testPerformCalculation(operation, operand1, failed, expected, operand2) {
//   const actual = performCalculation(operation, operand1, operand2);

//   if (actual !== expected) {
//     failed.push([operation, operand1, operand2, expected, actual]);
//   }
// }

// function getTestResult(failed) {
//   if (failed.length === 0) {
//     return console.log("congratulations");
//   }

//   return console.table(failed);
// }

// function testAll() {
//   const failed = [];
//   testPerformCalculation(add, 2, failed, 3, 1);
//   testPerformCalculation(sub, 2, failed, 1, 1);
//   testPerformCalculation(mul, 2, failed, 2, 1);
//   testPerformCalculation(div, 2, failed, 2, 1);
//   testPerformCalculation(squareRoot, 4, failed, 2);
//   testPerformCalculation(absValue, 2, failed, 2);
//   testPerformCalculation(radiants, 90, failed, 1.5708)
//   testPerformCalculation(sin, 90, failed, 1);
//   testPerformCalculation(sin, 0, failed, 0);
//   testPerformCalculation(sin, 30, failed, 0.5);
//   testPerformCalculation(cos, 90, failed, 0);
//   testPerformCalculation(cos, 0, failed, 1);
//   testPerformCalculation(cos, 60, failed, 0.5);
//   testPerformCalculation(roundOffTillDecimlas, 0.098088, failed, 0.09809, 5)

//   getTestResult(failed);
// }

// testAll(); 

}

const performOperationOfOneInput = function (operation) {
  if (operation > 11) {
    return "ENTER THE CORRECT CHOICE NEXT TIME";
  }

  if (operation === 11) {
    return giveExit();
  }

  const value = +prompt("ENTER THE VALUE :");
  const result = conductAction(operation)(value);
  let resultMessage = ["Result for the operation for value: ", value];
  resultMessage.push(" is ", result);

  return resultMessage;
}

const conductAction = function (operation) {
  const allOperations = [
    [9, performSine],
    [10, performCosine],
    [6, giveSquareRoot],
    [1, performAddition],
    [4, performDivision],
    [7, giveAbsoluteValue],
    [2, performSubtraction],
    [3, performMultiplication],
    [8, convertDegreesToRadiants],
    [5, performRoundOffTillDecimlas],
    ];

  for (let index = 0; index < allOperations.length; index++) {
    if (allOperations[index][0] === operation) {
      return allOperations[index][1];
    }
  }

  return "THANK YOU BYE BYE";
}

const catalogue = function () {
  const menuItems = [
    "(1) Addition",
    "(2) Subtraction",
    "(3) Multiplication",
    "(4) Division",
    "(5) Round Off Till Decimals",
    "(6) square Root",
    "(7) AbsoluteValue",
    "(8) Convert Degree To Radiants",
    "(9) Sin",
    "(10) cos",
    "(11) exit"
  ]

  return (menuItems.join("\n"));
}

const performOperationOfTwoInputs = function(actionSelected) {
  const number1 = +prompt("num1:");
  const number2 = +prompt("num2:");
  const result = conductAction(actionSelected)(number1, number2);
  const resultMessage = ["Result for the operation for number1:", number1];

  resultMessage.push("and number2 :", number2)
  resultMessage.push("is", result)

  return (resultMessage.join(" "));
}

const performCalculator = function() {
  console.clear();
  let actionChosen = +prompt(catalogue());

  if (actionChosen > 4) {
    return performOperationOfOneInput(actionChosen);
  }

  return performOperationOfTwoInputs(actionChosen);
}

console.log(performCalculator());