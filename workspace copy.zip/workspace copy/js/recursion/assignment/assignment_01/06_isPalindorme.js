function reverseOfString(string, index) {
  if (index === string.length) {
    return "";
  }
  
  return reverseOfString(string, index + 1) + string[index];
}

function reverse(string) {
  const reversedString = reverseOfString(string, 0);

  return reversedString === string;
}

function makeMessage(string, expected, actual) {
  let message = "the string " + string;

  message = message + " expected to be " + expected;
  message = message + " and it is " + actual;

  return message;
}

function testIsPalindrome(string, expected) {
  const actual = reverse(string);
  const getMark  = actual === expected ? '✅' : '❌';
  
  console.log(getMark + makeMessage(string, expected, actual));
}

function testAll() {
  testIsPalindrome("1990", false);
  testIsPalindrome("1991", true);
  testIsPalindrome("MOM", true);
  testIsPalindrome("racecar", true);
  testIsPalindrome("hello", false);
  testIsPalindrome("a", true);
  testIsPalindrome("9", true);
  testIsPalindrome("", true);
}

testAll();