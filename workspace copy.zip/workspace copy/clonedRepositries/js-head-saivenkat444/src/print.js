export const invalidFile = (token, sectionType) => {
  return `${sectionType}: ${token} no such file or directory`;
};

export const invalidCount = (token, sectionType) => {
  return `${sectionType}: illegal line count -- ${token}`;
};

export const invalidOption = (token, sectionType) => {
  return `${sectionType}: invalid option -- ${token}
usage: ${sectionType} [-n lines | -c bytes] [file ...]`;
};

export const errorMessagesFormats = ({ type, token }, sectionType) => {
  return {
    "invalid file": invalidFile(token, sectionType),
    "invalid count": invalidCount(token, sectionType),
    "invalid option": invalidOption(token, sectionType),
  }[type];
};

const addHeading = (name) => `==>${name}<==\n`;

export const fileContent = ({ ...fileContent }) => {
  return addHeading(fileContent.fileName) + fileContent.content;
};

export const display = (content, sectionType) => {
  content.forEach((individualContent) => {
    if (individualContent.isError) {
      const errorMessage = errorMessagesFormats(
        individualContent,
        sectionType
      );
      console.error(errorMessage); // console.error()
      return 1;
    } else {
      const message = fileContent(individualContent);
      console.log(message); // console.log()
      return 0;
    }
  }); // should return something
}; // what should display return? should it return something?
