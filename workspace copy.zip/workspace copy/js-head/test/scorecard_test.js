import { getAllDeliveries } from "../src/scorecard.js";
import { assertEquals } from "jsr:@std/assert";

Deno.test("should generate scorecard", () => {
  const sampleData = [];
  const expectedOutput = ``;
  // assertEquals(generateScoreCard(sampleData), expectedOutput);
});
Deno.test(`all are valid deliveries`, () => {
  const sampleData = [
    {
      team: "Kolkata Knight Riders",
      overs: [
        {
          over: 0,
          deliveries: [
            {
              batter: "SC Ganguly",
              bowler: "P Kumar",
              extras: {
                legbyes: 1,
              },
              non_striker: "BB McCullum",
              runs: {
                batter: 0,
                extras: 1,
                total: 1,
              },
            },
          ],
        },
      ],
    },
  ];
  const expectedOutput = [
    [
      {
        batter: "SC Ganguly",
        bowler: "P Kumar",
        extras: {
          legbyes: 1,
        },
        non_striker: "BB McCullum",
        runs: {
          batter: 0,
          extras: 1,
          total: 1,
        },
      },
    ],
  ];
  console.log(getAllDeliveries(sampleData));
  assertEquals(getAllDeliveries(sampleData), expectedOutput);
});
