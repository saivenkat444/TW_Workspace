/*
  Write a function that counts the occurrence of a substring in a string

  Examples:
    occurrences('hello world', 'l') => 3
    occurrences('hello world', 'll') => 1
    occurrences('hello world', 'world') => 1
    occurrences('hello world', 'zebra') => 0

  **Your function must return a value**

  It's not necessary to print the result on screen, 
  however to test your function you are free to print the result
  */

function subString(substring, string, indexOfString) {
  let slicedString = "";

  for (let indexOfSlice = 0; indexOfSlice < substring.length; indexOfSlice++) {
    slicedString = slicedString + string[indexOfString];
    indexOfString = indexOfString + 1;
  }

  return slicedString;
 }

function occurrences(string, substring) {
  let countOfSubString = 0;

  const indexOfString = substring.length === 0 ? string.length : 0;

  for (let index = indexOfString; index < string.length; index++) {
    if (subString(substring, string, index) === substring) {
      countOfSubString = countOfSubString + 1;
    }

  }
  return countOfSubString;
}

function message(text, target, expect, evaluatingTo) {
  const isPassing = evaluatingTo === expect ? "✅" : "❌";

  const context = " The string " + text + " must have " + target;
  const expected = " " + expect + " times " ;
  const actual = " but it has " + evaluatingTo + " times ";
  return isPassing + context + expected + actual;
}

function testPrimeAbove(text,target, expect) {
  const evaluatingTo = occurrences(text, target);
  console.log(message(text, target, expect, evaluatingTo));
}

function testCases() {
  testPrimeAbove("hello world", "l", 3);
  testPrimeAbove("hello world ", "d", 1);
  testPrimeAbove("hello world", "", 0);
  testPrimeAbove("hello world", " ", 1);
  testPrimeAbove("hello world", "z", 0);
}

testCases();