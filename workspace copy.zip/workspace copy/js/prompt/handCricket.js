// toss 
// according to toss bat or bowl is chosen 
// player starts to enter values 
// when matches he is out second innings starts 
// player starts to enter values 
// when matches computer is out and score is displayed with winner


function bowling(innings, computerScore) {
  if (innings < 3) {
    const computerChoice = Math.ceil((Math.random() * 10) % 9);
    const playerChoice = prompt("Bowler: ");
    if (computerChoice === playerChoice) {
      return computerScore;
    }
    
    return batting(innings, computerScore + computerChoice);
  }
}

function batting(innings, playerScore) {
  if (innings < 3) {
    const computerChoice = Math.ceil((Math.random() * 10) % 9);
    const playerChoice = prompt("Batter: ");
    if (computerChoice === playerChoice) {
      return playerScore;
    }
    
    return batting(innings, playerScore + computerChoice);
  }
}

function selectBatOrBowl(tossResult) {
  if (tossResult) {
    // console.log("choose batting or bowling");
    const choice = prompt("type 1 for batting\n 2 for bowling");
    if (choice < 3) {
      if(choice === 1) {
        const battingScore = batting();
        return battingScore;
      } 
      const bowlingScore = bowling ();
      return bowlingScore;
    }
    console.log("you entered wrong value please renter your choice");
    return selectBatOrBowl(tossResult);
  }
}

function toss(call) {
  const headOrTail = Math.round(Math.random());
  if (headOrTail === call) {
    console.log("HEY you won the TOSS \n");
    return true;
  }

  console.log("sorry you lose the toss");
  return false;
}

function handCricket() {
  const call = prompt("let's toss what is your call?\n1 for head\n2 for tail");
  if (call !== 1 || call !== 2) {
    console.log(("enter the correct value again"));
    return handCricket();
  }
  const tossResult = toss(+call);
  const batOrBowl = selectBatOrBowl(tossResult);
}