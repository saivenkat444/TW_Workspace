/*
  Write a function that converts temperature from one unit to another

  Function takes three arguments: `from`, `to`, `value`
  
  `from` and `to` can have following values:
    - C
    - F
    - K

  Here C means Celsius, K is Kelvin and F is Fahrenheit

  Examples:
    convert('C', 'K', 0) => 273.15
    convert('C', 'F', 37) => 98.6
    convert('F', 'K', 98.6) => 310.15
    convert('F', 'C', -40) => -40
    convert('K', 'C', 100) => -173.15
    convert('K', 'F', 100) => -279.67

  Here are the conversion formulae in case you wonder how it is done :)
    - F to C:
      (F − 32) × 5/9 = C
    - K to C:
      K − 273.15 = C

  **Your function must return a value**

  It's not necessary to print the result on screen, 
  however to test your function you are free to print the result
*/

function convertingToCelsius(from, value) {
  if (from === "F") {
    return (+value - 32) * 5 / 9;
  }

  if (from === "K") {
    return +value - 273.15;
  }

  return +value;
}

function convertingFromCelsius(to, tempInC) {
  if (to === "C") {
    return tempInC;
  }

  if (to === "K") {
    return tempInC + 273.15;
  }

  if (to === "F") {
    return (tempInC * 9 / 5) + 32;
  }

  return NaN;
}

function convert(from, to, value) {
  if (from === "C" || from === "F" || from === "K") {
    let tempInC = convertingToCelsius(from, value);

    return convertingFromCelsius(to, tempInC);
  }
  
  return NaN;
}

function showMessage(from, to, value, expected, actual) {
  const expect = expected + "" === "NaN" ? "NaN" :expected;

  const mark = actual === expect ? "✅" : "❌";
  let message = " tempreature converted from " + from;
  message = message + " to " + to + " " + value;
  message = message + " is " + actual;

  return message;
}

function testConvert(from, to, value, expected) {
  let actual = convert(from, to, value);
  actual = ("" + actual === "NaN") ? "NaN" : actual; 
  console.log(showMessage(from, to, value, expected, actual));
}

function convertFromCelsiusTestCases() {
  testConvert('C', 'K', 100, 373.15);
  testConvert('C', 'K', '100', 373.15);
  testConvert('C', 'C', 100, 100);
  testConvert('C', 'C', '100', 100);
  testConvert('C', 'F', -40, -40);
  testConvert('C', 'F', 26, 78.8);
  testConvert('C', 'F', '37', 98.6);
}

function convertFromKelvinTestCases() {
  testConvert('K', 'K', 90, 90);
  testConvert('K', 'F', 373.15, 212);
  testConvert('K', 'C', 0, -273.15);
}

function convertFromFahrenheitTestCases() {
  testConvert('F', 'F', 26, 26);
  testConvert('F', 'C', 98, 36.666666666666664);
  testConvert('F', 'K', 32, 273.15);
}

function invalidTestCases() {
  testConvert('j', 'C', 56, NaN);
  testConvert('K', 'j', 90, NaN);
  testConvert('h', 'j', 86, NaN);
  testConvert('', 'j', 54, NaN);
  testConvert('', 'j', 43, NaN);
  testConvert('K', 'C', 'hi', NaN);
}

function testCases() {
  convertFromCelsiusTestCases();
  convertFromKelvinTestCases();
  convertFromFahrenheitTestCases();
  invalidTestCases();
}

testCases();

// function testFromCelsius() {
//   testTempConv('C', 'K', 0, 273.15);
//   testTempConv('C', 'F', 37, 98.6);
//   testTempConv('C', 'C', 100, 100);
//   testTempConv('C', 'D', 100, NaN);
//   testTempConv('C', 'F', '37', 98.6);
//   testTempConv('C', '', 100, NaN);
//   testTempConv('C', 'F', 'string', NaN);
// }

// function testFromKelvin() {
//   testTempConv('K', 'C', 100, -173.15);
//   testTempConv('K', 'C', 0, -273.15);
//   testTempConv('K', 'F', 100, -279.67);
//   testTempConv('K', 'K', 100, 100);
// }

// function testFromFahrenheit() {
//   testTempConv('F', 'K', 98.6, 310.15);
//   testTempConv('F', 'C', -40, -40);
//   testTempConv('F', 'F', 100, 100);
// }

// function testMiscellaneous() {
//   testTempConv('D', 'D', 100, NaN);
//   testTempConv('D', 'C', 100, NaN);
//   testTempConv('C', 'F', '37', 98.6);
//   testTempConv('x', '-', 100, NaN);
//   testTempConv('', '', 100, NaN);
//   testTempConv('', 'e', 100, NaN);
//   testTempConv('', 'C', 100, NaN);
// }

// function testAll() {
//   testFromCelsius();
//   testFromKelvin();
//   testFromFahrenheit();
//   testMiscellaneous();
// }

// testAll();
