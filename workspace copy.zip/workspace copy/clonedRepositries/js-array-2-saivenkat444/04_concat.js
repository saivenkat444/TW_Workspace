// concat the given arrays.
// concat([1, 2, 3], [4, 5, 6]) => [1, 2, 3, 4, 5, 6]

function clone(array) {
  const copyOfArray = [];

  for (let index = 0; index < array.length; index++) {
    copyOfArray.push(array[index]);
  }

  return copyOfArray;
}

export function concat(array1, array2) {
  const concatenated = clone(array1);

  for (let index = 0; index < array2.length; index++) {
    concatenated.push(array2[index]);
  }

  return concatenated;
}
