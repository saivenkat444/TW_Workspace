import * as Assertion from "jsr:@std/assert";
import { isStrictlyDescending } from "./02_strictly_descending.js";

Deno.test("everything is ascending should be false", () =>
  Assertion.assertFalse(isStrictlyDescending([1, 3, 4, 5, 16]))
);
Deno.test("one element is not in descending should be false", () =>
  Assertion.assertFalse(isStrictlyDescending([16, 5, 3, 4, 2]))
);
Deno.test("two elements in the ascending should be false", () =>
  Assertion.assertFalse(isStrictlyDescending([1, 3]))
);
Deno.test("two elements in the descending should be true", () =>
  Assertion.assert(isStrictlyDescending([3, 1]))
);
Deno.test("two elements are same and adjacent should be false", () =>
  Assertion.assertFalse(isStrictlyDescending([17, 16, 16, 15, 14, 13]))
);
Deno.test("only one element in the array should be true", () =>
  Assertion.assert(isStrictlyDescending([1]))
);
Deno.test("nothing in the array shoud be true", () =>
  Assertion.assert(isStrictlyDescending([]))
);
