console.log("hehe")

const a = 10;
a = 5;

function sum(a, b) {
  return a + b;
}
sum(2, 3);