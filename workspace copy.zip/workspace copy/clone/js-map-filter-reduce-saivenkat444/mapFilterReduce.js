// ["abc","def","ghi"] => "cfi"
// You are given an array of strings. Write a function to return a single string that is the concatenation of the last character of every string in the array.
const giveLastChar = function (resultantString, string) {
  return resultantString + string[string.length - 1];
}
const allLastChars = function (arrayOfStrings) {
  return arrayOfStrings.reduce(giveLastChar, "");
}

// [[1,-2],[3,4],[5,-6]] => [[3,4]]
// Write a function to return a new array containing only those lists that contain at least one positive number.

const areAllPositive = function (element) {
  return element >= 0;
}

const isPositive = function (listOfPositives, list) {
  const allPositivesTillNow = [...listOfPositives];

  if (list.some(areAllPositive)) {
    return allPositivesTillNow.concat([list]);
  }

  return allPositivesTillNow;
}

const listsWithPositiveNumbers = function (listOfLists) {
  return listOfLists.reduce(isPositive, []);
}

// [0,-1,-2,3,4] => 12
// Write a function to calculate the product of all the positive numbers in the array. 0 is not positive.

const VerifyIsPositive = function (element) {
  return element > 0;
}

const multiply = function (mulResultTillNow, element) {
  return mulResultTillNow * element;
}

const productOfPositives = function (numbers) {
  const allPositives = numbers.filter(VerifyIsPositive);
  const product = allPositives.reduce(multiply, 1);

  return product;
}

// ["educate", "there", "animation"] => "educate"
// Write a function to return the longest string that contains the letter "e".  

const includeE = function (string) {
  return string.includes("E") || string.includes("e");
}

const findLongestString = function (biggestLengthTillNow, string) {
  if (string.length >= biggestLengthTillNow.length && includeE(string)) {
    return string;
  }

  return biggestLengthTillNow;
}

const longestEWord = function (strings) {
  return strings.reduce(findLongestString, "");
}

// [[2, 4, 6], [1, 3, 5], [8, 10]] => false
// [[2,4],[6,8]] => true
// Write a function to check if all lists contain only even numbers. Return `true` if they do, and `false` otherwise.

const isEven = function (number) {
  return number % 2 === 0;
}

const verifyIfEven = function (list) {
  return list.every(isEven);
}

const areAllListsEven = function (listOfLists) {
  return listOfLists.every(verifyIfEven);
}

// [1,2,3,4] => 10 (sqr(1) + sqr(3))
// Write a function to calculate the sum of the squares of all the odd numbers in the array

const getOdds = function (oddsList, number) {
  const listOfOdds = [...oddsList];
  if (!isEven(number)) {
    return listOfOdds.concat(number);
  }

  return listOfOdds;
}

const square = function (number) {
  return number * number;
}

const sum = function (sumTillNow, number) {
  return sumTillNow + number;
}

const sumOfSquaresOfOdds = function (numbers) {
  const listOfOdds = numbers.reduce(getOdds, []);
  const squares = listOfOdds.map(square);

  return squares.reduce(sum, 0);
}

// ["abc","def"] => true
// ["abc","de"] => false
// Write a function to check if all strings have the same length. Return `true` if they do, and `false` otherwise. 

const verifyDifferentLength = function (length) {
  return function (element) {
    return element.length === length;
  }
}

const areAllOfSameLength = function (listOfStrings) {
  return listOfStrings.every(verifyDifferentLength(listOfStrings[0].length))
}

// [1,2,3,4,1,2] => [1,2,3,4]
// Write a function to return a new array with all duplicate values removed.

const verifyForDuplicates = function (numbers, element) {
  if (numbers.includes(element)) {
    return numbers;
  }

  return numbers.concat(element);
}

const removeDuplicates = function (numbers) {
  return numbers.reduce(verifyForDuplicates, []);
}

// ["ant", "eye", "id"] => true
// ["ant","bat"] => false
// Write a function to check if all the strings in the array start with a vowel. Return `true` if they do, and `false` otherwise.  

const verifyStartWithVowel = function (element) {
  const vowels = ["a", "e", "i", "o", "u", "A", "E", "I", "O", "U"];

  return vowels.includes(element[0]);
}

const allStartWithAVowel = function (arrayOfStrings) {
  return arrayOfStrings.every(verifyStartWithVowel);
}

// [1,2,3,4] => [1,3,6,10]
// [1,1,4,5] => [1,2,6,11]
// Build an array where each element is the running sum of the elements up to that index.

const giveTotal = function (resultantTotal, element) {
  return resultantTotal.concat(resultantTotal.at(-1) + element);
}

const runningTotal = function (numbers) {
  const runningSum = numbers.reduce(giveTotal, [0]);
  return runningSum.slice(1);
}

// [] => [[]]
// [1] => [[1]]
// [1,2] => [[1,2]]
// [1,2,3] => [[1,2],[3]]
// [1,2,3,4] => [[1,2],[3,4]]
// Write a function to pair up elements of a list. 

const makePair = function (pairsArray, element) {
  if ((pairsArray.at(-1)).length < 2) {
    pairsArray.at(-1).push(element);

    return pairsArray;
  }

  pairsArray.push([element]);

  return pairsArray;
}

const pairs = function (list) {
  return list.reduce(makePair, [[]]);
}
