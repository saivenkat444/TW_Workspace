function isDivisible(numerator, denominator) {
  return numerator % denominator === 0;
}

function isPrime(number) {
  for (let isDivisibleWith = 2; isDivisibleWith < number; isDivisibleWith++) {
    if (isDivisible(number, isDivisibleWith)) {
      return false;
    }
  }

  return true;
}

function nextPrime(number) {
  if (isPrime(number)) {
    return number;
  }

  return nextPrime(number + 1);
}

function firstPrimeAbove(number) {
  if (number < 2) {
    return 2;
  }

  return nextPrime(number + 1);
}

function makeMessage(primeCandidate, expected, actual) {
  let message = "the prime number above " + primeCandidate;

  message = message + " expected to be " + expected;
  message = message + " and it is " + actual;

  return message;
}

function testFirstPrimeAbove(number, expected) {
  const actual = firstPrimeAbove(number);
  const getMark  = actual === expected ? '✅' : '❌';
  
  console.log(getMark + makeMessage(number, expected, actual));
}

function testAll() {
  testFirstPrimeAbove(5, 7);
  testFirstPrimeAbove(23, 29);
  testFirstPrimeAbove(6, 7);
  testFirstPrimeAbove(2, 3);
  testFirstPrimeAbove(1, 2);
  testFirstPrimeAbove(0, 2);
}

testAll();