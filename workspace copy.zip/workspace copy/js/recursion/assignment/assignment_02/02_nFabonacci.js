function nthTermInFabonacci(previous, next, terms) {
  if (terms === 0) {
    return next;
  }

  return nthTermInFabonacci(next, previous + next, terms - 1);
}

function nthFibonacciTerm(n) {
  const previous = -1;
  const next = 1;

  return nthTermInFabonacci(previous, next, n);
}

function makeMessage(number, expected, actual) {
  let message = "the term " + number;
  
  message = message + " expected to be " + expected;
  message = message + " and it is " + actual;

  return message;
}

function testSumOfAP(number, expected) {
  const actual = nthFibonacciTerm(number);
  const getMark  = actual === expected ? '✅' : '❌';
  
  console.log(getMark + makeMessage(number, expected, actual));
}

function testAll() {
  testSumOfAP(1, 0);
  testSumOfAP(2, 1);
  testSumOfAP(3, 1);
  testSumOfAP(4, 2);
  testSumOfAP(5, 3);
  testSumOfAP(6, 5);
  testSumOfAP(7, 8);
  testSumOfAP(8, 13);
}

testAll();