// const terms = 1;

const addition = function ([startElement, nextElement]) {
  return [nextElement, startElement + nextElement];
}

const fillInArray = function (terms) {
  const dummyArray = [];
  dummyArray[terms - 1] = 0;
  
  return dummyArray.fill(0);
  
  // const array = [];
  // for (let index = 0; index < terms; index++) {
  //   array.push(0);
  // }

  // return array;
}

const nThFibonacci = function (terms) {
  const dummyArray = fillInArray(terms - 1);
  const array = dummyArray.reduce(addition, [0, 1]);
  return array[0];
}

console.log(nThFibonacci(8));