understandings:
tree
data
--small_data
----tansaction files
----cutsomer data
--code

there are customers and their data need to check their balance and their transactioncs count

- get the content
- convert them into transactions data
- analyze the data and give a summary report

- fetch the user's data
- transactions are counted and their balances are calculated
- move the data to a new csv file

- split the customer data and their data files
- calculate them and store them
- then move onto the next customer
