export const fetchNLines = (count, content, readFromTop = true) => {
  const fileContent = content.split("\n");
  const firstLines = readFromTop
    ? fileContent.slice(0, count)
    : fileContent.slice(0 - count);
  return firstLines.join("\n");
};

export const fetchNchars = (count, content, readFromTop = true) => {
  const fileContent = content;
  const start = readFromTop ? 0 : fileContent.length - count;
  return fileContent.substring(start, count);
};
