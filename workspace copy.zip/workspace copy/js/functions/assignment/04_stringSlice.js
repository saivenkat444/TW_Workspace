/*
  Implement the below function that
  creates a slice/substring using start and end indices

  Examples:
    slice('hello world', 0, 4) => 'hello'
    slice('negative start', -1, 8) => 'negative '
    slice('', 0, 10) => ''

  **Your function must return a value**

  It's not necessary to print the result on screen, 
  however to test your function you are free to print the result
*/

function max(number1, number2) {
  return number1 < number2 ? number2 : number1;
}

function min(number1, number2) {
  return number1 > number2 ? number2 : number1;
}

function slice(text, start, end) {
  let slicedString = "";

  for (let index = max(start, 0); index <= min(end, text.length - 1); index++) {
    slicedString = slicedString + text[index];
  }

  return slicedString;
}

function message(text, expect, evaluatingTo) {
  const isPassing = evaluatingTo === expect ? "✅" : "❌";

  const context = " the string " + text;
  const expected = " should be " + expect;
  const actual = " but it is " + evaluatingTo;
  
  return isPassing + context + expected + actual;
}

function testSlice(text, start, end, expect) {
  const evaluatingTo = slice(text, start, end);
  console.log(message(text, expect, evaluatingTo));
}

function testcases() {
  testSlice("hello", 0, 2, "hel");
  testSlice("hello", -12, 100, "hello");
  testSlice("hello", 12, 2, "");
  testSlice("hello", 0, 0, "h");
  testSlice("hello", 0, 90, "hello");
  testSlice("", 0, 5, "");
  testSlice("hello", 9, 10, "");
}

testcases();