// Give an number extract its digit into array
// Number can positive, negative, floating point.
// extractDigits(123) => [1, 2, 3]
// extractDigits(-123) => [1, 2, 3]
// extractDigits(12.3) => [1, 2, 3]

function getDigits(number) {
  let candidate = Math.abs(number);
  const digits = [];

  while (candidate > 0) {
    digits.unshift(candidate % 10);
    candidate = (candidate - (candidate % 10)) / 10;
  }

  return digits;
}

function extractDigits(number) {
  if (number === 0) {
    return [0];
  }

  return getDigits(number);
}

function makeMessage(number, expected, actual) {
  let message = "the number '" + number + "' the digits extracted are";

  message = message + " are '" + expected;
  message = message + "' and it is '" + actual + "'";

  return message;
}

function areEqual(array1, array2) {
  if (array1.length !== array2.length) {
    return false;
  }

  for (let index = 0; index < array1.length; index++) {
    if (array1[index] !== array2[index]) {
      return false;
    }
  }

  return true;
}

function testExtractDigits(number, expected) {
  const actual = extractDigits(number);
  const getMark = areEqual(actual, expected) ? '✅' : '❌';

  console.log(getMark + makeMessage(number, expected, actual));
}

function testAll() {
  testExtractDigits(123, [1, 2, 3]);
  testExtractDigits(-123, [1, 2, 3]);
  // testExtractDigits(12.3, [1, 2, 3]);
  // testExtractDigits(-12.3, [1, 2, 3]);
  testExtractDigits(1020, [1, 0, 2, 0]);
  testExtractDigits(0, [0]);
}

testAll();