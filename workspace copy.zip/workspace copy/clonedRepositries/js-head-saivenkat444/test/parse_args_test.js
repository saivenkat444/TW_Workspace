import { describe, it } from "jsr:@std/testing/bdd";
import { assertEquals } from "jsr:@std/assert";
import { parseArgs } from "../src/parse_args.js";

describe("parseArgs(args) for the arguments which starts with file", () => {
  it("should give the single file with default option and count, when a single file is given", () => {
    const actual = parseArgs(["file.txt"]);
    const expected = {
      option: "n",
      count: 10,
      filepaths: ["file.txt"],
      isError: false,
    };
    assertEquals(actual, expected);
  });
  it("should give multiple files with default option and count, when there are multipe files", () => {
    const actual = parseArgs(["file.txt", "something.js"]);
    const expected = {
      option: "n",
      count: 10,
      filepaths: ["file.txt", "something.js"],
      isError: false,
    };
    assertEquals(actual, expected);
  });
  it("should treat every argument as file, even when there is -n(count) after the filepath", () => {
    const actual = parseArgs(["file.txt", "-n2"]);
    const expected = {
      option: "n",
      count: 10,
      filepaths: ["file.txt", "-n2"],
      isError: false,
    };
    assertEquals(actual, expected);
  });
  it("should treat every argument as file, even when there is -n(space)(count) after the filepath", () => {
    const actual = parseArgs(["file.txt", "-n", "2"]);
    const expected = {
      option: "n",
      count: 10,
      filepaths: ["file.txt", "-n", "2"],
      isError: false,
    };
    assertEquals(actual, expected);
  });
  it("should treat every argument as file, even when there is -c(count) after the filepath", () => {
    const actual = parseArgs(["file.txt", "-c2"]);
    const expected = {
      option: "n",
      count: 10,
      filepaths: ["file.txt", "-c2"],
      isError: false,
    };
    assertEquals(actual, expected);
  });
  it("should treat every argument as file, even when there is -c(with space)(count) after the filepath", () => {
    const actual = parseArgs(["file.txt", "-c", "2"]);
    const expected = {
      option: "n",
      count: 10,
      filepaths: ["file.txt", "-c", "2"],
      isError: false,
    };
    assertEquals(actual, expected);
  });
});

describe("parseArgs(args) for valid option -n", () => {
  it("should give a single file with count of lines, when -n(count) is given with single file", () => {
    const actual = parseArgs(["-n7", "file.txt"]);
    const expected = {
      option: "n",
      count: 7,
      filepaths: ["file.txt"],
      isError: false,
    };
    assertEquals(actual, expected);
  });
  it("should give a single file with count of lines when, -n(space)(count) is given with single file", () => {
    const actual = parseArgs(["-n", "7", "file.txt"]);
    const expected = {
      option: "n",
      count: 7,
      filepaths: ["file.txt"],
      isError: false,
    };
    assertEquals(actual, expected);
  });
  it("should give a multiple files with count of lines, when -n(count) is given with multiple files", () => {
    const actual = parseArgs(["-n7", "file.txt", "something.js"]);
    const expected = {
      option: "n",
      count: 7,
      filepaths: ["file.txt", "something.js"],
      isError: false,
    };
    assertEquals(actual, expected);
  });
  it("should give a multiple files with count of lines, when -n(space)(count) is given with multiple files ", () => {
    const actual = parseArgs(["-n", "7", "file.txt", "something.js"]);
    const expected = {
      option: "n",
      count: 7,
      filepaths: ["file.txt", "something.js"],
      isError: false,
    };
    assertEquals(actual, expected);
  });
});

describe("parseArgs(args) for repeated valid option n", () => {
  it("should over ride all the previous valid options, when -n(count) are given with single file", () => {
    const actual = parseArgs(["-n7", "-n8", "file.txt"]);
    const expected = {
      option: "n",
      count: 8,
      filepaths: ["file.txt"],
      isError: false,
    };
    assertEquals(actual, expected);
  });
  it("should over ride all the previous valid options, when -n(count) are given with multiple files", () => {
    const actual = parseArgs(["-n7", "-n8", "file.txt", "something.js"]);
    const expected = {
      option: "n",
      count: 8,
      filepaths: ["file.txt", "something.js"],
      isError: false,
    };
    assertEquals(actual, expected);
  });
  it("should over ride all the previous valid options, when -n(space)(count) are given with single file", () => {
    const actual = parseArgs(["-n", "7", "-n", "8", "file.txt"]);
    const expected = {
      option: "n",
      count: 8,
      filepaths: ["file.txt"],
      isError: false,
    };
    assertEquals(actual, expected);
  });
  it("should over ride all the previous valid options, when -n(space)(count) are given with space for multiple files", () => {
    const actual = parseArgs([
      "-n",
      "7",
      "-n",
      "8",
      "file.txt",
      "something.js",
    ]);
    const expected = {
      option: "n",
      count: 8,
      filepaths: ["file.txt", "something.js"],
      isError: false,
    };
    assertEquals(actual, expected);
  });
  it("should over ride, even when combination of options are given together  with single file", () => {
    const actual = parseArgs(["-n", "7", "-n8", "file.txt"]);
    const expected = {
      option: "n",
      count: 8,
      filepaths: ["file.txt"],
      isError: false,
    };
    assertEquals(actual, expected);
  });
  it("should over ride, even when combination of options are given together with multiple files", () => {
    const actual = parseArgs(["-n", "7", "-n8", "file.txt", "something.js"]);
    const expected = {
      option: "n",
      count: 8,
      filepaths: ["file.txt", "something.js"],
      isError: false,
    };
    assertEquals(actual, expected);
  });
});

describe("parseArgs(args) for valid option c", () => {
  it("should give a single file with count of lines, when -c(count) is given with single file", () => {
    const actual = parseArgs(["-c7", "file.txt"]);
    const expected = {
      option: "c",
      count: 7,
      filepaths: ["file.txt"],
      isError: false,
    };
    assertEquals(actual, expected);
  });
  it("should give a single file with count of lines, when -c(space)(count) is given with single file", () => {
    const actual = parseArgs(["-c", "7", "file.txt"]);
    const expected = {
      option: "c",
      count: 7,
      filepaths: ["file.txt"],
      isError: false,
    };
    assertEquals(actual, expected);
  });
  it("should give multiple files with count of lines, when -c(count) is given with multiple files", () => {
    const actual = parseArgs(["-c7", "file.txt", "something.js"]);
    const expected = {
      option: "c",
      count: 7,
      filepaths: ["file.txt", "something.js"],
      isError: false,
    };
    assertEquals(actual, expected);
  });
  it("should give multiple files with count of lines, when -c(space)(count) is given with multiple files", () => {
    const actual = parseArgs(["-c", "7", "file.txt", "something.js"]);
    const expected = {
      option: "c",
      count: 7,
      filepaths: ["file.txt", "something.js"],
      isError: false,
    };
    assertEquals(actual, expected);
  });
});

describe("parseArgs(args) for repeated valid option c", () => {
  it("should over ride all the previous valid options, when -c(count) are given with single file", () => {
    const actual = parseArgs(["-c7", "-c8", "file.txt"]);
    const expected = {
      option: "c",
      count: 8,
      filepaths: ["file.txt"],
      isError: false,
    };
    assertEquals(actual, expected);
  });
  it("should over ride all the previous valid options, when -c(count) are given with multiple files", () => {
    const actual = parseArgs(["-c7", "-c8", "file.txt", "something.js"]);
    const expected = {
      option: "c",
      count: 8,
      filepaths: ["file.txt", "something.js"],
      isError: false,
    };
    assertEquals(actual, expected);
  });
  it("should over ride all the previous valid options, when -c(space)(count) are given with single file", () => {
    const actual = parseArgs(["-c", "7", "-c", "8", "file.txt"]);
    const expected = {
      option: "c",
      count: 8,
      filepaths: ["file.txt"],
      isError: false,
    };
    assertEquals(actual, expected);
  });
  it("should over ride all the previous valid options, when -c(space)(count) are given with multiple files", () => {
    const actual = parseArgs([
      "-c",
      "7",
      "-c",
      "8",
      "file.txt",
      "something.js",
    ]);
    const expected = {
      option: "c",
      count: 8,
      filepaths: ["file.txt", "something.js"],
      isError: false,
    };
    assertEquals(actual, expected);
  });
  it("should over ride all the previous valid options, when -c(space)(count) and -c(count) are given together with single file", () => {
    const actual = parseArgs(["-c", "7", "-c8", "file.txt"]);
    const expected = {
      option: "c",
      count: 8,
      filepaths: ["file.txt"],
      isError: false,
    };
    assertEquals(actual, expected);
  });
  it("should over ride all the previous valid options, when -c(space)(count) and -c(count) are given together with multiple files", () => {
    const actual = parseArgs(["-c", "7", "-c8", "file.txt", "something.js"]);
    const expected = {
      option: "c",
      count: 8,
      filepaths: ["file.txt", "something.js"],
      isError: false,
    };
    assertEquals(actual, expected);
  });
});

describe("parseArgs(args) for illegal count error", () => {
  it("should give the error, when no number is given with -c(space)(invalid count)", () => {
    const actual = parseArgs(["-c", "file.txt"]);
    const expected = {
      type: "invalid count",
      token: "file.txt",
      isError: true,
    };
    assertEquals(actual, expected);
  });
  it("should give the error, when no number is given with -c(invalid count)", () => {
    const actual = parseArgs(["-csomething", "file.txt"]);
    const expected = {
      type: "invalid count",
      token: "something",
      isError: true,
    };
    assertEquals(actual, expected);
  });
  it("should give the error, when no number is given with -n(space)(invalid count)", () => {
    const actual = parseArgs(["-n", "file.txt"]);
    const expected = {
      type: "invalid count",
      token: "file.txt",
      isError: true,
    };
    assertEquals(actual, expected);
  });
  it("should give the error, when no number is given with -n(invalid count)", () => {
    const actual = parseArgs(["-nsomething", "file.txt"]);
    const expected = {
      type: "invalid count",
      token: "something",
      isError: true,
    };
    assertEquals(actual, expected);
  });
});

describe("parseArgs(args) for option error", () => {
  it("should give the error, when -C is given as option", () => {
    const actual = parseArgs(["-C", "file.txt"]);
    const expected = { type: "invalid option", token: "C", isError: true };
    assertEquals(actual, expected);
  });
  it("should give the error, when -N is given as option", () => {
    const actual = parseArgs(["-N", "file.txt"]);
    const expected = { type: "invalid option", token: "N", isError: true };
    assertEquals(actual, expected);
  });
  it("should give the error, when -(invalid option) is given", () => {
    const actual = parseArgs(["-something", "file.txt"]);
    const expected = { type: "invalid option", token: "s", isError: true };
    assertEquals(actual, expected);
  });
  // it("should give the error when no number is given for without space format for n", () => {
  //   const actual = parseArgs(["-1", "file.txt"]);
  //   const expected = {
  //     error: { type: "invalid option", token: "1" },
  //   };
  //   assertEquals(actual, expected);
  // });
});

describe("parseArgs(args) should give the default case", () => {
  it("should not give any file paths when there are no filepaths are given", () => {
    const actual = parseArgs([]);
    const expected = {type: "no file", token: "", isError: true};
    assertEquals(actual, expected);
  });
});
