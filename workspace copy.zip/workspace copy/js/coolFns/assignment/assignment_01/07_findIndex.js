// Given an array of numbers and a element, return the first index in the array
// where element is present else -1
// findIndex(["apple", "cake", "tea", "coffee", "tea"], "tea") => 2
// do not modify input parameters
function findIndex(array, element) {
  for (let index = 0; index < array.length; index++) {
    if (array[index] === element) {
      return index;
    }
  }

  return -1;
}

function makeMessage(array, expected, actual) {
  let message = "the index of element in the array: '" + array;

  message = message + "' are '" + expected;
  message = message + "' and it is '" + actual + "'";

  return message;
}

function areEqual(array1, array2) {
  if (array1.length !== array2.length) {
    return false;
  }

  for (let index = 0; index < array1.length; index++) {
    if (array1[index] !== array2[index]) {
      return false;
    }
  }

  return true;
}

function testFindIndex(array, element, expected) {
  const actual = findIndex(array, element);
  const getMark = areEqual(actual, expected) ? '✅' : '❌';

  console.log(getMark + makeMessage(array, element, expected, actual));
}

function testAll() {
  testFindIndex(["apple", "cake", "tea", "coffee"], "tea", 2);
  testFindIndex(["apple", "cake", "tea", "coffee", "tea"], "milk", -1);
  testFindIndex(["apple", "cake", "tea", "coffee", "tea"], "tea", 2);
  testFindIndex(["apple", "cake", "tea", "coffee", "teaPowder"], "tea", 2);
  testFindIndex(["apple", "cake", "teaPowder", "coffee", "tea"], "tea", 4);
  testFindIndex([1, 2, 3, 4, 6, 7, 8, 9, 5], 5, 8);
}

testAll(); 