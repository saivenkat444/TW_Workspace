function isOdd(number) {
  if(number < 2) {
    console.log("line 3");return number === 1; 
  }

  console.log("line 6");return isOdd(number - 2);
}

console.log(isOdd(3));

// function message(number, expected) {
//   const getMark = actual === expected ? "✅" : "❌";

//   const context = "the number " + number;
//   const expect = " is expected to be " + expected;
//   const finalResult = " and it is " + expected;

//   return getMark + context + expect + finalResult;
// }

// function testisOdd(number, expected) {
//   console.log(message(number, expected));
// }

// function testCases() {
//   testisOdd(0, false);
//   testisOdd(1, true);
//   testisOdd(2, false);
//   testisOdd(3, true);
//   testisOdd(4, false);
//   testisOdd(5, true);
//   testisOdd(6, false);
//   testisOdd(7, true);
//   testisOdd(8, false);
// }

// testCases();