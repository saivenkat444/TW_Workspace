function isEven(number) {
  if(number < 2) {
    if (number === 0) {
      return true;
    }
    // return number === 0;
  }
  return isEven(number - 2);
}

console.log(isEven(6));
console.log(isEven(5));
console.log(isEven(4));
console.log(isEven(3));
console.log(isEven(2));
console.log(isEven(1));
console.log(isEven(0));