export const double = (number) => number * 2;
