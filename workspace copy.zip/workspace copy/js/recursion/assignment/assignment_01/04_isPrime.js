function areThereFactors(number, factorCandidate) {
  const isDivisible = number % factorCandidate !== 0;

  if (factorCandidate === 2) {
    return isDivisible;
  }
  
  return isDivisible && areThereFactors(number, factorCandidate - 1);
}

function isPrime(primeCandidate) {
  if (primeCandidate <= 2) {
    return primeCandidate === 2;
  }

  return areThereFactors(primeCandidate, primeCandidate - 1);  
}

function makeMessage(primeCandidate, expected, actual) {
  let message = "the number is " + primeCandidate;
  
  message = message + " expected to be " + expected;
  message = message + " and it is " + actual;

  return message;
}

function testIsPrime(primeCandidate, expected) {
  const actual = isPrime(primeCandidate);
  const getMark  = actual === expected ? '✅' : '❌';
  console.log(getMark + makeMessage(primeCandidate, expected, actual));
}

function testAll() {
  testIsPrime(5, true);
  testIsPrime(6, false);
  testIsPrime(2, true);
  testIsPrime(3, true);
  testIsPrime(19, true);
  testIsPrime(29, true);
  testIsPrime(27, false);
  testIsPrime(4, false);
}

testAll();