- [ ] know about the date.now();
- [ ] structure the files
---> test, src, directories
---> have a main file 



- get the order and note the time, and instantly...
- place the order and assign an order id and start the timer 
- wait for 3 seconds and add the food preparaton detail
- wait for 2 seconds and add the packaging details
- wait for 5 seconds and add the delivery details
- print all the order details