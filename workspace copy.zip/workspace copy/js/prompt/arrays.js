function takeName(number) {
  return prompt("Enter Player " + number + " Name: ");
}

function generateCard() {
  return Math.floor((Math.random() * 10) % 7);
}

function pickCard(player) {
  if (prompt(player + " pick the next card raa....", "✅") === "✅") {
    return generateCard();
  }
  console.log("(press enter to continue)");
  return pickCard(player);
}

function isCardAvailable(card, deck) {
  // let cardsDeck = clone(deck);
  return (deck[card] > 0);
}

function displayPickedCard(card, player) {
  switch (card) {
    case 0 :
      return "\n" + player + " you picked diffuse\n";
    case 1 :
      return "\n" + player + " you picked TACOCAT 🌮🌮\n";
    case 2 :
      return "\n" + player + " you picked GODCAT 🐱🐱\n";
    case 3 :
      return "\n" + player + " you picked CATERMELON 🍉🍉\n";
    case 4 :
      return "\n" + player + " you picked HAIRY POTATOCAT 🥔🥔\n";
    case 5 :
      return "\n" + player + " you picked RAINBOWCAT 🌈🌈\n";
    case 6 :
    return "\nOH NOOO....." + player + " you picked a BOMB CARD 💣💣💣💥💥💥\n";
  }
}

// function isBombExploded(card) {
//   return card === 3;
// }

function playerTurn(player, card) {
  if (!isCardAvailable(card, deck)) {
    const anotherCard = generateCard();
    return playerTurn(player, anotherCard);
  }

  console.log(displayPickedCard(card, player));
  // if (isBombExploded(card)) {
  //   return -1;
  // }
  
  return card;
}

function pickIndex(card) {
  if (card === -1) {
    return 0;
  }

  return card;
}

function displayCards(cards, player) {
  let message = player + "have ";

  message = message + " DIFFUSE:" + cards[0];
  message = message + " TACOCAT:" + cards[1];
  message = message + " GODCAT:" + cards[2];
  message = message + " CATERMELON:" + cards[3];
  message = message + " HAIRY POTATOCAT:" + cards[4];
  
  return message + " RAINBOWCAT:" + cards[5];
}

function clone(array) {
  const copyOfArray = [];

  for (let index = 0; index < array.length; index++) {
    copyOfArray.push(array[index]);
  }

  return copyOfArray;
}

function startPicking(cardsOfPlayer, player, deck) {
  const playerCards = clone(cardsOfPlayer);
  const cardsDeck = clone(deck);
  const card = playerTurn(player, pickCard(player));

  if (card === 6) {
    playerCards[0] = playerCards[0] - 1;
  } else { 
    playerCards[card] = playerCards[card] + 1;
    cardsDeck[card] =  cardsDeck[card] - 1;
  }

  if (playerCards[0] < 0) {
    return "GAME OVER";
  }

  console.log(displayCards(playerCards, player))
  return playerCards;
}

function game(p1Cards, p2Cards, deck) {
  let updatedDeck = clone(deck);
  const cardsOf1 = startPicking(p1Cards, player1, updatedDeck);

  const cardsOf2 = startPicking(p2Cards, player2, updatedDeck);

  if (cardsOf1 === "GAME OVER" ||cardsOf2 === "GAME OVER") {
    return "";
  }

  return game(cardsOf1, cardsOf2, updatedDeck);
}

const player1 = takeName(1);
const player2 = takeName(2);
const p1Cards = [1, 0, 0, 0, 0, 0];
const p2Cards = [1, 0, 0, 0, 0, 0];
const deck =  [1, 4, 4, 1, 4, 4, 4];