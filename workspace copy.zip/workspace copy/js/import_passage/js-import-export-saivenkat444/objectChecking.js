const isEqual = (a, b) => a === b;

const arrEqual = function (actual, expected) {
  if (actual.length !== expected.length) return false;

  return actual.every((element, index) => arrEqual(element, expected[index]));
};

const verifyObjects = function (actual, expected) {
  if (typeof actual !== "object") return isEqual(actual, expected);

  const actualKeys = Object.keys(actual);
  const expectedKeys = Object.keys(expected);

  if (actualKeys.length !== expectedKeys.length) return false;

  return actualKeys.every(
    (key) => key in expected && verifyObjects(expected[key], actual[key])
  );
};

// console.log(
//   verifyObjects(
//     { name: "sai", anotherName: "ajay", fav: { name: ["idli"] } },
//     { anotherName: "ajay", name: "sai", fav: { name: ["idli"] } }
//   )
// );

// console.log(verifyObjects(2, 2));
// console.log(verifyObjects([1, 2, 2, [3, 4, [5]]], [1, 2, 2, [3, 4, [5, 6]]]));
