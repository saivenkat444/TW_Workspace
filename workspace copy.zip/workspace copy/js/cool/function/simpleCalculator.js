const add = function(x, y) {
  return x + y;
}

const sub = function(x, y) {
  return x - y;
}

const mul = function(x, y) {
  return x * y;
}

const div = function(x, y) {
  return x / y;
}

const performCalculation = function (operation, operand1, operand2) {
  return operation(operand1, operand2);
}

function testPerformCalculation(operation, operand1, operand2, expected, failed) {
  const actual = performCalculation(operation, operand1, operand2);
  if (actual !== expected) {
    failed.push([operation, operand1, operand2, expected, actual]);
  }
  
}

function getTestResult(failed) {
  if (failed.length === 0) {
    return ("congratulations");
  }

  return console.table(failed);
}

function testAll() {
  const failed = [];
  testPerformCalculation(add, 2, 1, 3, failed);
  testPerformCalculation(sub, 2, 1, 1, failed);
  testPerformCalculation(mul, 2, 1, 2, failed);
  testPerformCalculation(div, 2, 1, 2, failed);

  console.log(getTestResult(failed));
}

testAll();