// Remove last n elements from the array
// dropLast([1, 2, 3], 1) => [1, 2]
// dropLast([1, 2, 3], 4) => []
// Do not modify the original array

function dropLast(array, n) {
  const elementsDroppedArray = [];

  for (let times = array.length - n - 1; times > -1; times--) {
    elementsDroppedArray.unshift(array[times]);
  }

  return elementsDroppedArray;
}

function makeMessage(array1, terms, expected, actual) {
  let message = "the array1: '" + array1 + "' dropped times : '" + terms;

  message = message + "' are '" + expected;
  message = message + "' and it is '" + actual + "'";

  return message;
}

function areEqual(array1, array2) {
  if (array1.length !== array2.length) {
    return false;
  }

  for (let index = 0; index < array1.length; index++) {
    if (array1[index] !== array2[index]) {
      return false;
    }
  }

  return true;
}

function testDropLast(array1, terms, expected) {
  const actual = dropLast(array1, terms);
  const getMark = areEqual(actual, expected) ? '✅' : '❌';

  console.log(getMark + makeMessage(array1, terms, expected, actual));
}

function testAll() {
  testDropLast([1, 2, 3], 1, [1, 2]);
  testDropLast([1, 2, 3], 2, [1]);
  testDropLast([1, 2, 3], 0, [1, 2, 3]);
  testDropLast([1, 2, 3], 3, []);
  testDropLast([], 3, []);
}

testAll();