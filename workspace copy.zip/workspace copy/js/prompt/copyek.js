function sliceIfInRange(text , currentIndex, endIndex) {
  if (currentIndex > endIndex) {
    return ""; 
  }

  return text[currentIndex] + slice(text, currentIndex + 1, endIndex);
}

function slice(text, start, end) {
  const startIndex = start < 0 ? 0 : start;
  const endIndex = text.length <= end ? text.length - 1 : end;

  return sliceIfInRange(text, startIndex, endIndex);
}

function cardPicked(lastCard) {
  switch (lastCard) {
    case 1 :
      return ("TACOCAT 🌮 ");
    case 2 :
      return ("GODCAT 🐱 ");
    case 3 :
      return "";
      case 4 :
      return ("CATERMELON 🍉 ");
    case 5 :
      return ("HAIRY POTATOCAT 🥔 ");
    case 6 :
      return ("RAINBOWCAT 🌈 ");
  }
}

function action(cardPicked) {
  if (cardPicked === 0) {
    if (confirm("Use the diffuse if there are any?")) {
      return 0;
    }
    return -1;
  }
  
}

function displayPickedCard(card) {
  if (card === 3) {
    console.log("\nOH NOOO..... you picked a BOMB CARD 💣💣💣💥💥💥\n");
    return action(0);
  }

  switch (card) {
    case 1 :
      console.log("\nLUCKY FELLOW you picked TACOCAT 🌮🌮\n");
      break;
    case 2 :
      console.log("\nLUCKY FELLOW you picked GODCAT 🐱🐱\n");
      break;
    case 4 :
      console.log("\nLUCKY FELLOW you picked CATERMELON 🍉🍉\n");
      break;
    case 5 :
      console.log("\nLUCKY FELLOW you picked HAIRY POTATOCAT 🥔🥔\n");
      break;
    case 6 :
      console.log("\nLUCKY FELLOW you picked RAINBOWCAT 🌈🌈\n");
      break;
  }

  return action(card);
}

function isBombExploded(card, player1, ndif, cardsPicked) {
  if (card <= 0) {
    if (ndif - 1 < 0 || card < 0) {
      return "GAME OVER\nplayer unable to diffuse so kitten died";
    }
    const removeDiffuse = sliceIfInRange(cardsPicked, 7, cardsPicked.length);
    return explodingKittens(player1, ndif - 1, removeDiffuse);
  }
  return explodingKittens(player1, ndif, cardsPicked);
}

function explodingKittens(player1, ndif, pickedCards) {
  console.log("______________________________________________________________");
  console.log("\nYOU HAVE " + pickedCards + "\n");
  console.log(player1 + " has " + ndif + " diffuse cards\n");
  
  if (prompt("pick next card", "✅") === "✅") {
    let card = Math.ceil((Math.random() * 10) % 6);
    const cardsPicked = pickedCards + cardPicked(card);
    card = displayPickedCard(card);
    return isBombExploded(card, player1, ndif, cardsPicked);    
  }
}

console.log(explodingKittens(prompt("enter player 1 name:"), 1, "DIFFUSE "));