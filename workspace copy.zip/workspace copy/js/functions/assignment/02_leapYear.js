/*
  Implement the below function that tells if a given year is leap or not.
  Examples:
    isLeapYear(1900) => false
    isLeapYear(2020) => true
    isLeapYear(2001) => false

  *Your function must return a value*

  It's not necessary to print the result on screen, 
  however to test your function you are free to print the result
*/

function divisibleWith (numerator, denominator) {
  return numerator % denominator === 0;
}

function isLeapYear(year) {
  if (divisibleWith(year, 400)) {
    return true;
  }

  return (!divisibleWith(year, 100) && divisibleWith(year, 4));
}

function message(leap, expect, evaluatingTo) {
  const isPassing = evaluatingTo === expect ? "✅" : "❌";

  const context = " year " + leap;
  const expected = " should be " + expect;
  const actual = " but it is " + evaluatingTo;

  return isPassing + context + expected + actual;
}

function testLeap(leap, expect) {
  const evaluatingTo = isLeapYear(leap);
  console.log(message(leap, expect, evaluatingTo));
}

function testCases() {
  testLeap(4, true);
  testLeap(1, false);
  testLeap(100, false);
  testLeap(400, true);
  testLeap(600, false);
}

testCases();