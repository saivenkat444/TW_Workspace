import {double} from "./main.js"
import { describe, test } from "jsr:@std/testing/bdd";
import { assertEquals } from "jsr:@std/assert";
  describe("finding the double of one digit number", () => {
  test("the double of 3 is 6", () => assertEquals(double(3), 6))
test("the double of 2 is 4", () => assertEquals(double(2), 4))
test("the double of 1 is 2", () => assertEquals(double(1), 2))
test("the double of 0 is 0", () => assertEquals(double(0), 0));
  }
)