function takeName(number) {
  return prompt("Enter Player " + number + " Name: ");
}

function occurences(pickedCards, target) {
  let count = 0;
  for (let index = 0; index < pickedCards.length; index++){
    if (pickedCards[index] === target) {
      count = count + 1;
    }
  }

  return "" + count;
}

function countTheCards(pickedCards) {
  const diffuse = occurences(pickedCards, "0");
  const taco = occurences(pickedCards, "1");
  const god = occurences(pickedCards, "2");
  const caterMelon = occurences(pickedCards, "4");
  const hairyPotato = occurences(pickedCards, "5");
  const rainbow = occurences(pickedCards, "6");

  return diffuse + taco + god + caterMelon + hairyPotato + rainbow;
}

function displayCards(pickedCards, player) {
  if (pickedCards === "GAME OVER") {
    return player + " HAS NO DIFFUSE TO SAVE KITTENS";
  }
  const nCards = countTheCards(pickedCards);

  console.log("_________________________________________________________________________________________________________");
  let message = player + " HAVE DIFFUSE: " + nCards[0];
  message = message + "  TACOCAT 🌮:" + nCards[1];
  message = message + "  GODCAT 🐱:" + nCards[2];
  message = message + "  CATERMELON 🍉:" + nCards[3];
  message = message + "  HAIRY POTATOCAT 🥔:" + nCards[4];
  message = message + "  RAINBOWCAT 🌈:" + nCards[5];

  return message;
}

function generateCard() {
  const calling = Math.floor((Math.random() * 10) % 7);
  // console.log(calling);
  return calling;
}

function pickCard(player) {
  if (prompt(player + " pick the next card raa....", "✅") === "✅") {
    return generateCard();
  }
  console.log("(press enter to continue)");
  return pickCard(player);
}

function isBombExploded(card) {
  return card === 3; 
}

function displayPickedCard(card, player) {
  switch (card) {
    case 0 :
      return "\n" + player + " you picked diffuse\n";
    case 1 :
      return "\n" + player + " you picked TACOCAT 🌮🌮\n";
    case 2 :
      return "\n" + player + " you picked GODCAT 🐱🐱\n";
    case 3 :
      return "\nOH NOOO....." + player + " you picked a BOMB CARD 💣💣💣💥💥💥\n";
    case 4 :
      return "\n" + player + " you picked CATERMELON 🍉🍉\n";
    case 5 :
      return "\n" + player + " you picked HAIRY POTATOCAT 🥔🥔\n";
    case 6 :
      return "\n" + player + " you picked RAINBOWCAT 🌈🌈\n";
  }
}

function sliceIfInRange(text , currentIndex, endIndex) {
  if (currentIndex > endIndex) {
    return ""; 
  }

  return text[currentIndex] + slice(text, currentIndex + 1, endIndex);
}

function slice(text, start, end) {
  const startIndex = start < 0 ? 0 : start;
  const endIndex = text.length <= end ? text.length - 1 : end;

  return sliceIfInRange(text, startIndex, endIndex);
}

function updateCards(isBomb, cards, lastPickedCard) {
  if (isBomb) {
    if (cards[0] === "0") {
    return slice(cards, 1, cards.length);
    }
    return "GAME OVER";
  }
  return cards + lastPickedCard;
}

function findAndReplace(cards, targetIndex) {
  if (targetIndex === 10) {
    return cards;
  }

  console.log(cards);
  let replaced = sliceIfInRange(cards, 0, targetIndex - 1);
  replaced = replaced + "n"
  return replaced + sliceIfInRange(cards, targetIndex + 1, cards.length);
}

function indexOfReplace(cards, target) {
  for (let index = 0; index < cards.length; index++) {
    if (cards[index] === target) {
      return ("" + index) + target;
    }
  }

  const nextCard = "" + generateCard();
  return indexOfReplace(cards, nextCard);
}

function PlayerTurn(playerCards, player, PCard) {
  let cards = playerCards;
  // console.log("pCard = ", PCard);
  console.log(displayPickedCard(PCard, player));
  const isBomb = isBombExploded(PCard);
  const currentCards = updateCards(isBomb, cards, PCard);

  console.log(displayCards(currentCards, player));
  return currentCards;
}

function startPicking(player1Cards, player2Cards, player1, player2, deck) {
  let deckOfCards = deck;

  let cardOf1 = pickCard(player1);
  const cardOf1IndexAndcard = indexOfReplace(deckOfCards, "" + cardOf1);
  const indexOf1 = cardOf1IndexAndcard[0];
  const cardNumberOf1 = cardOf1IndexAndcard[1];
  deckOfCards = findAndReplace(deck, +indexOf1);

  let currentCardsOf1 = PlayerTurn(player1Cards, player1, +cardNumberOf1);
  // console.log("P1" + currentCardsOf1);

  if (currentCardsOf1 === "GAME OVER") {
    return player2 + "WON THE MATCH\n congratulationsssss🥳🥳🥳🥳🥳🥳🥳";
  }
  
  const cardOf2 = pickCard(player2);
  const cardOf2IndexAndcard = indexOfReplace(deckOfCards, "" + cardOf2);
  const indexOf2 = cardOf2IndexAndcard[0];
  const cardNumberOf2 = cardOf2IndexAndcard[1];
  deckOfCards = findAndReplace(deckOfCards, +indexOf2);

  let currentCardsOf2 = PlayerTurn(player2Cards, player2, +cardNumberOf2);
  // console.log("P2" + currentCardsOf1)
  if (currentCardsOf2 === "GAME OVER") {
    return player1 + " WON THE MATCH\n congratulationsssss🥳🥳🥳🥳🥳🥳🥳";
  }
  
  return startPicking(currentCardsOf1, currentCardsOf2, player1, player2, deckOfCards);
}

const player1 = takeName(1);
const player2 = takeName(2);
const p1Cards = [1, 0, 0, 0, 0, 0];
const p2Cards = [1, 0, 0, 0, 0, 0];


console.log(displayCards(p1Cards, player1));
console.log(displayCards(p2Cards, player2));
console.log(startPicking("0", "0", player1, player2, "n0111122223444455556666"));
console.log(startPicking("0", "0", player1, player2, "n0111122223444455556666"));