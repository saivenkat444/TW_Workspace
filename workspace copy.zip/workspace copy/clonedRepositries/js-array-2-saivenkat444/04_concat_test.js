import * as Assertion from "jsr:@std/assert";
import { concat } from "./04_concat.js";

Deno.test("concating regular arrays", () =>
  Assertion.assertEquals(concat([1, 2, 3], [4, 5, 6]), [1, 2, 3, 4, 5, 6])
);
Deno.test("concating empty arrays", () =>
  Assertion.assertEquals(concat([], []), [])
);
Deno.test("concating one element with empty array arrays", () =>
  Assertion.assertEquals(concat([1], []), [1])
);
Deno.test("concating two single element arrays", () =>
  Assertion.assertEquals(concat([1], [1]), [1, 1])
);
