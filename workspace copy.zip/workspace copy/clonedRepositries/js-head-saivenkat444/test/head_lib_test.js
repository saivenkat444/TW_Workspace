import { afterEach, beforeEach, describe, it } from "jsr:@std/testing/bdd";
import { assertEquals } from "jsr:@std/assert";
import { head } from "../src/head_lib.js";

const oldProperty = Deno.readTextFileSync;

const testingFiles = {
  "tenLines.txt": "1\n2\n3\n4\n5\n6\n7\n8\n9\n10",
  "fiveLines.txt": "1\n2\n3\n4\n5",
  "twentyLines.txt":
    "1\n2\n3\n4\n5\n6\n7\n8\n9\n10\n11\n12\n13\n14\n15\n16\n17\n18\n19\n20",
  "emptyFile.txt": "",
  "charFile.txt": "sai1\nsai2\nsai3\nsai4\nsai5\nsai6\nsai7\nsai8\nsai9\nsai10",
};

describe("head(count, filePath, separator) for n option ", () => {
  beforeEach(() => {
    Deno.readTextFileSync = (filePath) => {
      if (testingFiles[filePath] !== undefined) {
        return testingFiles[filePath];
      }
      throw "error";
    };
  });

  afterEach(() => {
    Deno.readTextFileSync = oldProperty;
  });

  it("should give content, when there is a single file", () => {
    const actual = head({
      option: "n",
      count: 10,
      filepaths: ["tenLines.txt"],
      isError: false,
    });
    const expected = [
      {
        fileName: "tenLines.txt",
        content: "1\n2\n3\n4\n5\n6\n7\n8\n9\n10",
      },
    ];
    assertEquals(actual, expected);
  });

  it("should give content, when there are multiple valid files", () => {
    const actual = head({
      option: "n",
      count: 10,
      filepaths: ["tenLines.txt", "fiveLines.txt"],
      isError: false,
    });
    const expected = [
      {
        fileName: "tenLines.txt",
        content: "1\n2\n3\n4\n5\n6\n7\n8\n9\n10",
      },
      { fileName: "fiveLines.txt", content: "1\n2\n3\n4\n5" },
    ];
    assertEquals(actual, expected);
  });

  it("should give error when invalid file is only given", () => {
    const actual = head({
      option: "n",
      count: 10,
      filepaths: ["tenlines.txt"],
      isError: false,
    });
    const expected = [
      { type: "invalid file", token: "tenlines.txt", isError: true },
    ];
    assertEquals(actual, expected);
  });

  it("should give error for invalid file and content for the valid files when there is an invalid file in multiple files", () => {
    const actual = head({
      option: "n",
      count: 10,
      filepaths: ["tenLines.txt", "fivelines.txt", "fiveLines.txt"],
      isError: false,
    });
    const expected = [
      {
        fileName: "tenLines.txt",
        content: "1\n2\n3\n4\n5\n6\n7\n8\n9\n10",
      },
      { type: "invalid file", token: "fivelines.txt", isError: true },
      { fileName: "fiveLines.txt", content: "1\n2\n3\n4\n5" },
    ];
    assertEquals(actual, expected);
  });

  it("should give error when an invalid option error is given to the head", () => {
    const actual = head({
      type: "invalid option",
      token: "something",
      isError: true,
    });
    const expected = [
      { type: "invalid option", token: "something", isError: true },
    ];
    assertEquals(actual, expected);
  });
  it("hould give error when an invalid count error is given to the head", () => {
    const actual = head({
      type: "invalid count",
      token: "something",
      isError: true,
    });
    const expected = [
      { type: "invalid count", token: "something", isError: true },
    ];
    assertEquals(actual, expected);
  });
});
