import { createDetails } from "jsr:@std/internal@^1.0.5/diff-str";
import { ballByBall } from "./data/match_1.js";
import { generateScoreCard } from "./src/scorecard.js";
import { batter, bowler, team } from "./src/templates.js";

const giveDismissalMessage = (dismissal) => {
  if (dismissal?.kind) {
    return {
      caught: `c ${dismissal.fielders} b ${dismissal.bowler}`,
      bowled: `b ${dismissal.bowler}`,
      "run out": `c ${dismissal.fielders}`,
    }[dismissal.kind];
  }

  return "not out";
};

const main = (ballByBall) => {
  return generateScoreCard(ballByBall);
};

const batsManStats = (inningsData) => (batsman) => {
  const playerData = inningsData[batsman];
  return `${playerData.name}, ${giveDismissalMessage(playerData.dismissal)}, ${
    playerData.runs
  }, ${playerData.balls}, ${playerData.fours}, ${playerData.sixes}`;
};

const bowlerManStats = (inningsData) => (bowler) => {
  const playerData = inningsData[bowler];
  return `${playerData.name}, ${playerData.overs}, ${playerData.runsgiven}, ${playerData.wicketsTaken}`;
};

const createScoreForBatters = (inningsData) => {
  const batters = Object.keys(inningsData);
  const batterStat = batsManStats(inningsData);
  const battingDetails = batters.map(batterStat);
  return `Batter,Dismissal,Runs,Balls,4s,6s
${battingDetails.join("\n")}
---`;
};

const createScoreForBowlers = (inningsData) => {
  const bowlers = Object.keys(inningsData);
  const bowlerStat = bowlerManStats(inningsData);
  const bowlingDetails = bowlers.map(bowlerStat);
  return `Bowler,O,R,W
${bowlingDetails.join("\n")}
---`;
};

const printScoreCard = (inningsData) => {
  const teamTotal = `Team,Total,Wickets
${inningsData[0].teamName},${inningsData[0].runs},${inningsData[0].wicketsTaken}
---`;
  const batters = createScoreForBatters(inningsData[1]);
  const extras = `Noballs,Wides,Legbyes,Byes
${inningsData[0].extras.noball}, ${inningsData[0].extras.wides}, ${inningsData[0].extras.legbyes}, ${inningsData[0].extras.byes}
---`;
  const bowlers = createScoreForBowlers(inningsData[2]);
  console.log(`${teamTotal}
${batters}
${extras}
${bowlers}`);
};

const dataSeparated = main(ballByBall);
dataSeparated.forEach((element) => {
  printScoreCard(element);
});
