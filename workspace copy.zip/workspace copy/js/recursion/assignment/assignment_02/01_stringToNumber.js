function convertingToNumber(string, index, assignSign) {
  if (index === 0 || (assignSign === -1 && index === 1)) {
    return (string[index] * 1); 
  }

  const currentNum = string[index] * 1;
  
  return currentNum + (10 * convertingToNumber(string, index - 1, assignSign));
}

function stringToNumber(string) {
  const assignSign = string[0] === "-" ? -1 : 1;

  return assignSign * convertingToNumber(string, string.length - 1, assignSign);
}

function makeMessage(string, expected, actual) {
  let message = "the string " + string;
  
  message = message + " expected to be " + expected;
  message = message + " and it is " + actual; 

  return message;
}

function testStringToNumber(string, expected) {
  const actual = stringToNumber(string);
  const getMark  = actual === expected ? '✅' : '❌';
  
  console.log(getMark + makeMessage(string, expected, actual));
}

function testAll() {
  testStringToNumber("123", 123);
  testStringToNumber("-123", -123);
  // testStrigToNumber("hello world", "z", -1);
  // testStrigToNumber("hello world", "", -1);
  // testStrigToNumber("MOM", "", -1);
  // testStrigToNumber("MOM", " ", -1);
  // testStrigToNumber("MOMO", "O", 3);
}

testAll();