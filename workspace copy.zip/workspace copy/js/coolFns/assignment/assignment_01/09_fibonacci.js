// Write a function that gives first n elements of fibonacci in an array
// fibonacci(5) => [0, 1, 1, 2, 3]
// do not modify input parameters   
function fibonacci(n) {
  let previous = -1;
  let next = 1;
  let result = 0;
  const fibonacciSeries = [];

  for (let terms = 0; terms < n; terms++) {
    fibonacciSeries[terms] = previous + next;
    result = previous + next;
    previous = next;
    next = result;
  }

  return fibonacciSeries;
}

function makeMessage(terms, expected, actual) {
  let message = "the fibonaci series upto: '" + terms;

  message = message + "' are '" + expected;
  message = message + "' and it is '" + actual + "'";

  return message;
}

function areEqual(array1, array2) {
  if (array1.length !== array2.length) {
    return false;
  }

  for (let index = 0; index < array1.length; index++) {
    if (array1[index] !== array2[index]) {
      return false;
    }
  }

  return true;
}

function testFibonacci(terms, expected) {
  const actual = fibonacci(terms);
  const getMark = areEqual(actual, expected) ? '✅' : '❌';

  console.log(getMark + makeMessage(terms, expected, actual));
}

function testAll() {
  testFibonacci(1, [0]);
  testFibonacci(2, [0, 1]);
  testFibonacci(3, [0, 1, 1]);
  testFibonacci(4, [0, 1, 1, 2]);
  testFibonacci(5, [0, 1, 1, 2, 3]);
  testFibonacci(6, [0, 1, 1, 2, 3, 5]);
  testFibonacci(7, [0, 1, 1, 2, 3, 5, 8]);
}

testAll();