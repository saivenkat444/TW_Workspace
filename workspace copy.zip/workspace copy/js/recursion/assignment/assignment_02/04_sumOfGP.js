function compoundInterest(a, r, n) {
  if (n < 1) {
    return 0;
  }
  
  const nthTerm = a;

  return nthTerm + compoundInterest(a * r, r, n - 1);
}

function makeMessage(terms, expected, actual) {
  let message = "the sum upto " + terms + " terms is";
  
  message = message + " expected to be " + expected;
  message = message + " and it is " + actual;

  return message;
}

function testCompoundInterest(a, r, n, expected) {
  const actual = compoundInterest(a, r, n);
  const getMark  = actual === expected ? '✅' : '❌';
  
  console.log(getMark + makeMessage(n, expected, actual));
}

function testAll() {
  testCompoundInterest(1, 2, 10, 1023);
  testCompoundInterest(0, 2, 10, 0);
  testCompoundInterest(1, 0, 10, 1);
  testCompoundInterest(1, 2, 0, 0);
}

testAll();