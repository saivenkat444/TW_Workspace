// numbers greter than 5
// [1, 2, 3, 8, 9, 10]
const numbersGreaterThan5 = (array) => array.filter((number) => number > 5);

// console.log(numbersGreaterThan5([1, 2, 3, 8, 9, 10]));

// write a fucntion that gives the sum of odd numbers in the array
// [1, 2, 3, 4, 5, 6, 7]

export const isOdd = (number) => number % 2 === 1;

const addNumbersIfOdd = (sum, number) => (isOdd(number) ? sum + number : sum);

// const sumOfOdds = (numbers) => numbers.reduce(addNumbersIfOdd, 0);

const sumOfOdds = function (numbers) {
  const odds = numbers.filter(isOdd);
  return odds.reduce((sum, element) => sum + element, 0);
};

// console.log(sumOfOdds([1, 2, 3, 4, 5, 6, 7]));
