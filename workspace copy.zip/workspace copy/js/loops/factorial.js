let num= 5;
let factorial=1
for(num;num>0;num--){
    factorial=factorial*num
}
console.log(factorial)