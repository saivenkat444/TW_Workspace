  const calculateElapsedTime = (startTime) => {
    return ((Date.now() - startTime) / 1000).toFixed(2);
  };

  const updateOrderField = ({ orderRecord, key, keyValue }) => {
    const updatedOrder = { ...orderRecord };
    updatedOrder[key] = keyValue;
    return updatedOrder;
  };

  const displayOrderStatus = (startTime, message, orderDetails = "") => {
    console.log(`[${calculateElapsedTime(startTime)}]`, message, orderDetails);
  };

  const processOrderStep =
    (begin, timeNeeded, next, startTime) => (orderStepDetails, message) => {
      begin();
      setTimeout(() => {
        const updatedOrder = updateOrderField(orderStepDetails);
        displayOrderStatus(startTime, message, updatedOrder);
        next(updatedOrder);
      }, timeNeeded);
    };

  const deliverOrder = (startTime, orderDetails) => {
    processOrderStep(
      () => displayOrderStatus(startTime, "Delivering order..."),
      5000,
      () => {},
      startTime
    )(
      {
        orderRecord: orderDetails,
        key: "deliveryDetails",
        keyValue: "delivered by john at 7:30 PM",
      },
      "order delivered: "
    );
  };

  const packOrder = (startTime, orderDetails) => {
    processOrderStep(
      () => displayOrderStatus(startTime, "Packing order..."),
      2000,
      (updatedOrder) => deliverOrder(startTime, updatedOrder),
      startTime
    )(
      {
        orderRecord: orderDetails,
        key: "packageDetails",
        keyValue: "packed in eco-friendly box",
      },
      "order packed: "
    );
  };

  const prepareFood = (startTime, orderDetails) => {
    //prepareFood
    // Preparing food ...
    processOrderStep(
      () => displayOrderStatus(startTime, "preparing food..."),
      3000,
      (updatedOrder) => packOrder(startTime, updatedOrder),
      startTime
    )(
      {
        orderRecord: orderDetails,
        key: "foodDetails",
        keyValue: "Burger & fries",
      },
      "food is ready: "
    );
  };

  const placeOrder = () => {
    return { startTime: Date.now(), orderId: 123 };
  };

  const trackOrder = () => {
    const { startTime, orderId } = placeOrder();
    displayOrderStatus(startTime, "order received: ", { orderId });
    prepareFood(startTime, { orderId });
  };

  trackOrder();
