let x = 9;

console.log(x);
console.log(x++);
console.log(++x);
