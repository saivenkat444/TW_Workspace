function targetIndex(string, char, index) {
  if (index >= string.length) {
    return -1;
  }

  if (string[index] === char) {
    return index;
  }

  return targetIndex(string, char, index + 1);
}

function findIndex(string, char) {
  return targetIndex(string, char, 0);
}

function makeMessage(string, expected, actual) {
  let message = "the index of " + string;
  
  message = message + " expected to be " + expected;
  message = message + " and it is " + actual;

  return message;
}

function testFindIndex(string, char, expected) {
  const actual = findIndex(string, char);
  const getMark  = actual === expected ? '✅' : '❌';
  
  console.log(getMark + makeMessage(char, expected, actual));
}

function testAll() {
  testFindIndex("MOM", "M", 0);
  testFindIndex("hello world", "z", -1);
  testFindIndex("hello world", "", -1);
  testFindIndex("MOM", "", -1);
  testFindIndex("MOM", " ", -1);
  testFindIndex("MOM", "O", 1);
}

testAll();