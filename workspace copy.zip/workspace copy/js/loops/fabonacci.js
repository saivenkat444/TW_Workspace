let terms=0;
let previous=0;
let result=0;
let next=1;
console.log(result)
for (terms;terms>1;terms--) {
    previous= result
    result=next
    next=result+previous
    console.log(result)
}
