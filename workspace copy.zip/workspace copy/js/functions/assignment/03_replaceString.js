/*
  Implement the below function 
  that replaces a character `match` with another character `replacement`
  in a given text and returns a new string.

  Examples:
    replace('hello world', 'l', 'n') => 'henno world'
    replace('no spaces in here', ' ', '_') => 'no_spaces_in_here'
    replace('', 'd', 'e') => ''

  **Your function must return a value**

  It's not necessary to print the result on screen, 
  however to test your function you are free to print the result
*/

function getNextCharacter(replacement, currentCharachter, target) {
  return currentCharachter === target ? replacement : currentCharachter;
}

function replace(text, match, replacement) {
  let resultString = "";

  for (let index = 0; index < text.length; index++) {
    const nextcharacter = getNextCharacter(replacement, text[index], match);
    resultString = resultString + nextcharacter;
  }

  return resultString;
}

function message(text, expect, evaluatingTo) {
  const isPassing = evaluatingTo === expect ? "✅" : "❌";

  const context = " the string " + text;
  const expected = " should be " + expect;
  const actual = " but it is " + evaluatingTo;

  return isPassing + context + expected + actual;
}

function testReplace(text, match, replacement, expect) {
  const evaluatingTo = replace(text, match, replacement);
  console.log(message(text, expect, evaluatingTo));
}

function testCases(){
testReplace("hello", "h", "d", "dello");
testReplace("hello", "o", "p", "hellp");
testReplace(" ", " ", "d", "d");
testReplace("", "d", "e", "");
}

testCases();