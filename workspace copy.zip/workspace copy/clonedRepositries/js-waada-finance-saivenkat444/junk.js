const parseTransactions = (fileTransactions) =>
  fileTransactions.split("\n").map(Number);

const parseCustomers = (text) => {
  const allCustomers = text.split("\n");
  const data = allCustomers.reduce((result, customer) => {
    const [name, ...filePaths] = customer.split(",");
    return { ...result, [name]: { name, filePaths } };
  }, {});
  return data;
};

const sum = (a, b) => a + b;

const generateBalanceAndCount = (fileTransactions) => {
  const totalTransactions = fileTransactions.length;
  const balance = fileTransactions.reduce(sum, 0);
  return { totalTransactions, balance };
};

const generateSummaryForFile = (file) => {
  return Deno.readTextFile(file)
    .then(parseTransactions)
    .then(generateBalanceAndCount);
};

const summer = (total, transaction) => {
  const totalTransactions =
    total.totalTransactions + transaction.totalTransactions;
  const balance = total.balance + transaction.balance;

  return { totalTransactions, balance };
};

const generateTransactionSummary = ({ name, filePaths }) => {
  const dataValue = filePaths.map(generateSummaryForFile);
  return Promise.all(dataValue);
};

const generateFinanceTransactionSummary = (parsedCustomers) => {
  const customers = Object.keys(parsedCustomers);
  const result = {};
  customers.forEach((name) => {
    result[name] = {
      name: name,
      data: generateTransactionSummary(parsedCustomers[name]),
    };
  });
  return result;
};

const convertToCSV = (allSummary) => {
  return allSummary
    .map(({ name, totalTransactions, balance }) => {
      return [name, totalTransactions, balance].join(",");
    })
    .join("\n");
};

const pushToCSV = (allTransactionsData) => {
  Deno.writeTextFile("./results.csv", allTransactionsData);
};

const loadIntoFile = (alltransactionSummaries) => {
  Promise.all(alltransactionSummaries).then(convertToCSV).then(pushToCSV);
};

const summarizeAlltransactions = (parsedCustomers) => {
  console.log(parsedCustomers)
  const customers = Object.keys(parsedCustomers);
  const result = {};
  customers.forEach((name) => {
    result[name] = { name, data: parsedCustomers[name].data };
  });

  return result;
  // return Promise.all(data).then((allTransactions) => {
  //   const finalSummary = allTransactions.reduce(summer, {
  //     totalTransactions: 0,
  //     balance: 0,
  //   });
  //   return { name, ...finalSummary };
  // });
};

const summarizeAllCustomersTransactions = (allCustomersData) =>
  allCustomersData.map(summarizeAlltransactions);

const main = () => {
  Deno.readTextFile("./data/small_data/customers.csv")
    .then(parseCustomers)
    .then(generateFinanceTransactionSummary) //handle customers
    // .then(console.log);
    .then(summarizeAlltransactions)
    .then(console.log);
  // .then(loadIntoFile);
};
main();

// customers.csv data => {name: {name: "", files: []}}
//

//function names
//extract mapper
//split lines into parse
