import * as Assertion from "jsr:@std/assert";
import { isOdd } from "./new.js";

const testingFunction = (number, expected) => () =>
  Assertion.assertEquals(isOdd(number), expected);

// Deno.test("isodd", testingFunction(3, true));
// Deno.test("isodd", testingFunction(2, true));
// Deno.test("isodd", testingFunction(2, false));
// Deno.test("testing", () => Assertion.assertEquals(2, 3));
// Assertion.assertEquals(10, 10);
// console.log(testingFunction(2, true));
// Deno.test("testing array includes", () =>
//   Assertion.assertArrayIncludes([2, 4], 3)
// );

Deno.test("testing aassert", () => Assertion.assertEquals(2, [2]));
