the case should be specific and the test descritpion should specify the group of the test case and use comma as a separator for specifying the things

write test cases for the small functions as well in print also 
write test cases for fetch content also 


revisit the use case of try catch block
use of try catch is poor 
use try catch where we expect an error

formatting in a markdown 
plug in and extensions (review)
in the test cases use a separator for clarifying your input and output
plug in tail 
wire up the tail functionalities
handle the error objects with a default syntax
type and token is not making sense(feeling incomplete)

teh use of try catch in parse args
the print is not representing its own thing (not rich enough)



error object (one key to represent the error);
error message format and content can be done better (make it more readable)
for displaying the outputs, console is an object and it can be called using a key makes it more simple
try to return exit codes for the display function 
for numbers you can use Number instead of explicitly saying +




