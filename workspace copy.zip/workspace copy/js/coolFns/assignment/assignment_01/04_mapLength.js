// Given an array containing words, return a new array containing length of
// the words.
// mapLengths(["apple", "cat", "Four"]) => [5, 3, 4]
// do not modify input parameters
function mapLengths(words) {
  const countOfLetters = [];

  for (let index = 0; index < words.length; index++) {
    countOfLetters[index] = words[index].length;
  }

  return countOfLetters;
}

function makeMessage(array, expected, actual) {
  let message = "the length of words in the array: '" + array;

  message = message + "' are '" + expected;
  message = message + "' and it is '" + actual + "'";

  return message;
}

function areEqual(array1, array2) {
  if (array1.length !== array2.length) {
    return false;
  }

  for (let index = 0; index < array1.length; index++) {
    if (array1[index] !== array2[index]) {
      return false;
    }
  }

  return true;
}

function testmapLengths(array, expected) {
  const actual = mapLengths(array);
  const getMark = areEqual(actual, expected) ? '✅' : '❌';

  console.log(getMark + makeMessage(array, expected, actual));
}

function testAll() {
  testmapLengths([], []);
  testmapLengths(["aakash", "sai"], [6, 3]);
  testmapLengths(["aakash", ""], [6, 0]);
  testmapLengths(["aakash", " "], [6, 1]);
  testmapLengths(["one", "two"], [3, 3]);
  testmapLengths(["1", "1"], [1, 1]);
}

testAll();