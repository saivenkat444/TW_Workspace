let x = 0;
let y = 0;
const instruction = 332331;

let command = instruction;
let reversed = 0;
let heading = 0;

while(command > 0){
    reversed = (reversed * 10) + command % 10;
    command = (command - command % 10)/10;
}
console.log(reversed);

while (reversed > 0){
    let last = reversed % 10;
    reversed = (reversed - last) / 10;
    if (last === 1){
        heading = heading - 1;
        if (heading === 4 || heading === -4){
            heading = 0;
        }
    }
    if (last === 2){
        heading = heading + 1;
        if (heading === 4 || heading === -4){
            heading = 0;
        }
    }
    if (last === 3){
        if (heading === 0){
            //move north
            y = y + 1;
        }
        if (heading === 1){
            //move east
            x = x + 1;
        }
        if (heading === 2){
            //move south
            y = y - 1;
        }
        if (heading === 3){
            //move west
            x = x - 1;
        }
    }
    if (heading === -1){
        heading = 3;
    }
    if (heading === -2){
        heading = 2;
    }
    if (heading === -3){
        heading = 1;
    }
}

console.log(x,y,heading);