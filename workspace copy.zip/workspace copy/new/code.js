const code = `function add(a, b) {
  return a + b;
}
function something(a) {
  return something
  }
}`;

const arrayOfLines = code.split("\n");

const linesWithFunctions = arrayOfLines.filter((line) =>
  line.match(/function \w+/)
);

// console.log(linesWithFunctions);
const functionNames = linesWithFunctions.map((line) => line.match(/ \w+/));
console.log(functionNames);
