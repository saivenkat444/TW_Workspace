// Do not rename minefield, use it as input for your program.
const minefield = "---*\n---*\n*---\n-*--";

// Clear the mines one by one, always choosing the mine closest to the top left hand corner
// See the README for more details
// START YOUR CODE AFTER THIS LINE. DO NOT REMOVE THIS LINE
//input
//  0123
//0 -*--
//1 ---*
//2 *---
//3 -*--
//output
//0 -+--
//1 ---+
//2 +---
//3 -+--
let copyOfDefusedBomb = minefield;
let noOfBomb = 0;
let positionIndicator = 0;
while (positionIndicator < copyOfDefusedBomb.length) {
    if (copyOfDefusedBomb[positionIndicator] === "*") {
        noOfBomb++;
    }
    positionIndicator++;
}

while (noOfBomb > 0) {
    let x = 0;
    let bomb = "";
    let y = 0;
    let X = "";
    let Y = "";
    for (let index = 0; index < copyOfDefusedBomb.length; index++) {
        if (copyOfDefusedBomb[index] === "*") {
            const location = x + y;
            bomb = bomb + location;
            //bomb = bomb + " ";
            X = X + x;
            Y = Y + y;
            y++;
        }
        if (copyOfDefusedBomb[index] === "\n") {
            x++;
            y = 0;
        }
        else {
            y++;
        }
    }
    // console.log(bomb);
    // console.log(X);
    // console.log(Y);
    let positionOfBomb = 0;
    let closest = bomb[positionOfBomb];
    let target = 0;
    for (; positionOfBomb < bomb.length; positionOfBomb++) {
        if (bomb[positionOfBomb] < closest) {
            closest = bomb[positionOfBomb];
            target = positionOfBomb;
        }
    }
    // console.log(closest,target);
    //console.log(X[target], Y[target]);
    //console.log(noOfBomb);
    let newX = 0;
    let newY = 0;
    let defusedBomb = "";

    for (let newIndex = 0; newIndex < copyOfDefusedBomb.length; newIndex++) {
        if (newX == X[target] && newY == Y[target]) {
            defusedBomb += "+";
            newY++;
            continue;
        }
        else if (copyOfDefusedBomb[newIndex] === "\n") {
            newY = 0;
            newX++;
        }
        else {
            newY++;
        }
        defusedBomb += copyOfDefusedBomb[newIndex];
        //console.log(newX, newY);
    }

    console.log(defusedBomb, "\n");
    --noOfBomb;

    copyOfDefusedBomb = defusedBomb;
}







