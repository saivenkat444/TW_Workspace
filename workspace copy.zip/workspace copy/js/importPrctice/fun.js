import data from "./stillFun.json" with {type: "json"}

console.log(data);

// const something = JSON.parse(data)
// const number = "hi hello";
// const nothing = JSON.parse(number);
// const anything = JSON.stringify(number);
// console.log(something);