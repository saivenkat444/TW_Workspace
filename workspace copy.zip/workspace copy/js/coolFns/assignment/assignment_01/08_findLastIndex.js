// Given an array of numbers and a element, return the last index in the array
// where element is present else -1
// findLastIndex(["apple", "cake", "tea", "coffee", "tea", "pen"], "tea") => 4
// do not modify input parameters
function findLastIndex(array, element) {
  for (let index = array.length - 1; index > -1; index--) {
    if (array[index] === element) {
      return index;
    }
  }

  return -1;
}

function makeMessage(array, expected, actual) {
  let message = "the last index of element in the array: '" + array;

  message = message + "' are '" + expected;
  message = message + "' and it is '" + actual + "'";

  return message;
}

function areEqual(array1, array2) {
  if (array1.length !== array2.length) {
    return false;
  }

  for (let index = 0; index < array1.length; index++) {
    if (array1[index] !== array2[index]) {
      return false;
    }
  }

  return true;
}

function testFindLastIndex(array, element, expected) {
  const actual = findLastIndex(array, element);
  const getMark = areEqual(actual, expected) ? '✅' : '❌';

  console.log(getMark + makeMessage(array, element, expected, actual));
}

function testAll() {
  testFindLastIndex(["apple", "cake", "tea", "coffee"], "tea", 2);
  testFindLastIndex(["apple", "cake", "tea", "coffee", "tea"], "milk", -1);
  testFindLastIndex(["apple", "cake", "tea", "coffee", "tea"], "tea", 4);
  testFindLastIndex(["apple", "cake", "tea", "coffee", "teaPowder"], "tea", 2);
  testFindLastIndex(["apple", "cake", "teaPowder", "coffee", "tea"], "tea", 4);
  testFindLastIndex([1, 2, 3, 4, 6, 7, 8, 9, 5, 1, 2, 3, 5], 5, 12);
}

testAll();