// Given an array of numbers and a threshold value, return a new array
// that contains all the numbers above the threshold.
// filterAbove([6, 2, 3, 1, 4, 7], 3) => [6, 4, 7]
// filterAbove([1, 2, 3], 4) => []
// do not modify input parameters
function filterAbove(array, threshold) {
  const filteredAbove = [];
  for (let index = 0; index < array.length; index++) {
    if (array[index] > threshold) {
      filteredAbove[filteredAbove.length] = array[index];
    }
  }

  return filteredAbove;
}

function makeMessage(array, expected, actual) {
  let message = "the numbers above the threshold: '" + array;

  message = message + "' are '" + expected;
  message = message + "' and it is '" + actual + "'";

  return message;
}

function areEqual(array1, array2) {
  if (array1.length !== array2.length) {
    return false;
  }

  for (let index = 0; index < array1.length; index++) {
    if (array1[index] !== array2[index]) {
      return false;
    }
  }

  return true;
}

function testFilterAbove(array, threshold, expected) {
  const actual = filterAbove(array, threshold);
  const getMark = areEqual(actual, expected) ? '✅' : '❌';

  console.log(getMark + makeMessage(array, threshold, expected, actual));
}

function testAll() {
  testFilterAbove([6, 2, 3, 1, 4, 7], 3, [6, 4, 7]);
  testFilterAbove([1, 2, 3], 4, []);
  testFilterAbove([1, 2, 3, 4, 5], 5, []);
  testFilterAbove([1, 2, 3, 4, 5], 0, [1, 2, 3, 4, 5]);
}

testAll();