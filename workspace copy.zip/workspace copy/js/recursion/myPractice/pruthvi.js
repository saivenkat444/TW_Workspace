function isEven(n) {
  if (n < 0) {
    return false;
  }

  return n - isEven(n - 2);
  
}