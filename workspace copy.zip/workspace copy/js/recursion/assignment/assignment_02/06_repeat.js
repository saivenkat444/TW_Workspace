function repeat(string, n) {
  if (n === 0) {
    return "";
  } 

  return string + repeat (string, n - 1);
}

function makeMessage(string, times, expected, actual) {
  let message = "the string '" + string + "' repeated " + times;
  
  message = message + " times is expected to be '" + expected;
  message = message + "' and it is '" + actual + "'";

  return message;
}

function testRepeatString(string, times, expected) {
  const actual = repeat(string, times);
  const getMark  = actual === expected ? '✅' : '❌';
  
  console.log(getMark + makeMessage(string, times, expected, actual));
}

function testAll() {
  testRepeatString("hello", 2, "hellohello");
  testRepeatString("priyankush", 1, "priyankush");
  testRepeatString("", 1000, "");
  testRepeatString(" ", 10, "          ");
}

testAll();