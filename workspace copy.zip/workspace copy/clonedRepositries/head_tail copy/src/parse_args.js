const isOption = (candidate) => candidate.startsWith("-");

const isValidOption = (candidate) => ["-n", "-c"].includes(candidate);

const isValidCount = (candidate) => +candidate > 0;

export const parseArgs = (args) => {
  let index = 0;
  const parseArgs = { option: "n", count: 10, filepaths: [] };

  while (index < args.length) {
    if (!isOption(args[index]))
      return { output: { ...parseArgs, filepaths: args.slice(index) } };

    const option = args[index].slice(0, 2);
    if (!isValidOption(option)) {
      return { error: { type: "invalid option", token: option[1] } };
    }

    const count = args[index].length > 2 ? args[index].slice(2) : args[++index]; //can use or
    if (!isValidCount(count)) {
      return { error: { type: "invalid count", token: count } };
    }

    parseArgs.option = option[1];
    parseArgs.count = +count;
    index++;
  }

  return parseArgs;
};
