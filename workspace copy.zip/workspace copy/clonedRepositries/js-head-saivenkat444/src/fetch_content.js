import { readFile } from "./read_file.js";

export const fetchNLines = (count, content, readFromTop = true) => {
  const fileContent = content.split("\n");
  const firstLines = readFromTop
    ? fileContent.slice(0, count)
    : fileContent.slice(0 - count);
  return firstLines.join("\n");
};

export const fetchNchars = (count, content, readFromTop = true) => {
  const start = readFromTop ? 0 : Math.max(0, content.length - count);
  const end = readFromTop ? Math.min(count, content.length) : content.length;

  return content.substring(start, end);
};

const options = {
  n: fetchNLines,
  c: fetchNchars,
};

export const fetchContent = (
  optionType,
  count,
  filePath,
  readFromTop = true
) => {
  try {
    const content = readFile(filePath);
    return {
      fileName: filePath,
      content: options[optionType](count, content, readFromTop),
    };
  } catch {
    return { type: "invalid file", token: filePath, isError: true};
  }
};
