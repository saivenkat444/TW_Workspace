class Expense {
  #dollar;
  #cent;
  constructor(dollar, cents) {
    this.#dollar = dollar;
    this.#cent = cents;
  }

  static parseMoney(money) {
    const [dollar, cent] = money.split(".");
    
    return new Expense(+dollar, +cent);
  }

  #fixMoney() {
    const fixedDollar = this.#dollar + Math.floor(this.#cent / 100);
    const fixedCents = this.#cent % 100;
    return new Expense(fixedDollar, fixedCents);
  }

  add(otherExpense) {
    const dollar = this.#dollar + otherExpense.#dollar;
    const cent = this.#cent + otherExpense.#cent;
    return new Expense(dollar, cent).#fixMoney();
    return this.#fixMoney();
  }

  toString() {
    return `${this.#dollar}.${this.#cent}`;
  }
}

console.log(
  Expense.parseMoney("20.2").add(Expense.parseMoney("20.9")).toString()
);
