import { assert } from "jsr:@std/assert/assert";
import { batter } from "../src/templates.js";
import { assertEquals } from "jsr:@std/assert/equals";
import { generateScoreCard, updateBatter } from "../src/scorecard.js";

Deno.test("verify template", () => {
  const expected = {
    name: "someone",
    dismissal: "not out",
    runs: 0,
    balls: 0,
    fours: 0,
    sixes: 0,
  };
  const actual = batter();
  assertEquals(actual, expected);
});

Deno.test("update name", () => {
  const expected = {
    name: "pradeep moganti",
    dismissal: "not out",
    runs: 0,
    balls: 0,
    fours: 0,
    sixes: 0,
  };
  const ball = {
    batter: "pradeep moganti",
    bowler: "SC Ganguly",
    extras: {
      wides: 1,
    },
    non_striker: "AA Noffke",
    runs: {
      batter: 0,
      extras: 1,
      total: 1,
    },
  };
  const actual = updateBatter(batter(), ball);
  assertEquals(actual, expected);
});

Deno.test("update runs", () => {
  const expected = {
    name: "pradeep moganti",
    dismissal: "not out",
    runs: 2,
    balls: 0,
    fours: 0,
    sixes: 0,
  };
  const ball = {
    batter: "pradeep moganti",
    bowler: "SC Ganguly",
    extras: {
      wides: 1,
    },
    non_striker: "AA Noffke",
    runs: {
      batter: 2,
      extras: 1,
      total: 1,
    },
  };
  const actual = updateBatter(batter(), ball);
  assertEquals(actual, expected);
});

Deno.test("update balls", () => {
  const expected = {
    name: "pradeep moganti",
    dismissal: "not out",
    runs: 2,
    balls: 1,
    fours: 0,
    sixes: 0,
  };
  const ball = {
    batter: "pradeep moganti",
    bowler: "SC Ganguly",
    extras: {
      wides: 1,
    },
    non_striker: "AA Noffke",
    runs: {
      batter: 2,
      extras: 1,
      total: 1,
    },
  };
  const actual = updateBatter(batter(), ball);
  assertEquals(actual, expected);
});

