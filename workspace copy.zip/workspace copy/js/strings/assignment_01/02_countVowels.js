// Do not rename string, use it as input for your program.
// While testing we will change it's value.
const string = 'aeioA';
// Print the number of vowles in given string. Consider case sensitivity.
// If string = "abcdefghi" then output should be 3
// START YOUR CODE AFTER THIS LINE. DO NOT REMOVE THIS LINE

let index = 0;
let output = 0;

for (let lengthOfString = string.length; lengthOfString > 0; lengthOfString--) {
    const testIfVowel = string[index];
    if (testIfVowel === "a" || testIfVowel === "e" || testIfVowel === "i" || testIfVowel === "o" || testIfVowel === "u") {
        output = output + 1;
    }

    if (testIfVowel === "A" || testIfVowel === "E" || testIfVowel === "I" || testIfVowel === "O" || testIfVowel === "U") {
        output = output + 1;
    }

    index = index + 1;
}

console.log(output);