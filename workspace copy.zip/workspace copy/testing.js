./js/import_passage/js-import-export-saivenkat444/README.md:- Create a `answers.js` which when we run using `[01;31m[Kdeno[m[K run answers.js` should give answer for all the questions.
./js/recursion/assignment/assignment_01/05_firstPrimeAbove.js:function isDivisible(numerator, [01;31m[Kdeno[m[Kminator) {
./js/recursion/assignment/assignment_01/05_firstPrimeAbove.js:  return numerator % [01;31m[Kdeno[m[Kminator === 0;
./js/functions/assignment/02_leapYear.js:function divisibleWith (numerator, [01;31m[Kdeno[m[Kminator) {
./js/functions/assignment/02_leapYear.js:  return numerator % [01;31m[Kdeno[m[Kminator === 0;
./js/functions/assignment/08_firstPrimeAbove.js:function isDivisible(numerator, [01;31m[Kdeno[m[Kminator) {
./js/functions/assignment/08_firstPrimeAbove.js:  return numerator % [01;31m[Kdeno[m[Kminator === 0;
./js/functions/.vscode/settings.json:  "[01;31m[Kdeno[m[K.enable": true
./clonedRepositries/truchet/README.md:- [Deno](https://[01;31m[Kdeno[m[K.land/) (JavaScript and TypeScript runtime).
./clonedRepositries/truchet/README.md:   [01;31m[Kdeno[m[K run --allow-read truchetMain.js <width> <height>
./clonedRepositries/truchet/README.md:[01;31m[Kdeno[m[K truchetMain.js 4 4
./clonedRepositries/js-mul-saivenkat444/.vscode/settings.json:  "[01;31m[Kdeno[m[K.enable": true
./clonedRepositries/js-array-2-saivenkat444/.vscode/settings.json:  "[01;31m[Kdeno[m[K.enable": true
./clonedRepositries/js-scorecard-saivenkat444/.vscode/settings.json:  "[01;31m[Kdeno[m[K.enable": true
./new/.vscode/settings.json:  "[01;31m[Kdeno[m[K.enable": true
