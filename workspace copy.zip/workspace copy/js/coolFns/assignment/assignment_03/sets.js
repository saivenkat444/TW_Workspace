function clone(array) {
  const copyOfArray = [];

  for (let index = 0; index < array.length; index++) {
    copyOfArray.push(array[index]);
  }

  return copyOfArray;
}

function concat(array1, array2) {
  const concatenated = clone(array1);

  for (let index = 0; index < array2.length; index++) {
    concatenated.push(array2[index]);
  }

  return concatenated;
}

function getSubset(arrayIndex, terms, arr, sub) {
  const subset = clone(sub);
  let indexOfArray = arrayIndex;

  for (let times = 2; times <= terms; times++) {
    subset.push(arr[indexOfArray]);
    indexOfArray = indexOfArray + 1;
  }

  return subset;
}

function subsetsFromIndex(arr, terms, index) {
  let currentIndex = index;
  let startIndex = index + 1;
  const subsetsArray = [];

  for (let subIndex = startIndex; subIndex + terms - 1 <= arr.length; subIndex++) {
    let subset = [arr[currentIndex]];
    subset = getSubset(subIndex, terms, arr, subset);
    subsetsArray.push(subset);
  }

  return subsetsArray;
}

function getAllSubsets(arr, terms) {
  let array = [];
  
  for (let index = 0; index <= Math.ceil(arr.length / 2); index++) {
    const subset = (subsetsFromIndex(arr, terms, index));
    array = concat(array, subset);
  }

return array;
}

function generatePowerSet(arr) {
  let powerSet = [[]];

  for(let index = 0; index < arr.length; index++) {
    const array =[arr[index]];

    powerSet.push(array);
  }

  for (let times = 2; times <= arr.length; times++) {
    powerSet = concat(powerSet, getAllSubsets(arr, times));
  }
  
  return powerSet;
}

function makeMessage(array1, expected, actual) {
  let message = "the array: '" + array1;

  message = message + "' are '" + expected; 
  message = message + "' and it is '" + actual + "'";

  return message;
}

function areIndexArrayEqual(array1, array2) {
  if (array1.length !== array2.length) {
    return false;
  }

  for (let index = 0; index < array1.length; index++) {
    if (array1[index] !== array2[index]) {
      return false;
    }
  }

  return true;
}

function areEqual(array1, array2) { 
  for (let index = 0; index < array1.length; index++) {
    if (!areIndexArrayEqual(array1[index], array2[index])) {
      return false;
    }
  }

  return true;
}

function testGeneratePowerSet(array, expected) {
  const actual = generatePowerSet(array);
  const getMark = areEqual(actual, expected) ? '✅' : '❌';

  console.log(getMark + makeMessage(array, expected, actual));
}

function testAll() {
  testGeneratePowerSet([1, 2, 3, 4], [[], [1], [2], [3], [4], [1, 2], [1, 3], [1, 4], [2, 3], [2, 4], [3, 4], [1, 2, 3], [1, 3, 4], [2, 3, 4], [1, 2, 3, 4]]);
  testGeneratePowerSet([1, 2, 3], [[], [1], [2], [3], [1, 2], [1, 3], [2, 3], [1, 2, 3]]);
  testGeneratePowerSet([1, 2], [[], [1], [2], [1, 2]]);
  testGeneratePowerSet([1], [[], [1]]);
  testGeneratePowerSet([], [[]]);
}

testAll();