import { describe, it } from "jsr:@std/testing/bdd";
import {
  fetchNLines,
  fetchContent,
  fetchNchars,
} from "../src/fetch_content.js";
import { assertEquals } from "jsr:@std/assert/equals";
import { beforeEach, afterEach } from "jsr:@std/testing/bdd";

const oldProperty = Deno.readTextFileSync;

const testingFiles = {
  "tenLines.txt": "1\n2\n3\n4\n5\n6\n7\n8\n9\n10",
  "fiveLines.txt": "1\n2\n3\n4\n5",
  "twentyLines.txt":
    "1\n2\n3\n4\n5\n6\n7\n8\n9\n10\n11\n12\n13\n14\n15\n16\n17\n18\n19\n20",
  "emptyFile.txt": "",
  "charFile.txt": "sai1\nsai2\nsai3\nsai4\nsai5\nsai6\nsai7\nsai8\nsai9\nsai10",
};

describe("fetchNlines(count, content, readFromTop = true)", () => {
  it("should give exact lines of the file when the count of lines is equal to the count", () => {
    const actual = fetchNLines(
      2,
      "there is something\nit shouldn't be nothing"
    );
    const expected = "there is something\nit shouldn't be nothing";
    assertEquals(actual, expected);
  });
  it("should give all the lines in the file when the count is more than the number of lines", () => {
    const actual = fetchNLines(
      10,
      "there is something\nit shouldn't be nothing"
    );
    const expected = "there is something\nit shouldn't be nothing";
    assertEquals(actual, expected);
  });
  it("should give the lines in the file upto the count when the count is less than the total lines", () => {
    const actual = fetchNLines(
      1,
      "there is something\nit shouldn't be nothing"
    );
    const expected = "there is something";
    assertEquals(actual, expected);
  });
});

describe("fetchNchars(count, content, readFromTop = true)", () => {
  it("should give exact characters of the file when the count of characters is equal to the count", () => {
    const actual = fetchNchars(2, "th");
    const expected = "th";
    assertEquals(actual, expected);
  });
  it("should give all the chars in the file when the count is equal to the number of characters", () => {
    const actual = fetchNchars(18, "there is something");
    const expected = "there is something";
    assertEquals(actual, expected);
  });
  it("should give the chars in the file upto the count when the count is less than the total chars", () => {
    const actual = fetchNchars(
      20,
      "there is something it shouldn't be nothing"
    );
    const expected = "there is something i";
    assertEquals(actual, expected);
  });
  it("should give the chars in the file when there are new lines", () => {
    const actual = fetchNchars(17, "there is\nsomething");
    const expected = "there is\nsomethin";
    assertEquals(actual, expected);
  });
});

describe("fetchContent(optionType, count, filePath)", () => {
  beforeEach(() => {
    Deno.readTextFileSync = (filePath) => {
      if (testingFiles[filePath] !== undefined) {
        return testingFiles[filePath];
      }
      throw "error";
    };
  });

  afterEach(() => {
    Deno.readTextFileSync = oldProperty;
  });

  it("should give content for the valid file for option n", () => {
    const actual = fetchContent("n", 10, ["tenLines.txt"]);
    const expected = {
      fileName: ["tenLines.txt"],
      content: "1\n2\n3\n4\n5\n6\n7\n8\n9\n10",
    };
    assertEquals(actual, expected);
  });
  it("should give content for the valid file for option c", () => {
    const actual = fetchContent("c", 10, ["tenLines.txt"]);
    const expected = {
      fileName: ["tenLines.txt"],
      content: "1\n2\n3\n4\n5\n",
    };
    assertEquals(actual, expected);
  });
  it("should give invalid file when file is missing for option n", () => {
    const actual = fetchContent("n", 10, ["missing.txt"]);
    const expected = {
      type: "invalid file",
      token: ["missing.txt"],
      isError: true,
    };
    assertEquals(actual, expected);
  });
  it("should give invalid file when file is missing for option c", () => {
    const actual = fetchContent("c", 10, ["missing.txt"]);
    const expected = {
      type: "invalid file",
      token: ["missing.txt"],
      isError: true,
    };
    assertEquals(actual, expected);
  });
});
