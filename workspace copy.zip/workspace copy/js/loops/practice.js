if (2>3) 
    
{
    console.log("greater");
} 

else

{
    console.log("lesser");
}



(2>3) ?     console.log("greater") :     console.log("lesser")
