// Given an array return reverse of array.
// reverse([1, 2, 3]) => [3, 2, 1]
// reverse([]) => []
// do not modify input parameters

function reverse(array) {
  let indexFromLast = array.length - 1;
  const reversed = [];

  for (let index = 0; index < array.length; index++) {
    reversed[index] = array[indexFromLast];
    indexFromLast = indexFromLast - 1;
  }

  return reversed;
}

function makeMessage(array, expected, actual) {
  let message = "the array 1: '" + array;

  message = message + "' are reversed to be '" + expected;
  message = message + "' and it is '" + actual + "'";

  return message;
}

function areEqual(array1, array2) {
  if (array1.length !== array2.length) {
    return false;
  }

  for (let index = 0; index < array1.length; index++) {
    if (array1[index] !== array2[index]) {
      return false;
    }
  }

  return true;
}

function testReverse(array, expected) {
  const actual = reverse(array);
  const getMark = areEqual(actual, expected) ? '✅' : '❌';

  console.log(getMark + makeMessage(array, expected, actual));
}

function testAll() {
  testReverse([1, 2, 3], [3, 2, 1]);
  testReverse([1, 1, 1], [1, 1, 1]);
  testReverse(["venkat", "sai"], ["sai", "venkat"]);
  testReverse([], []);
  testReverse(["aakash"], ["aakash"]);
  testReverse(["1", "2"], ["2", "1"]);
}

testAll();