export const batter = () => ({
  dismissal: "not out",
  runs: 0,
  balls: 0,
  fours: 0,
  sixes: 0,
});

export const bowler = () => ({
  overs: 0,
  runsgiven: 0,
  wicketsTaken: 0,
  balls: 0,
});

export const team = () => ({
  teamName: "",
  runs: 0,
  wicketsTaken: 0,
  extras: {
    noball: 0,
    wides: 0,
    legbyes: 0,
    byes: 0,
  },
});

// export const extras = () => ({
//   noBall: 0,
//   wide: 0,
//   legbyes: 0,
//   byes: 0,
// });
