function isInvalidFormat(format) {
  if (format === "dd-mm-yyyy") {
    return false;
  }

  if (format === "mm-dd-yyyy") {
    return false;
  }

  return !(format === "yyyy-mm-dd");
}

function verifyHyphen(date, Hyphen1, hyphen2) {
  return date[Hyphen1] !== "-" && date[hyphen2] !== "-";
}

function isInvalidDate(format, date) {
  if (format === "dd-mm-yyyy" || format === "mm-dd-yyyy") {
    return verifyHyphen (date, 2, 5);
  }

  return verifyHyphen (date, 4, 7);
}

function validateYear(date, index) {
  let year = date[index] + date [index + 1] + date[index + 2] + date[index + 3];
  
  year = +year;
  return (year < 1 || year > 9999);
}

function isYearInvalid(format, date) {
  if (format === "dd-mm-yyyy") {
    return validateYear(date, 6);
  }
  if (format === "mm-dd-yyyy") {
    return validateYear(date, 6);
  }
  if (format === "yyyy-mm-dd") {
    return validateYear(date, 0);
  }
}

function isMonthInvalid(format, date) {
  if (format === "dd-mm-yyyy") {
    let month = date[3] + date[4];
    month = +month;

    if (month < 1 || month > 12) {
      return true;
    }
  }
  if (format === "mm-dd-yyyy") {
    let month = date[0] + date[1];
    month = +month;

    if (month < 1 || month > 12) {
      return true;
    }
  }
  if (format === "yyyy-mm-dd") {
    let month = date[5] + date[6];
    month = +month;

    if (month < 1 || month > 12) {
      return true;
    }
  }
  return false;
}

function dayFirstFormat(format, date) {
  if (isYearInvalid(format, date)) {
    return "invalid year";
  }
  if (isMonthInvalid(format, date)) {
    return "invalid month";
  }
  return isDayValid(format, date);
}
// function monthFirstFormat(format, date) {
//   if (isMonthInvalid(format, date)) {
//     return "invalid month";
//   }

//   if (isYearInvalid(format, date)) {
//     return "invalid year";
//   }

//   return "valid";
// }

// function yearFirstFormat(format, date) {
//   if (isYearInvalid(format, date)) {
//     return "invalid year";
//   }

//   if (isMonthInvalid(format, date)) {
//     return "invalid month";
//   }

//   return "valid";

// }

function validate(format, date) {
  if (isInvalidFormat(format)) {
    return "invalid format";
  }

  if (isInvalidDate(format, date)) {
    return "date not according to format";
  }
  
  if (format === "dd-mm-yyyy") {
    return dayFirstFormat(format, date);
  }

  if (format === "mm-dd-yyyy") {
    return dayFirstFormat(format, date);
  }

  if (format === "yyyy-mm-dd") {
    return dayFirstFormat(format, date);
  }
}

function isDivisibleBy(dividend, divisor) {
  return dividend % divisor === 0;
}

function isLeapYear(year) {
  const isNonCenturyLeap = !isDivisibleBy(year, 100) && isDivisibleBy(year, 4);
  return isNonCenturyLeap || isDivisibleBy(year, 400);
}

function isDayValid(format) {

}

function testValidate(format, date, expected) {
  const result = validate(format, date);
  console.log(result === expected ? '✅' : '❌', format, date, expected, result);
}

function testMDY() {
  testValidate('mm-dd-yyyy', '01-01-2001', 'valid');
  testValidate('mm-dd-yyyy', '02-28-2001', 'valid');
  testValidate('mm-dd-yyyy', '02-29-2001', 'invalid day');
  testValidate('mm-dd-yyyy', '13-01-2001', 'invalid month');
  testValidate('mm-dd-yyyy', '01-01-0000', 'invalid year');
  testValidate('mm-dd-yyyy', '02-29-2004', 'valid');
  testValidate('mm-dd-yyyy', '01 01 2001', 'date not according to format');

}

function testAll() {
  // // testValidate('xx-yy-zzzz', '01-01-2020', 'invalid format');
  // // testValidate('mm-dd-yyyy', '01 01 2020', 'date not according to format');
  // // testValidate('mm-dd-yyyy', '01-01-0000', 'invalid year');
  // // testValidate('mm-dd-yyyy', '13-01-0000', 'invalid month');
  // // testValidate('mm-dd-yyyy', '01-60-0000', 'invalid day');
  // // testValidate('dd-mm-yyyy', '01-01-2020', 'valid');
  // testValidate('xx-yy-zzzz', '01-01-2020', 'invalid format');
  // testValidate('mm-dd-yyyy', '01 01 2020', 'date not according to format');
  // testValidate('mm-dd-yyyy', '01-01-0000', 'invalid year');
  // testValidate('mm-dd-yyyy', '13-01-0000', 'invalid year');
  // testValidate('mm-dd-yyyy', '01-60-0000', 'invalid year');
  // testValidate('dd-mm-yyyy', '01-01-2020', 'valid');
  // testValidate('mm-dd-yyyy', '01-01-2020', 'valid');
  // testValidate('yyyy-mm-dd', '2020-01-01', 'valid');
  // testValidate('yyyy-mm-dd', '2020-02-29', 'valid');
  testMDY();
}

testAll();