import { peoplesData } from "./data.js";
import {
  giveHowManyAreEmployed,
  giveHowManyOwnACar,
  giveHowManyPetsFullyVaccinated,
  giveNameAndTypeOfPet,
  giveCitiesTheyLiveIn,
  giveHobbies,
  giveHowManyPetsOfUnemployed,
  giveAverageAgeOfIndividuals,
  givePetsAndOfCSPeople,
  giveNumberOfIndividualsWithMoreThanOnePet,
  givePetsWithSpecificActivities,
  givePetsLiveInBangaloreAndChennai,
  giveHowManyVaccinatedPetsWithoutCar,
  giveYoungestPet,
  giveIndividualsDoesNotOwnAPet,
} from "./extractAnswers.js";

const isEqual = (a, b) => a === b;

const arrEqual = function (actual, expected) {
  if (!Array.isArray(actual)) return isEqual(actual, expected);

  if (actual.length !== expected.length) return false;

  return actual.every((element, index) => arrEqual(element, expected[index]));
};

const getMark = function (actual, expected) {
  return arrEqual(actual, expected) ? "✅" : "❌";
};

const test = (actual, expected) => [
  getMark(actual, expected),
  " expected:",
  expected,
  " actual:",
  actual,
];

const runTests = (fn, args, expected) => {
  const actual = fn(args);
  const [mark, expMsg, expectedValue, acMsg, actualValue] = test(
    actual,
    expected
  );
  console.log(mark, expMsg, expectedValue, acMsg, actualValue);
};

const question1 = function () {
  const allUnemployed = [
    {
      name: "sai",
      employment: { isEmployed: false },
    },
    {
      name: "another sai",
      employment: { isEmployed: false },
    },
    {
      name: "not another sai",
      employment: { isEmployed: false },
    },
  ];
  const oneEmployed = [
    {
      name: "sai",
      employment: { isEmployed: false },
    },
    {
      name: "another sai",
      employment: { isEmployed: false },
    },
    {
      name: "not another sai",
      employment: { isEmployed: true },
    },
  ];
  const twoEmployed = [
    {
      name: "sai",
      employment: { isEmployed: false },
    },
    {
      name: "another sai",
      employment: { isEmployed: true },
    },
    {
      name: "not another sai",
      employment: { isEmployed: true },
    },
  ];
  const allEmployed = [
    {
      name: "sai",
      employment: { isEmployed: true },
    },
    {
      name: "another sai",
      employment: { isEmployed: true },
    },
    {
      name: "not another sai",
      employment: { isEmployed: true },
    },
  ];

  const groups = [
    [allUnemployed, 0],
    [oneEmployed, 1],
    [twoEmployed, 2],
    [allEmployed, 3],
  ];
  groups.map(([group, expected]) =>
    runTests(giveHowManyAreEmployed, group, expected)
  );
};

const question2 = function () {
  const noOneOwnACar = [
    {
      name: "sai",
      vehicle: [{ type: "bike", usage: "to raom" }],
    },
    {
      name: "another sai",
      vehicle: [{ type: "", usage: "to raom" }],
    },
    {
      name: "not another sai",
      vehicle: [{ type: "", usage: "to raom" }],
    },
  ];
  const oneOwnACar = [
    {
      name: "sai",
      vehicle: [{ type: "car", usage: "to raom" }],
    },
    {
      name: "another sai",
      vehicle: [{ type: "", usage: "to raom" }],
    },
    {
      name: "not another sai",
      vehicle: [{ type: "", usage: "to raom" }],
    },
  ];
  const twoOwnACar = [
    {
      name: "sai",
      vehicle: [{ type: "bike", usage: "to raom" }],
    },
    {
      name: "another sai",
      vehicle: [{ type: "car", usage: "to raom" }],
    },
    {
      name: "not another sai",
      vehicle: [{ type: "car", usage: "to raom" }],
    },
  ];
  const threeOwnACar = [
    {
      name: "sai",
      vehicle: [{ type: "car", usage: "to raom" }],
    },
    {
      name: "another sai",
      vehicle: [{ type: "car", usage: "to raom" }],
    },
    {
      name: "not another sai",
      vehicle: [{ type: "car", usage: "to raom" }],
    },
  ];

  const groups = [
    [noOneOwnACar, 0],
    [oneOwnACar, 1],
    [twoOwnACar, 2],
    [threeOwnACar, 3],
  ];
  groups.map(([group, expected]) =>
    runTests(giveHowManyOwnACar, group, expected)
  );
};

const question3 = function () {
  const noPetIsVaccinated = [
    {
      name: "sai",
      pets: [{ name: "whiskers", isVaccinated: false }],
    },
    {
      name: "another sai",
      pets: [{ name: "luna", isVaccinated: false }],
    },
    {
      name: "not another sai",
      pets: [
        { name: "bella", isVaccinated: false },
        { name: "charlie", isVaccinated: false },
      ],
    },
  ];
  const onePetIsVaccinated = [
    {
      name: "sai",
      pets: [{ name: "whiskers", isVaccinated: false }],
    },
    {
      name: "another sai",
      pets: [{ name: "luna", isVaccinated: false }],
    },
    {
      name: "not another sai",
      pets: [
        { name: "bella", isVaccinated: true },
        { name: "charlie", isVaccinated: false },
      ],
    },
  ];
  const twoAreVacinated = [
    {
      name: "sai",
      pets: [{ name: "whiskers", isVaccinated: false }],
    },
    {
      name: "another sai",
      pets: [{ name: "luna", isVaccinated: true }],
    },
    {
      name: "not another sai",
      pets: [
        { name: "bella", isVaccinated: true },
        { name: "charlie", isVaccinated: false },
      ],
    },
  ];
  const allAreVacinted = [
    {
      name: "sai",
      pets: [{ name: "whiskers", isVaccinated: true }],
    },
    {
      name: "another sai",
      pets: [{ name: "luna", isVaccinated: true }],
    },
    {
      name: "not another sai",
      pets: [
        { name: "bella", isVaccinated: true },
        { name: "charlie", isVaccinated: true },
      ],
    },
  ];

  const groups = [
    [noPetIsVaccinated, 0],
    [onePetIsVaccinated, 1],
    [twoAreVacinated, 2],
    [allAreVacinted, 4],
  ];

  groups.map(([group, expected]) =>
    runTests(giveHowManyPetsFullyVaccinated, group, expected)
  );
};

const question4 = function () {
  const noPets = [{ name: "sai", pets: [{ name: "", type: "" }] }];
  const onePet = [{ name: "sai", pets: [{ name: "spike", type: "dog" }] }];

  const twoPets = [
    { name: "sai", pets: [{ name: "spike", type: "dog" }] },
    { name: "another sai", pets: [{ name: "tom", type: "cat" }] },
  ];

  const oneOwnerWithManyPets = [
    { name: "sai", pets: [{ name: "spike", type: "dog" }] },
    { name: "another sai", pets: [{ name: "tom", type: "cat" }] },
    {
      name: "not another sai",
      pets: [
        { name: "jerry", type: "mouse" },
        { name: "scooby", type: "dog" },
      ],
    },
  ];

  const groups = [
    [noPets, [["", ""]]],
    [onePet, [["spike", "dog"]]],
    [
      twoPets,
      [
        ["spike", "dog"],
        ["tom", "cat"],
      ],
    ],
    [
      oneOwnerWithManyPets,
      [
        ["spike", "dog"],
        ["tom", "cat"],
        ["jerry", "mouse"],
        ["scooby", "dog"],
      ],
    ],
  ];

  groups.map(([group, expected]) =>
    runTests(giveNameAndTypeOfPet, group, expected)
  );
};

const question5 = function () {
  const noCity = [{ name: "sai", city: "" }];
  const onePerson = [{ name: "sai", city: "kakinada" }];
  const twoPersons = [
    { name: "sai", city: "kakinada" },
    { name: "another sai", city: "rajamahendravaram" },
  ];

  const groups = [
    [noCity, ""],
    [onePerson, "kakinada"],
    [twoPersons, "kakinada, rajamahendravaram"],
  ];

  groups.map(([group, expected]) =>
    runTests(giveCitiesTheyLiveIn, group, expected)
  );
};

const question6 = function () {
  const noHobbies = [{ name: "sai", hobbies: [{ hobby: "" }] }];
  const onePersonHasHobbies = [
    { name: "sai", hobbies: [{ hobby: "" }] },
    { name: "another sai", hobbies: [{ hobby: "gaming" }] },
  ];

  const multipleHobbies = [
    { name: "sai", hobbies: [{ hobby: "" }] },
    { name: "another sai", hobbies: [{ hobby: "gaming" }] },
    {
      name: "not another sai",
      hobbies: [{ hobby: "gaming" }, { hobby: "sleeping" }],
    },
  ];

  const groups = [
    [noHobbies, [0, ""]],
    [onePersonHasHobbies, [1, "gaming"]],
    [multipleHobbies, [2, "gaming, sleeping"]],
  ];

  groups.map(([group, expected]) => runTests(giveHobbies, group, expected));
};

const question7 = function () {
  const onePetOfunemployed = [
    {
      name: "sai",
      employment: { isEmployed: false },
      pets: [{ name: "figgy" }],
    },
  ];
  const onePetOfEmployed = [
    {
      name: "sai",
      employment: { isEmployed: true },
      pets: [{ name: "figgy" }],
    },
  ];
  const twoPetsOfEmployed = [
    {
      name: "sai",
      employment: { isEmployed: false },
      pets: [{ name: "figgy" }, { name: "swiggy" }],
    },
    {
      name: "another sai",
      employment: { isEmployed: true },
      pets: [{ name: "zomato" }],
    },
  ];

  const groups = [
    [onePetOfunemployed, 1],
    [onePetOfEmployed, 0],
    [twoPetsOfEmployed, 2],
  ];

  groups.map(([group, expected]) =>
    runTests(giveHowManyPetsOfUnemployed, group, expected)
  );
};

const question8 = function () {
  const onePerson = [{ name: "sai", age: 18 }];
  const twoPersons = [
    { name: "sai", age: 18 },
    { name: "another sai", age: 20 },
  ];
  const sameagedPersons = [
    { name: "sai", age: 18 },
    { name: "another sai", age: 18 },
  ];

  const groups = [
    [onePerson, 18],
    [twoPersons, 19],
    [sameagedPersons, 18],
  ];

  groups.map(([group, expected]) =>
    runTests(giveAverageAgeOfIndividuals, group, expected)
  );
};

const question9 = function () {
  const noCSPerson = [
    {
      name: "sai",
      degreesOwned: ["electronics"],
      pets: [{ name: "max" }, { name: "tom" }, { name: "jerry" }],
    },
  ];
  const oneCSPerson = [
    {
      name: "sai",
      degreesOwned: ["computer science"],
      pets: [{ name: "max" }, { name: "tom" }, { name: "jerry" }],
    },
  ];

  const combinationOfCSAndOther = [
    {
      name: "sai",
      degreesOwned: ["computer science"],
      pets: [{ name: "max" }, { name: "tom" }, { name: "jerry" }],
    },
    {
      name: "another sai",
      degreesOwned: ["electronics"],
      pets: [{ name: "spike" }, { name: "courage" }, { name: "shirou" }],
    },
  ];

  const groups = [
    [noCSPerson, 0],
    [oneCSPerson, 3],
    [combinationOfCSAndOther, 3],
  ];

  groups.map(([group, expected]) =>
    runTests(givePetsAndOfCSPeople, group, expected)
  );
};

const quesion10 = function () {
  const noPersonHas2Pets = [
    {
      name: "sai",
      pets: [{ name: "whiskers", isVaccinated: false }],
    },
    {
      name: "another sai",
      pets: [{ name: "luna", isVaccinated: false }],
    },
    {
      name: "not another sai",
      pets: [{ name: "bella", isVaccinated: false }],
    },
  ];
  const onePersonHas2Pets = [
    {
      name: "sai",
      pets: [{ name: "whiskers", isVaccinated: false }],
    },
    {
      name: "another sai",
      pets: [{ name: "luna", isVaccinated: false }],
    },
    {
      name: "not another sai",
      pets: [
        { name: "bella", isVaccinated: true },
        { name: "charlie", isVaccinated: false },
      ],
    },
  ];
  const onePersonsHave3Pets = [
    {
      name: "sai",
      pets: [{ name: "whiskers", isVaccinated: false }],
    },
    {
      name: "another sai",
      pets: [{ name: "luna", isVaccinated: true }],
    },
    {
      name: "not another sai",
      pets: [
        { name: "bella", isVaccinated: true },
        { name: "charlie", isVaccinated: false },
        { name: "spike" },
      ],
    },
  ];
  const twoPersonsHave3Pets = [
    {
      name: "sai",
      pets: [{ name: "whiskers" }, { name: "courage" }, { name: "jerry" }],
    },
    {
      name: "another sai",
      pets: [{ name: "luna", isVaccinated: true }],
    },
    {
      name: "not another sai",
      pets: [
        { name: "bella", isVaccinated: true },
        { name: "charlie", isVaccinated: true },
        { name: "spike" },
      ],
    },
  ];

  const groups = [
    [noPersonHas2Pets, 0],
    [onePersonHas2Pets, 1],
    [onePersonsHave3Pets, 1],
    [twoPersonsHave3Pets, 2],
  ];

  groups.map(([group, expected]) =>
    runTests(giveNumberOfIndividualsWithMoreThanOnePet, group, expected)
  );
};

const quesion11 = function () {
  const noPetHasActivities = [
    {
      name: "sai",
      pets: [{ name: "whiskers", isVaccinated: false, activities: [] }],
    },
    {
      name: "another sai",
      pets: [{ name: "luna", isVaccinated: false, activities: [] }],
    },
    {
      name: "not another sai",
      pets: [
        { name: "bella", isVaccinated: false, activities: [] },
        { name: "charlie", isVaccinated: false, activities: [] },
      ],
    },
  ];
  const onePetHasActivities = [
    {
      name: "sai",
      pets: [
        { name: "whiskers", isVaccinated: false, activities: ["playing"] },
      ],
    },
    {
      name: "another sai",
      pets: [{ name: "luna", isVaccinated: false, activities: [] }],
    },
    {
      name: "not another sai",
      pets: [
        { name: "bella", isVaccinated: true, activities: [] },
        { name: "charlie", isVaccinated: false, activities: [] },
      ],
    },
  ];
  const twoPetsHaveActivities = [
    {
      name: "sai",
      pets: [
        { name: "whiskers", isVaccinated: false, activities: ["playing"] },
      ],
    },
    {
      name: "another sai",
      pets: [{ name: "luna", isVaccinated: true, activities: ["sleeping"] }],
    },
    {
      name: "not another sai",
      pets: [
        { name: "bella", isVaccinated: true, activities: [] },
        { name: "charlie", isVaccinated: false, activities: [] },
      ],
    },
  ];
  const allPetsHaveActivities = [
    {
      name: "sai",
      pets: [{ name: "whiskers", isVaccinated: true, activities: ["playing"] }],
    },
    {
      name: "another sai",
      pets: [{ name: "luna", isVaccinated: true, activities: ["sleeping"] }],
    },
    {
      name: "not another sai",
      pets: [
        { name: "bella", isVaccinated: true, activities: ["walking"] },
        { name: "charlie", isVaccinated: true, activities: ["acting"] },
      ],
    },
  ];

  const groups = [
    [noPetHasActivities, ""],
    [onePetHasActivities, "whiskers"],
    [twoPetsHaveActivities, "whiskers, luna"],
    [allPetsHaveActivities, "whiskers, luna, bella, charlie"],
  ];

  groups.map(([group, expected]) =>
    runTests(givePetsWithSpecificActivities, group, expected)
  );
};

const quesion12 = function () {
  const noPetLivesInCity = [{ name: "sai", city: "", pets: [] }];
  const onePetLivesInBangalore = [
    { name: "sai", city: "Bangalore", pets: [{ name: "max" }] },
  ];
  const onePetLivesInChennai = [
    { name: "sai", city: "kakinada" },
    { name: "another sai", city: "Chennai", pets: [{ name: "snowy" }] },
  ];
  const PetLiveInBangaloreAndChennai = [
    { name: "sai", city: "Bangalore", pets: [{ name: "max" }] },
    { name: "another sai", city: "Chennai", pets: [{ name: "snowy" }] },
  ];
  const twoPetsLiveInSameCity = [
    {
      name: "sai",
      city: "Bangalore",
      pets: [{ name: "max" }, { name: "spike" }],
    },
    { name: "another sai", city: "Chennai", pets: [{ name: "snowy" }] },
  ];

  const groups = [
    [noPetLivesInCity, ""],
    [onePetLivesInBangalore, "max"],
    [onePetLivesInChennai, "snowy"],
    [PetLiveInBangaloreAndChennai, "max, snowy"],
    [twoPetsLiveInSameCity, "max, spike, snowy"],
  ];

  groups.map(([group, expected]) =>
    runTests(givePetsLiveInBangaloreAndChennai, group, expected)
  );
};
const testQuestions = function ([questionNumber, question]) {
  console.log(questionNumber);
  question();
};

const testAllQuestions = function () {
  const questions = [
    ["question1:", question1],
    ["question 2: ", question2],
    ["question3 : ", question3],
    ["question4: ", question4],
    ["question5: ", question5],
    ["question6: ", question6],
    ["question7: ", question7],
    ["quesion8: ", question8],
    ["quesion9: ", question9],
    ["question10: ", quesion10],
    ["quesion11: ", quesion11],
    ["quesion12: ", quesion12],
  ];
  questions.map(testQuestions);
};

testAllQuestions();
