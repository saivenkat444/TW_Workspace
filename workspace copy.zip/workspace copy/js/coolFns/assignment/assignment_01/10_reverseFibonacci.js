// Write a function that gives first n elements of fibonacci in reverse order
// fibonacci(5) => [3, 2, 1, 1, 0]
// do not modify input parameters

function reverse(array) {
  let IndexFromLast = array.length - 1;
  const reversed = [];

  for (let index = 0; index < array.length; index++) {
    reversed[index] = array[IndexFromLast];
    IndexFromLast = IndexFromLast - 1;
  }

  return reversed;
}

function fibonacci(n) {
  let previous = -1;
  let next = 1;
  let result = 0;
  const fibonacciSeries = [];

  for (let terms = 0; terms < n; terms++) {
    fibonacciSeries[terms] = previous + next;
    result = previous + next;
    previous = next;
    next = result;
  }

  return fibonacciSeries;
}

function reverseFibonacci(n) {
  const fibonacciSeries = fibonacci(n);

  return reverse(fibonacciSeries);
}

function makeMessage(terms, expected, actual) {
  let message = "the reverse fibonaci series upto: '" + terms;

  message = message + "' are '" + expected;
  message = message + "' and it is '" + actual + "'";

  return message;
}

function areEqual(array1, array2) {
  if (array1.length !== array2.length) {
    return false;
  }

  for (let index = 0; index < array1.length; index++) {
    if (array1[index] !== array2[index]) {
      return false;
    }
  }

  return true;
}

function testReverseFibonacci(terms, expected) {
  const actual = reverseFibonacci(terms);
  const getMark = areEqual(actual, expected) ? '✅' : '❌';

  console.log(getMark + makeMessage(terms, expected, actual));
}

function testAll() {
  testReverseFibonacci(1, [0]);
  testReverseFibonacci(2, [1, 0]);
  testReverseFibonacci(3, [1, 1, 0]);
  testReverseFibonacci(4, [2, 1, 1, 0]);
  testReverseFibonacci(5, [3, 2, 1, 1, 0]);
  testReverseFibonacci(6, [5, 3, 2, 1, 1, 0]);
  testReverseFibonacci(7, [8, 5, 3, 2, 1, 1, 0]);
}

testAll();