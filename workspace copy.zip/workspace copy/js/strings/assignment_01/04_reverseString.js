// Do not rename string, use it as input for your program.
// While testing we will change it's value.
const string = 'reverse';
// Reverse the given string
// If string = "reverse" then output should be "esrever"
// START YOUR CODE AFTER THIS LINE. DO NOT REMOVE THIS LINE

let reversedString = "";

for (let lengthOfString = (string.length - 1); lengthOfString >= 0; lengthOfString--) {
    reversedString = reversedString + string[lengthOfString];
}

console.log(reversedString);