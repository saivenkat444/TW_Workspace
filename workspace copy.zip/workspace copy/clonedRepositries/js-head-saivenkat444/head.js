import { parseArgs } from "./src/parse_args.js";
import { head } from "./src/head_lib.js";
import { display } from "./src/print.js";
//something refers to one file data

const main = () => {
  const parsedArgs = parseArgs(Deno.args);
  const allHeadContent = head(parsedArgs);
  const exitValue = display(allHeadContent, "head");
  Deno.exit(exitValue);
};

main();
