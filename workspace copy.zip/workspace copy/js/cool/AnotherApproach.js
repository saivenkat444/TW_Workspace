function canBecreated(dimensions) {
  return dimensions[0] > 0 && dimensions[1] > 0;
}

function hallow(dimensions, i) {
  const row = ["*"];
  if (dimensions[0] === 1) {
    return row;
  }

  for (let j = 1; j < dimensions[0] - 1; j++) {
    const element = i === 0 || i === dimensions[1] - 1 ? "*" : " ";
    row.push(element);
  }

  row.push("*");
  return row;
}

function filled(dimensions, char) {
  const row = [];

  for (let j = 0; j < dimensions[0]; j++) {
    row.push(char);
  }

  return row;
}

function createTriangle(dimensions) {
  const triangle = [];

  for (let i = 1; i <= dimensions[0]; i++) {
    triangle.push(filled([i], "*"));
  }

  return triangle;
}

function createAlternatingRectangle(dimensions) {
  const rectangle = [];

  for (let i = 0; i < dimensions[1]; i++) {
    const char = i % 2 === 0 ? "*" : "-";
    rectangle.push(filled(dimensions, char));
  }

  return rectangle;
}

function createFilledAndHallowRectangle(style, dimensions) {
  const rectangle = [];

  for (let i = 0; i < dimensions[1]; i++) {
    if (style === "filled-rectangle") {
      rectangle.push(filled(dimensions, "*"));
    } else {
      rectangle.push(hallow(dimensions, i));
    }
  }

  return rectangle;
}

function allTriangles(style, dimensions) {
  if (style === "triangle") {
    return createTriangle(dimensions);
  }
}

function allReactangles(style, dimensions) {
  const canCreate = canBecreated(dimensions);
  
  if (!canCreate) {
    return "";
  }

  if (style === "filled-rectangle" || style === "hollow-rectangle") {
    return createFilledAndHallowRectangle(style, dimensions);
  }

  if (style === "alternating-rectangle") {
    return createAlternatingRectangle(dimensions);
  }
}

function createShape(style, dimensions) {
  if (style.endsWith("rectangle")) {
    return allReactangles(style, dimensions);
  }

  if (style.endsWith("triangle")) {
    return allTriangles(style, dimensions);
  }
}

function convertToString(shape) {
  let shapeToPrint = "";

  for (let index = 0; index < shape.length; index++) {
    if (index === shape.length - 1) {
      shapeToPrint = (shapeToPrint + (shape[index].join(''))).replaceAll(",", "");
      return shapeToPrint;
    }
    shapeToPrint = shapeToPrint + shape[index].join('') + "\n";
  }

  return shapeToPrint;
}

function generatePattern(style, dimensions) {
  const shape = createShape(style, dimensions);
  return convertToString(shape);
}

function testGeneratePattern(style, dimensions, expected, failed) {
  const actual = generatePattern(style, dimensions);
  if (actual !== expected) {
    failed.push([style, dimensions, actual, expected]);
  }
}

function testAll() {
  const failed = [];
  testGeneratePattern('filled-rectangle', [0, 0], '', failed);
  testGeneratePattern('filled-rectangle', [1, 0], '', failed);
  testGeneratePattern('filled-rectangle', [1, 1], '*', failed);
  testGeneratePattern('filled-rectangle', [1, 2], '*\n*', failed);
  testGeneratePattern('filled-rectangle', [2, 2], '**\n**', failed);
  testGeneratePattern('filled-rectangle', [2, 3], '**\n**\n**', failed);
  testGeneratePattern('hollow-rectangle', [0, 0], '', failed);
  testGeneratePattern('hollow-rectangle', [1, 0], '', failed);
  testGeneratePattern('hollow-rectangle', [1, 1], '*', failed);
  testGeneratePattern('hollow-rectangle', [1, 2], '*\n*', failed);
  testGeneratePattern('hollow-rectangle', [1, 3], '*\n*\n*', failed);
  testGeneratePattern('hollow-rectangle', [2, 2], '**\n**', failed);
  testGeneratePattern('hollow-rectangle', [2, 1], '**', failed);
  testGeneratePattern('hollow-rectangle', [3, 3], '***\n* *\n***', failed);
  testGeneratePattern('hollow-rectangle', [3, 2], '***\n***', failed);
  testGeneratePattern('hollow-rectangle', [3, 1], '***', failed);
  testGeneratePattern('hollow-rectangle', [4, 3], '****\n*  *\n****', failed);
  testGeneratePattern('alternating-rectangle', [3, 3], '***\n---\n***', failed);
  testGeneratePattern('alternating-rectangle', [2, 2], '**\n--', failed);
  testGeneratePattern('alternating-rectangle', [1, 1], '*', failed);
  testGeneratePattern('alternating-rectangle', [1, 0], '', failed);
  testGeneratePattern('alternating-rectangle', [0, 1], '', failed);
  testGeneratePattern('alternating-rectangle', [0, 0], '', failed);
  testGeneratePattern('alternating-rectangle', [3, 1], '***', failed);
  testGeneratePattern('alternating-rectangle', [3, 1], '***', failed);
  testGeneratePattern('alternating-rectangle', [1, 3], '*\n-\n*', failed);
  testGeneratePattern('alternating-rectangle', [4, 4], '****\n----\n****\n----', failed);
  testGeneratePattern('triangle', [5], '*\n**\n***\n****\n*****', failed);
  testGeneratePattern('triangle', [4], '*\n**\n***\n****', failed);
  testGeneratePattern('triangle', [3], '*\n**\n***', failed);
  testGeneratePattern('triangle', [2], '*\n**', failed);
  testGeneratePattern('triangle', [1], '*', failed);
  testGeneratePattern('triangle', [0], '', failed);

  console.table(failed);
}

testAll();