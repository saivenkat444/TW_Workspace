let num=1;
let numberOfDigits=0;
let checkNOD=num;
let checkarm=num;
let armstrong=0;
let isarmstrong=false;
while(checkNOD>0){
    checkNOD=checkNOD-(checkNOD%10)
    checkNOD=checkNOD/10
    numberOfDigits=numberOfDigits+1
}
while(checkarm>0){
    armstrong=armstrong+((checkarm%10)**numberOfDigits);
    checkarm= checkarm - checkarm%10;
    checkarm=checkarm/10;
}
if (armstrong===num){
    isarmstrong=true
}
console.log(num,armstrong,isarmstrong)
