function compoundInterest(principle, rate, time) {
  if (time === 0 || rate === 0 || principle === 0) {
    return 0;
  }

  const interest = (principle * rate) / 100;

  return interest + compoundInterest(principle + interest, rate, time - 1);
}

function makeMessage(principle, rate, time, expected, actual) {
  let message = "the compound interst for " + principle + " rate : " + rate;
  message = message + " time is : " + time;
  
  message = message + " expected to be " + expected;
  message = message + " and it is " + actual;

  return message;
}

function testCompoundInterest(principle, rate, time, expected) {
  const actual = compoundInterest(principle, rate, time);
  const getMark  = actual === expected ? '✅' : '❌';
  
  console.log(getMark + makeMessage(principle, rate, time, expected, actual));
}

function testAll() {
  testCompoundInterest(1000, 10, 2, 210);
  testCompoundInterest(0, 10, 2, 0);
  testCompoundInterest(1000, 0, 2, 0);
  testCompoundInterest(1000, 10, 0, 0);
}

testAll();