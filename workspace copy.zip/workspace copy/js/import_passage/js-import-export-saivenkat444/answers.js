import { peoplesData } from "./data.js";
import {
  giveHowManyAreEmployed,
  giveHowManyOwnACar,
  giveHowManyPetsFullyVaccinated,
  giveNameAndTypeOfPet,
  giveCitiesTheyLiveIn,
  giveHobbies,
  giveHowManyPetsOfUnemployed,
  giveAverageAgeOfIndividuals,
  givePetsAndOfCSPeople,
  giveNumberOfIndividualsWithMoreThanOnePet,
  givePetsWithSpecificActivities,
  givePetsLiveInBangaloreAndChennai,
  giveHowManyVaccinatedPetsWithoutCar,
  giveIndividualsMoreThan2Habits,
  giveIndividualsShareHobbyWithRamesh,
  giveYoungestPet,
  giveBooksAndPeopleThatRead,
  giveCitiesStartWithB,
  giveIndividualsDoesNotOwnAPet,
} from "./extractAnswers.js";
import {
  question1,
  question2,
  question3,
  question4,
  question5,
  question6,
  question7,
  question8,
  question9,
  question10,
  question11,
  question12,
  question13,
  question14,
  question15,
  question16,
  question17,
  question18,
  question19,
  question20,
} from "./questions.js";

const giveResult = ([fn, data, question]) =>
  console.log(question, "\n", fn(data));

const allQuestionAndAnswers = function () {
  const array = [
    [giveHowManyAreEmployed, peoplesData, question1],
    [giveHowManyOwnACar, peoplesData, question2],
    [giveHowManyPetsFullyVaccinated, peoplesData, question3],
    [giveNameAndTypeOfPet, peoplesData, question4],
    [giveCitiesTheyLiveIn, peoplesData, question5],
    [giveHobbies, peoplesData, question6],
    [giveHowManyPetsOfUnemployed, peoplesData, question7],
    [giveAverageAgeOfIndividuals, peoplesData, question8],
    [givePetsAndOfCSPeople, peoplesData, question9],
    [giveNumberOfIndividualsWithMoreThanOnePet, peoplesData, question10],
    [givePetsWithSpecificActivities, peoplesData, question11],
    [givePetsLiveInBangaloreAndChennai, peoplesData, question12],
    [giveHowManyVaccinatedPetsWithoutCar, peoplesData, question13],
    // [giveMostCommonPet, peoplesData, question14],
    [giveIndividualsMoreThan2Habits, peoplesData, question15],
    [giveIndividualsShareHobbyWithRamesh, peoplesData, question16],
    [giveYoungestPet, peoplesData, question17],
    // [giveBooksAndPeopleThatRead, peoplesData, question18],
    [giveCitiesStartWithB, peoplesData, question19],
    [giveIndividualsDoesNotOwnAPet, peoplesData, question20],
  ];

  array.map(giveResult);
};

allQuestionAndAnswers();
