import { parseArgs } from "./src/parse_args.js";
import { head } from "./src/head_lib.js";

//something refers to one file data

const main = () => {
  try {
    const parsedArgs = parseArgs(Deno.args); //do in head
    console.log(head(parsedArgs));
  } catch (){

  }
  Deno.exit();
};

main();

//bitwise and or operator
//data structuring

/* data => update, update x
inputs outputs expecting 
template
use the template 
expected data*/

/* data => better stats, 
data=> bowler stats,
data=> team stats, 
*/
