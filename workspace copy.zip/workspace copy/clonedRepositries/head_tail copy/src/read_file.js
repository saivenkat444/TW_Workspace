export const readFile = (filePath) => {
  try {
    return Deno.readTextFileSync(filePath);
  } catch {
    return { error: { type: "invalid file", token: filePath } };
  }
};
