function getYear(date, index) {
  return +(date[index] + date[index + 1] + date[index + 2] + date [index + 3]);
}

function getDayOrMonth(date, index) {
  return +(date[index] + date[index + 1]);
}

function validateDate(day, month, year) {
  if (!validateYear(year)) {
    return "invalid year"
  }
  
  if (!validateMonth(month)) {
    return "invalid month";
  }
  
  return validateDay(day, month, year);
}

function validateYear(year) {
  return year > 0 && year < 10000; 
}

function validateMonth(month) {
  return month > 0 && month < 13;
}

function daysInMonth(month, isLeap) {
  if (isLeap && month === 2) {
    return 29;
  }

  if (month === 4 || month === 6 || month === 9 ||month === 11) {
    return 30;
  }

  if (month !== 2) {
    return 31;
  }

  return 28;
}

function validateDay(day, month, year) {
  if (day > 0 && day < 32) {
    const isLeap = ((year % 400 === 0) || (year % 4 === 0 && year % 100 !== 0));
    if (day <= daysInMonth(month, isLeap)) {
      return "valid";
    
    }
    return "invalid day";
}
}

function validateMDY(date) {
  const day = getDayOrMonth(date, 3);
  const month = getDayOrMonth(date, 0);
  const year = getYear(date, 6);
  return validateDate(day, month, year);
}

function validateDMY(date) {
  const day = getDayOrMonth(date, 0);
  const month = getDayOrMonth(date, 3);
  const year = getYear(date, 6); 
  return validateDate(day, month, year);
}

function validateYMD(date) {
  const day = getDayOrMonth(date, 8);
  const month = getDayOrMonth(date, 5);
  const year = getYear(date, 0); 
  return validateDate(day, month, year);  
}

function verifyTwoCharacters(date, index) {
  if (date[index] <= 9 && date[index] !== " ") {
    return date[index + 1] <= 9 && date[index + 1] !== " ";
  } 
  return false;
}

function validateDateFormat(date, dateIndex, monthIndex, halfyearIndex, otherHalfYearIndex) {
  if (date.length === 10) {
    const isDateCorrect = verifyTwoCharacters(date, dateIndex);
    const isMonthCorrect = verifyTwoCharacters(date, monthIndex);
    const isYearCorrect = verifyTwoCharacters(date, halfyearIndex) && verifyTwoCharacters(date, otherHalfYearIndex);
    return isDateCorrect && isMonthCorrect && isYearCorrect;
  }
}

function validate(format, date) {
  if (format === "mm-dd-yyyy") {
    validateDateFormat(date, 3, 0, 6, 8);
    return validateMDY(date);
  }
  if (format === "dd-mm-yyyy") {
    return validateDMY(date);
  }

  if (format === "yyyy-mm-dd") {
    return validateYMD(date);
  }
  return "invalid format"
}

function testValidate(format, date, expected) {
  const result = validate(format, date);
  console.log(result === expected ? '✅' : '❌', format, date, expected, result);
}
function testMDY() {
  testValidate('mm-dd-yyyy', '01-01-2001', 'valid');
  testValidate('mm-dd-yyyy', '02-28-2001', 'valid');
  testValidate('mm-dd-yyyy', '02-29-2001', 'invalid day');
  testValidate('mm-dd-yyyy', '13-01-2001', 'invalid month');
  testValidate('mm-dd-yyyy', '01-01-0000', 'invalid year');
  testValidate('mm-dd-yyyy', '02-29-2004', 'valid');
  testValidate('mm-dd-yyyy', '01 01 2001', 'date not according to format');

}

function testDMY() {
  testValidate('mm-dd-yyyy', '01-01-2001', 'valid');
  testValidate('mm-dd-yyyy', '02-28-2001', 'valid');
  testValidate('mm-dd-yyyy', '02-29-2001', 'invalid day');
  testValidate('mm-dd-yyyy', '13-01-2001', 'invalid month');
  testValidate('mm-dd-yyyy', '01-01-0000', 'invalid year');
  testValidate('mm-dd-yyyy', '02-29-2004', 'valid');
  testValidate('mm-dd-yyyy', '01 01 2001', 'date not according to format');

}

function testYMD() {
  testValidate('mm-dd-yyyy', '01-01-2001', 'valid');
  testValidate('mm-dd-yyyy', '02-28-2001', 'valid');
  testValidate('mm-dd-yyyy', '02-29-2001', 'invalid day');
  testValidate('mm-dd-yyyy', '13-01-2001', 'invalid month');
  testValidate('mm-dd-yyyy', '01-01-0000', 'invalid year');
  testValidate('mm-dd-yyyy', '02-29-2004', 'valid');
  testValidate('mm-dd-yyyy', '01 01 2001', 'date not according to format');

}

function testAll() {
  testMDY();
}

testAll();  