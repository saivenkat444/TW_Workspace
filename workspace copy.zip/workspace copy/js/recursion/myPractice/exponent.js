function exponent(number, power) {
  if (power === 0) {
    return 1;
  }

  return number * exponent(number, power - 1);
}

console.log(exponent(6, 0));
console.log(exponent(6, 1));
console.log(exponent(6, 2));
console.log(exponent(6, 3));
console.log(exponent(6, 1));
// console.log(exponent(6, 1));
// console.log(exponent(6, 1));
// console.log(exponent(6, 1));