function multiply(number1, number2) {
  if (number2 === 0) {
    return 0;
  }

  return number1 + multiply(number1, number2 - 1);
}

console.log(multiply(2, 1));
console.log(multiply(1, 2));
console.log(multiply(2, 2));
console.log(multiply(2, 3));
console.log(multiply(1,0));
console.log(multiply(0, 3));