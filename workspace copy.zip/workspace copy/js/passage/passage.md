Rahul, a software engineer from Pune, enjoys playing chess and gardening when he's not busy coding. He owns a golden retriever named Max, who is 4 years old, fully vaccinated, and loves playing fetch in the park. Rahul is currently employed and has a car that he uses for weekend trips.
Meanwhile, Ananya, who recently turned 30 and lives in Bangalore, is passionate about cooking and often experiments with Italian recipes. She has a parrot named Kiwi, who knows over 20 phrases, mimics her voice, and is also vaccinated. Unlike Rahul, Ananya doesn’t own a car but prefers using public transport.
Both Rahul and Ananya studied computer science in college, though Ananya also has a minor in graphic design.
Ramesh, a 45-year-old business owner from Jaipur, has little in common with them, except for his love of gardening. He spends his weekends tending to his rose garden and reading historical fiction. Ramesh has two Persian cats, Bella and Leo, who are 3 years old, fully vaccinated, and love lounging in the sun.
Unlike Ramesh, Kavya, who’s 28 and a professional dancer from Chennai, prefers modern fantasy novels and binge-watching sci-fi shows in her downtime. Kavya has a rescue rabbit named Snowy, who is 2 years old, vaccinated, and enjoys hopping around her backyard and nibbling on carrots. Kavya, however, is currently unemployed and does not own a vehicle.

things listed in the passage are their
names, 
their place,
age/profession,
hobbies, 
pet, 
pet age,
ispet vaccinated, 
hobby of pet,
mode of transport