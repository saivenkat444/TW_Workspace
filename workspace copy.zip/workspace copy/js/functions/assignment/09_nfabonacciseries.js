/*
  Write a function that returns the nth fibonacci term
  
  Examples:
    nthFibonacciTerm(1) => 0
    nthFibonacciTerm(4) => 2
    nthFibonacciTerm(6) => 5

  **Your function must return a value**

  It's not necessary to print the result on screen, 
  however to test your function you are free to print the result
*/

function nthFibonacciTerm(n) {
  let previous = -1;
  let result = 0;
  let next = 1;

  for (let term = n; term > 0; term--) {
    result = previous + next;
    previous = next;
    next = result;
  }

  return result;
}

function message(term, expect, evaluatingTo) {
  const isPassing = evaluatingTo === expect ? "✅" : "❌";

  const context = " In fabonacci series " + term + " term ";
  const expected = " should be " + expect;
  const actual = " but it is " + evaluatingTo;
  
  return isPassing + context + expected + actual;
}

function testFabonacci(term, expect) {
  const evaluatingTo = nthFibonacciTerm(term);
  console.log(message(term, expect, evaluatingTo));
}

function testCases() {
  testFabonacci(1, 0);
  testFabonacci(2, 1);
  testFabonacci(3, 1);
  testFabonacci(4, 2);
  testFabonacci(5, 3);
  testFabonacci(6, 5);
  testFabonacci(7, 8);
  testFabonacci(8, 13);
}

testCases();