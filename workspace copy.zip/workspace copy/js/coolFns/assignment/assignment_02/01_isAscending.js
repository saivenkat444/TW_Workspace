// Given an array of numbers true if numbers are in strictly ascending order
// otherwise false.
// isStrictlyAscending([1, 3, 4, 5, 16]) => true
// isStrictlyAscending([1, 3, 2, 4]) => false
// isStrictlyAscending([1, 3, 3, 4]) => false

function isStrictlyAscending(numbers) {
  for (let index = 0; index < numbers.length - 1; index++) {
    if (numbers[index] >= numbers[index + 1]) {
      return false;
    }
  }
  return true;
}

function makeMessage(numbers, expected, actual) {
  let message = "the array '" + numbers;

  message = message + "' is ascending '" + expected;
  message = message + "' and it is '" + actual + "'";

  return message;
}

function testIsAsceding(numbers, expected) {
  const actual = isStrictlyAscending(numbers);
  const getMark = actual === expected ? '✅' : '❌';

  console.log(getMark + makeMessage(numbers, expected, actual));
}

function testAll() {
  testIsAsceding([1, 3, 4, 5, 16], true);
  testIsAsceding([1, 3, 4, 5, 16, 15], false);
  testIsAsceding([1, 3, 4, 5, 16, 16, 17], false);
  testIsAsceding([15, 1, 3, 4, 5, 16, 17, 18], false);
  testIsAsceding([1], true);
  testIsAsceding([], true);
}

testAll();