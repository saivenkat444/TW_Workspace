// Give an number extract its digit into array
// Number can positive, negative, floating point.
// extractDigits(123) => [1, 2, 3]
// extractDigits(-123) => [1, 2, 3]
// extractDigits(12.3) => [1, 2, 3]

function getDigits(number) {
  let candidate = Math.abs(number);
  const digits = [];

  while (candidate > 0) {
    digits.unshift(candidate % 10);
    candidate = (candidate - (candidate % 10)) / 10;
  }

  return digits;
}

export function extractDigits(number) {
  if (number === 0) {
    return [0];
  }

  return getDigits(number);
}
