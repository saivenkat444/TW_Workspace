import { text } from "../data/inputs.js";
import { part1, part2 } from "../src/mul.js";
import { assertEquals } from "jsr:@std/assert";
// Below are sample test cases. Do not limit yourself to these test cases.
// Write more test cases to make sure your implementation works as expected.

Deno.test("Part1 test", () => {
  const input =
    "xmul(2,4)%&mul[3,7]!@^do_not_mul(5,5)+mul(32,64]then(mul(11,8)mul(8,5))";
  assertEquals(part1(input), 161);
});
Deno.test("Part is invalid", () => assertEquals(part1("nothing matches"), 0));
Deno.test("text1 test", () => assertEquals(part1(text), 169021493));
Deno.test("Part2 test", () => {
  const input =
    "xmul(2,4)&mul[3,7]!^don't()_mul(5,5)+mul(32,64](mul(11,8)undo()?mul(8,5))";
  assertEquals(part2(input), 48);
});
Deno.test("text1 test for part 2", () => assertEquals(part2(text), 104887473));
