// Return all the elements of array1 which are not present in array2.
// difference([1, 2, 3], [2, 3, 4]) => [1]

function isPresent(array, target) {
  for (let index = 0; index < array.length; index++) {
    if (array[index] === target) {
      return true;
    }
  }

  return false;
}

export function difference(array1, array2) {
  const missingElements = [];

  for (let index = 0; index < array1.length; index++) {
    if (!isPresent(array2, array1[index])) {
      missingElements.push(array1[index]);
    }
  }

  return missingElements;
}

function makeMessage(array1, array2, expected, actual) {
  let message = "the array1: '" + array1 + "' the array2 : '" + array2;

  message = message + "' are '" + expected;
  message = message + "' and it is '" + actual + "'";

  return message;
}

function areEqual(array1, array2) {
  if (array1.length !== array2.length) {
    return false;
  }

  for (let index = 0; index < array1.length; index++) {
    if (array1[index] !== array2[index]) {
      return false;
    }
  }

  return true;
}

function testDifference(array1, array2, expected) {
  const actual = difference(array1, array2);
  const getMark = areEqual(actual, expected) ? '✅' : '❌';

  console.log(getMark + makeMessage(array1, array2, expected, actual));
}

function testAll() {
  testDifference([1, 2, 3], [2, 3, 4], [1]);
  testDifference([1, 2, 3], [1, 2, 3], []);
  testDifference([1, 2, 3], [3, 1, 2], []);
  testDifference([], [], []);
  testDifference([], [1, 2, 3], []);
  testDifference([1, 2, 3], [], [1, 2, 3]);

}

testAll();
