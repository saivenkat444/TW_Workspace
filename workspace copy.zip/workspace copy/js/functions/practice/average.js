const maximum = (number1, number2) => {
  return number1 > number2 ? number1 : number2;
};

function minimum(number1, number2) {
  return number1 < number2 ? number1 : number2;
}

function average(bigNumber, smallNumber) {
  if (bigNumber === smallNumber) {
    return bigNumber;
  }

  if (bigNumber < smallNumber) {
    return bigNumber + 0.5;
  }

  return average(bigNumber - 1, smallNumber + 1);
}

function averageOfTwoNumbers(number1, number2) {
  const bigNumber = maximum(number1, number2);
  const smallNumber = minimum(number1, number2);
  if (number1 > number2) {
    return average(number1, number2);
  }

  return average(bigNumber, smallNumber);
}

console.log(averageOfTwoNumbers(8, 10));
console.log(averageOfTwoNumbers(6, 10));
console.log(averageOfTwoNumbers(5, 10));
console.log(averageOfTwoNumbers(10, 10));
