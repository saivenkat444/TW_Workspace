// const object = Deno.readTextFileSync("./tryout.json");
// console.log(object);
const program = `const a = 1;
const b = 2;
console.log(a + b);`;
Deno.writeTextFileSync("./program.js", program, {
  append: true,
});
