// Assume rangeStart and rangeEnd are always greater than 0.
// rangeStart is always less than rangeEnd.

function getNumberGuessed(maxAttempts) {
  console.log("Take a guess! (Remaining attempts: " + maxAttempts + ")");
  return +prompt("");
}

function startGame(rangeStart, rangeEnd, maxAttempts) {
  console.log("Welcome to Guess the Number!\nThe secret number is between 1 and 100. You have 5 attempts to find it.");
  getNumberGuessed(maxAttempts);
}

startGame(100, 200, 6);



// accept and store the number;
// reduce atttempt by 1;
// diplay the attempts along with   mesage 
// if caught display the winning message 
// if chanes are  over display try again message;