import { assert } from "jsr:@std/assert";

Deno.test("Match any string that contains a number", () =>
  assert(/.*\d.*/.test("a123"))
);

Deno.test("Find all lowercase letters in a string.", () =>
  assert(/[a-z]/g.test("do"))
);

Deno.test('Match a string that ends with "ed"', () =>
  assert(/.*ed$/.test("matched"))
);
Deno.test('Match the word "yes" in a string.', () =>
  assert(/yes/.test("hello i am not an yes i am no"))
);
Deno.test("Find any two consecutive vowels in a string.", () =>
  assert(/[aeiou]{2}/.test("coin"))
);
Deno.test('Match any string containing the word "hello"', () =>
  assert(/.*hello.*/.test("hi i am not hello"))
);
Deno.test("Find a string that contains exactly two spaces", () =>
assert(/[^\s]\s{2}[^\s]/.test("hi  hello how")))
Deno.test('Find a string that starts with "abc"', () =>
  assert(/^abc/.test("abc"))
);
Deno.test("Match any string that contains the digit `7`.", () =>
  assert(/.*7.*/.test("seven is 7 but not eight 8"))
);
Deno.test("Find all occurrences of the letter `e`.", () =>
  assert(/e/g.test("there are 3"))
);
Deno.test("Match a string that has at least one uppercase letter", () =>
  assert(/.*[A-Z].*/.test("there are no uppercase lEtters"))
);
Deno.test("Find a string with a period (`.`) in it.", () =>
  assert(/\./.test("find.notfound"))
);
Deno.test("Match a string that contains a single space.", () =>
  assert(/^[^ ]* [^ ]*$/.test("hi helo"))
);
Deno.test("Match all words that start with the letter `c`", () =>
  assert(/\bc\w+\b/g.test("car, coin, back, ball, clock"))
);
Deno.test('Match a string that contains the sequence "123"', () =>
  assert(/.*123.*/.test("123456"))
);
Deno.test("Match a string that contains a forward slash (`/`)", () =>
  assert(/.*\/.*/.test("this contains many / / / / "))
);
Deno.test('Find all strings that contain "and".', () =>
  assert(/.*and.*/.test("thsi conatins an and"))
);
Deno.test("Match a string that starts and ends with the same letter.", () =>
  assert(/^(.).*\1$/.test("this starts and ends with t"))
);
Deno.test('Match all lowercase letters except "x" and "y"', () =>
  assert(/[a-wz]/.test("x + y is x + y but not x * y"))
);
Deno.test("Find all words in a string that are exactly 5 letters long.", () =>
  assert(/\b\w{5}\b/g.test("this is a seven"))
);
Deno.test("Match all words starting with a vowel.", () =>
  assert(/\b[aeiou]\w*\b/g.test("see only some are starting with a vowel"))
);
Deno.test("Find all sequences of two or more consecutive digits.", () =>
  assert(/(\d)\1/g.test("there are 1449 thousands of people somewhere"))
);
Deno.test("Match all words that contain exactly three letters", () =>
  assert(/\b\w{3}\b/g.test("this has two words of three charachters"))
);
Deno.test('Find all occurrences of the word "cat" or "dog".', () =>
  assert(
    /\bcat|dog\b/.test("cat is a cat but not a dog but is a cat not a dog")
  )
);
Deno.test(
  'Capture the first and last name from a string like `"John Doe"`',
  () => assert(/\b(\w+) (\w+)\b/.test("John doe"))
);
Deno.test(
  'Match strings with repeating characters (e.g., `"aa"`, `"bb"`)',
  () => assert(/(\w)\1/g.test("ball, call"))
);
Deno.test("Extract all the hashtags from a tweet.", () =>
  assert(/#\w+[^# ]/g.test("#hashtag #twitter"))
);
Deno.test('Validate a 24-hour time format like `"23:59"`', () =>
  assert(/([01][0-9]|[2][0-3]):[0-5][0-9]/.test("23:59"))
);
Deno.test("Capture the area code and phone number from `(123) 456-7890`", () =>
  assert(/^(\(\d{3}\)) (\d{3}-\d{3})/.test("(123) 456-7890"))
);
Deno.test("Find sequences of whitespace followed by a word.", () =>
  assert(/  +/g.test("hi there are  2 whitespaces"))
);
Deno.test(
  "Match strings containing at least one uppercase and one digit.",
  () => assert(/[A-Z].*\d|\d.*[A-Z]/.test("Two 2"))
);
Deno.test(" Find all non-alphanumeric characters in a string.", () =>
  assert(/[^A-z\d]*/.test("there aer many thibgs # @ ! "))
);
Deno.test("Match email addresses.", () =>
  assert(/\w+@\w+\.\w+/g.test("somehting@gmail.com"))
);
Deno.test("Validate dates in the format `YYYY-MM-DD`", () =>
  assert(/\d{4}-\d{2}-\d{2}/.test("today it is 2025-01-03"))
);
Deno.test(
  "Extract the filename and extension from a path like `/path/to/file.txt`",
  () => assert(/\w+\.\w+$/.test("/path/to/file.txt"))
);
Deno.test("Find all duplicate words in a sentence.", () => assert(/\b(\w+)\b\1/.test("")))
Deno.test('Match words that do not contain the letter "e".', () =>
  assert(/\b[a-df-z]+\b/g.test("cool clean hat mat tree"))
);
Deno.test(
  "Extract the domain name from a URL like `https://www.example.com`.",
  () => assert(/https:\/\/w+\.\w+\.\w+/.test("https://www.example.com"))
);
Deno.test("Match strings containing three consecutive vowels.", () =>
  assert(/[aeiou]{3}/.test("aei"))
);
Deno.test("Find all 4-letter palindromes in a string.", () =>
  assert(/\b(\w)(\w)\2\1\b/.test("aooa sees"))
);
