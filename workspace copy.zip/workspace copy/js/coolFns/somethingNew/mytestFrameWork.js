const giveLastChar = function (resultantString, string) {
  return resultantString + string[string.length - 1];
}

const allLastChars = function (arrayOfStrings) {
  return arrayOfStrings.reduce(giveLastChar, "");
}

function testMainFunction(args) {
  const [functionName, inputArray, expected, failed] = args;
  const actual = functionName(inputArray);
  if (actual !== expected) {
    failed.push([functionName, inputArray, expected, actual]);
  }
}

function testAllLastChars(failed) {
  testMainFunction([allLastChars, ["abc", "def"], "cf", failed]);
  testMainFunction([allLastChars, ["abc", "def"], "cf", failed]);
}


function testAll() {
  const failed = [];
  testAllLastChars(failed);

  console.table(failed);
}

testAll();