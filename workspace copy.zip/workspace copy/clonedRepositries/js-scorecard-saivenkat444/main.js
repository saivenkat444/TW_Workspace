import { ballByBall } from './data/match_1';
import { generateScoreCard } from './src/scorecard.js';

const main = () => {
  console.log(generateScoreCard(ballByBall));
};

main();
