import { describe, it } from "jsr:@std/testing/bdd";
import { assertEquals } from "jsr:@std/assert";
import { parseArgs } from "../src/parse_args.js";

describe("parseArgs(args) for only files", () => {
  it("should give the single file with default values in it", () => {
    const actual = parseArgs(["file.txt"]);
    const expected = {
      output: { option: "n", count: 10, filepaths: ["file.txt"] },
    };
    assertEquals(actual, expected);
  });
  it("should give the multiple files with default values in it", () => {
    const actual = parseArgs(["file.txt", "something.js"]);
    const expected = {
      output: {
        option: "n",
        count: 10,
        filepaths: ["file.txt", "something.js"],
      },
    };
    assertEquals(actual, expected);
  });
  it("should treat every argument as file, when file is found first", () => {
    const actual = parseArgs(["file.txt", "-n2"]);
    const expected = {
      output: {
        option: "n",
        count: 10,
        filepaths: ["file.txt", "-n2"],
      },
    };
    assertEquals(actual, expected);
  });
  it("should give single file with treating the option n with spaces as file", () => {
    const actual = parseArgs(["file.txt", "-n", "2"]);
    const expected = {
      output: {
        option: "n",
        count: 10,
        filepaths: ["file.txt", "-n", "2"],
      },
    };
    assertEquals(actual, expected);
  });
  it("should give the single file with treating the option c without space as files", () => {
    const actual = parseArgs(["file.txt", "-c2"]);
    const expected = {
      output: {
        option: "n",
        count: 10,
        filepaths: ["file.txt", "-c2"],
      },
    };
    assertEquals(actual, expected);
  });
  it("should give single file with treating the option c with spaces as files", () => {
    const actual = parseArgs(["file.txt", "-c", "2"]);
    const expected = {
      output: {
        option: "n",
        count: 10,
        filepaths: ["file.txt", "-c", "2"],
      },
    };
    assertEquals(actual, expected);
  });
});

describe("parseArgs(args) for valid option n", () => {
  it("should give a single file with 7 lines for option without space", () => {
    const actual = parseArgs(["-n7", "file.txt"]);
    const expected = {
      output: {
        option: "n",
        count: 7,
        filepaths: ["file.txt"],
      },
    };
    assertEquals(actual, expected);
  });
  it("should give a single file with 7 lines for option with space", () => {
    const actual = parseArgs(["-n", "7", "file.txt"]);
    const expected = {
      output: {
        option: "n",
        count: 7,
        filepaths: ["file.txt"],
      },
    };
    assertEquals(actual, expected);
  });
  it("should give a single file with 7 lines for option without space for multiple files", () => {
    const actual = parseArgs(["-n7", "file.txt", "something.js"]);
    const expected = {
      output: {
        option: "n",
        count: 7,
        filepaths: ["file.txt", "something.js"],
      },
    };
    assertEquals(actual, expected);
  });
  it("should give a single file with 7 lines for option with space for multiple files", () => {
    const actual = parseArgs(["-n", "7", "file.txt", "something.js"]);
    const expected = {
      output: {
        option: "n",
        count: 7,
        filepaths: ["file.txt", "something.js"],
      },
    };
    assertEquals(actual, expected);
  });
});

describe("parseArgs(args) for repeated valid option n", () => {
  it("should over ride all the previous valid inputs without space for single file", () => {
    const actual = parseArgs(["-n7", "-n8", "file.txt"]);
    const expected = {
      output: {
        option: "n",
        count: 8,
        filepaths: ["file.txt"],
      },
    };
    assertEquals(actual, expected);
  });
  it("should over ride all the previous valid inputs without space for multiple files", () => {
    const actual = parseArgs(["-n7", "-n8", "file.txt", "something.js"]);
    const expected = {
      output: {
        option: "n",
        count: 8,
        filepaths: ["file.txt", "something.js"],
      },
    };
    assertEquals(actual, expected);
  });
  it("should over ride all the previous valid inputs with space for single file", () => {
    const actual = parseArgs(["-n", "7", "-n", "8", "file.txt"]);
    const expected = {
      output: {
        option: "n",
        count: 8,
        filepaths: ["file.txt"],
      },
    };
    assertEquals(actual, expected);
  });
  it("should over ride all the previous valid inputs with space for multiple files", () => {
    const actual = parseArgs([
      "-n",
      "7",
      "-n",
      "8",
      "file.txt",
      "something.js",
    ]);
    const expected = {
      output: {
        option: "n",
        count: 8,
        filepaths: ["file.txt", "something.js"],
      },
    };
    assertEquals(actual, expected);
  });
  it("should over ride even when combination of options with different formats is applied on single file", () => {
    const actual = parseArgs(["-n", "7", "-n8", "file.txt"]);
    const expected = {
      output: {
        option: "n",
        count: 8,
        filepaths: ["file.txt"],
      },
    };
    assertEquals(actual, expected);
  });
  it("should over ride even when combination of options with different formats is applied on multiple file", () => {
    const actual = parseArgs(["-n", "7", "-n8", "file.txt", "something.js"]);
    const expected = {
      output: {
        option: "n",
        count: 8,
        filepaths: ["file.txt", "something.js"],
      },
    };
    assertEquals(actual, expected);
  });
});

describe("parseArgs(args) for valid option c", () => {
  it("should give a single file with 7 lines for option without space", () => {
    const actual = parseArgs(["-c7", "file.txt"]);
    const expected = {
      output: {
        option: "c",
        count: 7,
        filepaths: ["file.txt"],
      },
    };
    assertEquals(actual, expected);
  });
  it("should give a single file with 7 lines for option with space", () => {
    const actual = parseArgs(["-c", "7", "file.txt"]);
    const expected = {
      output: {
        option: "c",
        count: 7,
        filepaths: ["file.txt"],
      },
    };
    assertEquals(actual, expected);
  });
  it("should give a single file with 7 lines for option without space for multiple files", () => {
    const actual = parseArgs(["-c7", "file.txt", "something.js"]);
    const expected = {
      output: {
        option: "c",
        count: 7,
        filepaths: ["file.txt", "something.js"],
      },
    };
    assertEquals(actual, expected);
  });
  it("should give a single file with 7 lines for option with space for multiple files", () => {
    const actual = parseArgs(["-c", "7", "file.txt", "something.js"]);
    const expected = {
      output: {
        option: "c",
        count: 7,
        filepaths: ["file.txt", "something.js"],
      },
    };
    assertEquals(actual, expected);
  });
});

describe("parseArgs(args) for repeated valid option c", () => {
  it("should over ride all the previous valid inputs without space for single file", () => {
    const actual = parseArgs(["-c7", "-c8", "file.txt"]);
    const expected = {
      output: {
        option: "c",
        count: 8,
        filepaths: ["file.txt"],
      },
    };
    assertEquals(actual, expected);
  });
  it("should over ride all the previous valid inputs without space for multiple files", () => {
    const actual = parseArgs(["-c7", "-c8", "file.txt", "something.js"]);
    const expected = {
      output: {
        option: "c",
        count: 8,
        filepaths: ["file.txt", "something.js"],
      },
    };
    assertEquals(actual, expected);
  });
  it("should over ride all the previous valid inputs with space for single file", () => {
    const actual = parseArgs(["-c", "7", "-c", "8", "file.txt"]);
    const expected = {
      output: {
        option: "c",
        count: 8,
        filepaths: ["file.txt"],
      },
    };
    assertEquals(actual, expected);
  });
  it("should over ride all the previous valid inputs with space for multiple files", () => {
    const actual = parseArgs([
      "-c",
      "7",
      "-c",
      "8",
      "file.txt",
      "something.js",
    ]);
    const expected = {
      output: {
        option: "c",
        count: 8,
        filepaths: ["file.txt", "something.js"],
      },
    };
    assertEquals(actual, expected);
  });
  it("should over ride even when combination of options with different formats is applied on single file", () => {
    const actual = parseArgs(["-c", "7", "-c8", "file.txt"]);
    const expected = {
      output: {
        option: "c",
        count: 8,
        filepaths: ["file.txt"],
      },
    };
    assertEquals(actual, expected);
  });
  it("should over ride even when combination of options with different formats is applied on multiple file", () => {
    const actual = parseArgs(["-c", "7", "-c8", "file.txt", "something.js"]);
    const expected = {
      output: {
        option: "c",
        count: 8,
        filepaths: ["file.txt", "something.js"],
      },
    };
    assertEquals(actual, expected);
  });
});

describe("parseArgs(args) for illegal count error", () => {
  it("should give the error when no number is given for with space format for c", () => {
    const actual = parseArgs(["-c", "file.txt"]);
    const expected = {
      error: { type: "invalid count", token: "file.txt" },
    };
    assertEquals(actual, expected);
  });
  it("should give the error when no number is given for without space format for c", () => {
    const actual = parseArgs(["-csomething", "file.txt"]);
    const expected = {
      error: { type: "invalid count", token: "something" },
    };
    assertEquals(actual, expected);
  });
  it("should give the error when no number is given for with space format for n", () => {
    const actual = parseArgs(["-n", "file.txt"]);
    const expected = {
      error: { type: "invalid count", token: "file.txt" },
    };
    assertEquals(actual, expected);
  });
  it("should give the error when no number is given for without space format for n", () => {
    const actual = parseArgs(["-nsomething", "file.txt"]);
    const expected = {
      error: { type: "invalid count", token: "something" },
    };
    assertEquals(actual, expected);
  });
});

describe("parseArgs(args) for option error", () => {
  it("should give the error when no number is given for with space format for c", () => {
    const actual = parseArgs(["-C", "file.txt"]);
    const expected = {
      error: { type: "invalid option", token: "C" },
    };
    assertEquals(actual, expected);
  });
  it("should give the error when no number is given for without space format for c", () => {
    const actual = parseArgs(["-N", "file.txt"]);
    const expected = {
      error: { type: "invalid option", token: "N" },
    };
    assertEquals(actual, expected);
  });
  it("should give the error when no number is given for with space format for n", () => {
    const actual = parseArgs(["-something", "file.txt"]);
    const expected = {
      error: { type: "invalid option", token: "s" },
    };
    assertEquals(actual, expected);
  });
  // it("should give the error when no number is given for without space format for n", () => {
  //   const actual = parseArgs(["-1", "file.txt"]);
  //   const expected = {
  //     error: { type: "invalid option", token: "1" },
  //   };
  //   assertEquals(actual, expected);
  // });
});

describe("parseArgs(args) should give the default case", () => {
  it("should not give any file paths", () => {
    const actual = parseArgs([]);
    const expected = { option: "n", count: 10, filepaths: [] };
    assertEquals(actual, expected);
  });
});
