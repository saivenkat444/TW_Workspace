// Remove first n elements from the array
// drop([1, 2, 3], 1) => [2, 3]
// drop([1, 2, 3], 4) => []
// Do not modify the original array

function drop(arrary, n) {
  const elementsDroppedArray = [];

  for (let times = n; times < arrary.length; times++) {
    elementsDroppedArray.push(arrary[times]);
  }

  return elementsDroppedArray;
}

function makeMessage(array1, terms, expected, actual) {
  let message = "the array1: '" + array1 + "' dropped times : '" + terms;

  message = message + "' are '" + expected;
  message = message + "' and it is '" + actual + "'";

  return message;
}

function areEqual(array1, array2) {
  if (array1.length !== array2.length) {
    return false;
  }

  for (let index = 0; index < array1.length; index++) {
    if (array1[index] !== array2[index]) {
      return false;
    }
  }

  return true;
}

function testDrop(array1, terms, expected) {
  const actual = drop(array1, terms);
  const getMark = areEqual(actual, expected) ? '✅' : '❌';

  console.log(getMark + makeMessage(array1, terms, expected, actual));
}

function testAll() {
  testDrop([1, 2, 3], 1, [2, 3]);
  testDrop([1, 2, 3], 2, [3]);
  testDrop([1, 2, 3], 0, [1, 2, 3]);
  testDrop([1, 2, 3], 3, []);
  testDrop([], 3, []);
}

testAll();
