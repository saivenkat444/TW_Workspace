import { readFile } from "./read_file.js";
import { fetchNLines, fetchNchars } from "./fetch_content.js";

const invalidFile = (token) => {
  return `head: ${token} no such file or directory`;
};

const invalidCount = (token) => {
  return `head: illegal line count -- ${token}`;
};

const invalidOption = (token) => {
  return `head: invalid option -- ${token}
usage: head [-n lines | -c bytes] [file ...]`;
};

const errorMessagesFormat = (type, token) => {
  return {
    "invalid file": invalidFile(token),
    "invalid count": invalidCount(token),
    "invalid option": invalidOption(token),
  }[type];
};

const fileContent = ({ ...fileContent }) => {
  return `==>${fileContent.fileName}<==
  ${fileContent.content}`;
};

const printOutputAnddetermineExit = ({ ...individualContent }) => {
  if ("error" in individualContent) {
    const { type, token } = individualContent.error;
    Deno.exitCode = 1;
    return displayError(type, token);
  }

  return displayContent(individualContent);
};

export const generateExitCodeAndPrint = (content) => {
  return content.map(printOutputAnddetermineExit);
};

const options = {
  n: fetchNLines,
  c: fetchNchars,
};

export const fetchContent = (optionType, count, filePath) => {
  try {
    const content = readFile(filePath);
    return { fileName: filePath, content: options[optionType](count, content) };
  } catch {
    return { error: { type: "invalid file", token: filePath } };
  }
};

const displayContent = (individualContent) => {
  return fileContent(individualContent);
};

const displayError = (type, token) => {
  return errorMessagesFormat(type, token);
};

export const head = (parsedArgs) => {
  if ("error" in parsedArgs) {
    const { type, token } = parsedArgs.error;
    Deno.exitCode = 1;
    return displayError(type, token);
  }

  const { filepaths, option, count } = parsedArgs.output; // why output?
  const contents = filepaths.map((filePath) =>
    fetchContent(option, count, filePath)
  );

  return generateExitCodeAndPrint(contents).join("");
};
