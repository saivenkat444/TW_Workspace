let terms=5;
let lastTerm=0;
for(terms;terms>0;terms--){
    console.log(lastTerm)
    lastTerm=lastTerm+1
}