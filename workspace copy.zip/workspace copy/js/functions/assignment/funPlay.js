const a = "a";
const hi = "hi";
const b = 9;

console.log(add(a,b));
console.log("going good");
function add (a,b){
    const hi = "bye";
    return a + b;
}

console.log(hi);