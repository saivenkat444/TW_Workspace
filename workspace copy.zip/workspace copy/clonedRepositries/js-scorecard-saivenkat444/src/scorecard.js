import { ballByBall } from "../data/match_1.js";
import { batter, bowler, team } from "./templates.js";

export const getAllDeliveries = (innings) =>
  innings.map((inning) => inning.overs.flatMap((overs) => overs.deliveries));

const updateBallsPlayed = (extras) =>
  extras?.no_ball || extras?.wides ? 0 : 1;
const updateBoundaries = ({ batter, non_bounday = false }, type) =>
  batter === type && !non_bounday ? 1 : 0;

const updateBatter = (batterDetails, deliveryDetails) => {
  batterDetails.runs += deliveryDetails.runs.batter;
  batterDetails.balls += updateBallsPlayed(deliveryDetails.extras);
  batterDetails.fours += updateBoundaries(deliveryDetails.runs, 4);
  batterDetails.sixes += updateBoundaries(deliveryDetails.runs, 6);
};

const fielderfunction = (something) =>
  something?.fielders ? something.fielders.map(({ name }) => name) : [];

const updateDismissal = (batterList, ballDetail) => {
  if ("wickets" in ballDetail) {
    const something = ballDetail.wickets[0];
    batterList[something.player_out].dismissal = {
      kind: something.kind,
      // console.log("kind", kind)

      fielders: fielderfunction(something),
      bowler: ballDetail.bowler,
    };
  }
  // return {
  //   caught: `c ${fielderName} b ${bowlerName}`,
  //   bowled: `b ${bowlerName}`,
  //   "run out": `c ${fielderName}`,
  // }[type];
};

const countOvers = (ballDetail) => {
  if (ballDetail?.extras ? "wides" in ballDetail.extras : false) {
    // if ("wides" in ballDetail.extras || "no_ball" in ballDetail.extras) {
    return 0;
  }
  return 1;
};

const convertIntoOvers = (totalBalls) =>
  Math.floor(totalBalls / 6) + 0.1 * (totalBalls % 6);

const updateRunsGiven = (extras) => {
  const wides = extras?.wides ? extras.wides : 0;
  const no_ball = extras?.no_ball ? extras.no_ball : 0;
  const byes = extras?.byes ? extras.byes : 0;
  const legbyes = extras?.legbyes ? extras.legbyes : 0;
  return wides + no_ball + byes + legbyes;
};

const checkWicket = (wickets) => {
  return wickets[0].kind === "run out" ? 0 : 1;
};

const updateBowler = (bowlerDetails, ballDetail) => {
  bowlerDetails.balls += countOvers(ballDetail);
  bowlerDetails.overs = convertIntoOvers(bowlerDetails.balls);
  bowlerDetails.runsgiven +=
    ballDetail.runs.batter + updateRunsGiven(ballDetail.extras);
  bowlerDetails.wicketsTaken += ballDetail?.wickets
    ? checkWicket(ballDetail.wickets)
    : 0;
};

const mergeWith = (o1, o2, f) => {
  const res = { ...o1 };
  for (const [k, v] of Object.entries(o2)) {
    res[k] = res[k] ? f(res[k], v) : v;
  }
  return res;
};

const add = (a, b) => a + b;

const getScoreCard = (innings, name) => {
  console.log(name);
  const teamCardList = team();
  const batterList = {};
  const bowlerList = {};
  teamCardList.teamName = name;
  innings.forEach((ball) => {
    if (!(ball.batter in batterList)) {
      batterList[ball.batter] = batter();
    }
    if (!(ball.non_striker in batterList)) {
      batterList[ball.non_striker] = batter();
    }
    if (!(ball.bowler in bowlerList)) {
      bowlerList[ball.bowler] = bowler();
    }
    updateDismissal(batterList, ball);
    updateBatter(batterList[ball.batter], ball);
    updateBowler(bowlerList[ball.bowler], ball);
    teamCardList.runs += ball.runs.total;
    teamCardList.wicketsTaken += ball?.wickets ? ball.wickets.length : 0;
    if ("extras" in ball)
      teamCardList.extras = mergeWith(teamCardList.extras, ball.extras, add);
  });
  return [teamCardList, batterList, bowlerList];
};

export const generateScoreCard = (ballByBall) => {
  const innings = ballByBall.innings;
  const ballsData = getAllDeliveries(innings);

  return ballsData.map((inning, index) =>
    getScoreCard(inning, innings[index].team)
  );
};

console.log(generateScoreCard(ballByBall));
