const incrementIndex = function (currentPlayerIndex, length) {
  return (currentPlayerIndex + 1) % length;
};

const diffuseBombIfPresent = function (playerName, playerCards) {
  console.log(`${playerName} defused the bomb!`);
  const diffCardIndex = playerCards.indexOf("DIFFUSE");
  if (diffCardIndex > -1) {
    playerCards.splice(diffCardIndex, 1);
  }
};

const bombCard = function (players, playerName, playerCards) {
  console.log("i am working");

  if (playerCards.includes("DIFFUSE")) {
    diffuseBombIfPresent(playerName, playerCards);
    return players;
  }

  console.log(`${playerName} exploded! Game over for them.`);
  return players.filter((player) => player.name !== playerName);
};
const initializeAction = function (playerName, playerCards, deck) {
  const cardToPlay = prompt("Enter the card name to play:");
  let skipTurn = false;

  if (playerCards.includes(cardToPlay)) {
    performAction(currentPlayer, cardToPlay, players, deck);
    if (cardToPlay === "ATTACK") {
      console.log(`${playerName} attacks the next player!`);
      skipTurn = true;
    }

    if (cardToPlay === "SKIP") {
      console.log(`${playerName} skips their turn.`);
      skipTurn = true;
    }

    const cardIndex = playerCards.indexOf(cardToPlay);
    if (cardIndex > -1) {
      playerCards.splice(cardIndex, 1);
    }

    if (!skipTurn) {
      const drawnCard = deck.shift();
      console.log(`${playerName} draws ${drawnCard}`);

      if (drawnCard === "BOMB") {
        bombCard(playerName, playerCards);
      }
      //   console.log("i am working");
      //   const bombCardIndex = playerCards.indexOf("BOMB");
      //   playerCards.splice(bombCardIndex, 1);
      //   if (playerCards.includes("DIFFUSE")) {
      //     console.log(`${playerName} defused the bomb!`);
      //     const diffCardIndex = playerCards.indexOf("DIFFUSE");
      //     if (diffCardIndex > -1) {
      //       playerCards.splice(diffCardIndex, 1);
      //     }
      //   } else {
      //     console.log(
      //       `${currentPlayer.playerName} exploded! Game over for them.`
      //     );
      //     players = players.filter((player) => player.name !== playerName);
      //   }
    }
    playerCards.push(drawnCard);
  }
};

export const game = (players, deck) => {
  let currentPlayerIndex = 0;
  const getCurrentPlayer = () => players[currentPlayerIndex];

  while (true) {
    if (players.length === 1) {
      return `${players[0].name} WON THE GAME`;
    }

    const currentPlayer = getCurrentPlayer();
    console.log(`${currentPlayer.name}'s turn`);
    console.log("Your cards:", currentPlayer.cards);

    if (confirm("Choose an action (draw a card):")) {
      initializeAction(currentPlayer.name, currentPlayer.cards, deck);
      console.log("You don't have that card. Please try again.");
      continue;
    }
    const drawnCard = deck.shift();
    console.log(`${currentPlayer.name} draws ${drawnCard}`);
    if (drawnCard === "BOMB") {
      players = bombCard(
        players,
        currentPlayer.name,
        currentPlayer.cards,
        drawnCard
      );
      currentPlayerIndex = incrementIndex(currentPlayerIndex, players.length);

      // currentPlayerIndex = (currentPlayerIndex + 1) % players.length;
      continue;
    }
    currentPlayer.cards.push(drawnCard);
    currentPlayerIndex = incrementIndex(currentPlayerIndex, players.length);
  }
};
