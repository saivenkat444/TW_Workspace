*** try to use starts with ***
###advice###
Play with the head and observe the properties 

Then pull the functionality into a function  and deal them separately 
You can maintain the head functionality as it is 

Give the function a good name so that it can tell you what it does and everything


When created you will be aware of the functioning and you can read it fully



for the function:
1. check the option 
2. then check the file name 
3. then throw the output either error or the output 


1.description 