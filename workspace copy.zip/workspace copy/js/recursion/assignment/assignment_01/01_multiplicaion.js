function multiply(multiplier, multiplicand) {
  if (multiplicand === 0) {
    return 0;
  }

  return multiplier + multiply(multiplier, multiplicand - 1);
}

function makeMessage(multiplier, multiplicand, expected, actual) {
  let message = "the multiplier is " + multiplier;

  message = message + " the multiplicand is " + multiplicand;
  message = message + " the result is expected to be " + expected;
  message = message + " and it is " + actual;

  return message;
}

function testMultiply(multiplier, multiplicand, expected) {
  const actual = multiply(multiplier, multiplicand);
  
  console.log(actual === expected ? '✅' : '❌');
  console.log(makeMessage(multiplier, multiplicand, expected, actual));
}

function testMultiplication() {
  testMultiply(2, 1, 2);
  testMultiply(1, 2, 2);
  testMultiply(0, 0, 0);
  testMultiply(2, 0, 0);
  testMultiply(0, 2, 0);
  testMultiply(2, 2, 4);
}

function testAll() {
  testMultiplication();
}

testAll();  