/*
  Write a function that returns the first prime number above given number
  
  Examples:
    firstPrimeAbove(3) => 5
    firstPrimeAbove(0) => 2
    firstPrimeAbove(15) => 17

  **Your function must return a value**

  It's not necessary to print the result on screen, 
  however to test your function you are free to print the result
*/

function isDivisible(numerator, denominator) {
  return numerator % denominator === 0;
}

function isPrime(number) {
  for (let isDivisibleWith = 2; isDivisibleWith < number; isDivisibleWith++) {
    if (isDivisible(number, isDivisibleWith)) {
      return false;
    }
  }

  return true;
}

function firstPrimeAbove(number) {
  number = number > 0 ? number + 1 : 2;

  while(!isPrime(number)) {
    number = number + 1;
  }

  return number;
}

function message(number, expect, evaluatingTo) {
  const isPassing = evaluatingTo === expect ? "✅" : "❌";

  const context = " number " + number;
  const expected = " it's prime should be " + expect;
  const actual = " it is " + evaluatingTo;
  return isPassing + context + expected + actual;
}

function testPrimeAbove(number, expect) {
  const evaluatingTo = firstPrimeAbove(number);
  console.log(message(number, expect, evaluatingTo));
}

function testCases() {
  testPrimeAbove(1, 2);
  testPrimeAbove(2, 3);
  testPrimeAbove(3, 5);
  testPrimeAbove(4, 5);
  testPrimeAbove(5, 7);
  testPrimeAbove(0, 2);
  testPrimeAbove(24, 29);
}

testCases();
