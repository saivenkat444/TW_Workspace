const isOdd = function (number) {
  return number & 1 === 1;
}

const isNegative = function (number) {
  return (number < 0);
}

const greaterThan100 = function (number) {
  return number > 100;
}

const sizeIsLesserThan3 = function(string) {
  return (string.length < 3);
}

const verifyAllElements = function (array, predicate) {
  for (const element of array) {
    if (predicate(element)) {
      return false;
    }
  }

  return true;
}

const atleastOneElementFound = function (array, predicate) {
  for (const element of array) {
    if (predicate(element)) {
      return true;
    }
  }

  return false;
}

const array = [1, 2, 3, 4];
const array2 = [2, 4];
const array3 = [1, 2, -3];
const array4 = [1, 2, 101];
const array5 = ["hi", "hi"];
const array6 = ["hello", "hello"];
console.log(atleastOneElementFound(array, isOdd));
console.log(atleastOneElementFound(array2, isOdd));
console.log(verifyAllElements(array3, isNegative));
console.log(verifyAllElements(array2, isNegative));
console.log(atleastOneElementFound(array4, greaterThan100));
console.log(atleastOneElementFound(array, greaterThan100));
console.log(verifyAllElements(array5, sizeIsLesserThan3));
console.log(verifyAllElements(array6, sizeIsLesserThan3));