import * as Assertion from "jsr:@std/assert";
import { isStrictlyAscending } from "./01_strictly_ascending.js";

Deno.test("everything is ascending should be true", () =>
  Assertion.assert(isStrictlyAscending([1, 3, 4, 5, 16]))
);
Deno.test("one element is not in ascending should be false", () =>
  Assertion.assertFalse(isStrictlyAscending([1, 3, 5, 4, 16]))
);
Deno.test("two elements in the ascending should be true", () =>
  Assertion.assert(isStrictlyAscending([1, 3]))
);
Deno.test("two elements in the descending should be false", () =>
  Assertion.assertFalse(isStrictlyAscending([3, 1]))
);
Deno.test("two elements are same and adjacent should be false", () =>
  Assertion.assertFalse(isStrictlyAscending([1, 3, 4, 5, 16, 16, 17]))
);
Deno.test("only one element in the array should be true", () =>
  Assertion.assert(isStrictlyAscending([1]))
);
Deno.test("nothing in the array shoud be true", () =>
  Assertion.assert(isStrictlyAscending([]))
);
