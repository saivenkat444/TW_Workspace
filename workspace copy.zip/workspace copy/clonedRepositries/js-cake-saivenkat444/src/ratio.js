export class Ratio {
  #numerator;
  #denominator;
  constructor(dividend, divisor) {
    this.#numerator = dividend;
    this.#denominator = divisor;
  }
  add(ratio) {
    const numerator =
      this.#numerator * ratio.#denominator +
      this.#denominator * ratio.#numerator;
    const denominator = this.#denominator * ratio.#denominator;
    return new Ratio(numerator, denominator);
  }

  sub(ratio) {
    // return {
    //   numerator:
    //     this.#numerator * ratio.#denominator -
    //     this.#denominator * ratio.#numerator,
    //   denominator: this.#denominator * ratio.#denominator,
    // };
  }

  simplify() {}

  toString() {
    return `${this.#numerator}/${this.#denominator}`;
  }
}
