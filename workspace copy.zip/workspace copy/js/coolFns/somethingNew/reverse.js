const array = [1, 2, 3];

const reverse =  function (result, element) {
  return [element, ...result];
}

const reversedArray = function (array) {
  return array.reduce(reverse, []);
}

console.log(reversedArray(array));