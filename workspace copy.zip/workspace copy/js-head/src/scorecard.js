import { ballByBall } from "../data/match_1.js";
import { batter, bowler, team } from "./templates.js";

export const getAllDeliveries = (innings) =>
  innings.map((inning) => inning.overs.flatMap((overs) => overs.deliveries));

const isLegalDelivery = (extras) => (extras?.no_ball || extras?.wides ? 0 : 1);

const isABoundary = ({ batter, non_bounday = false }, type) =>
  batter === type && !non_bounday ? 1 : 0;

export const updateBatter = (deliveryDetails) => {
  const batterDetails = {};
  batterDetails.runs = deliveryDetails.runs.batter;
  batterDetails.balls = isLegalDelivery(deliveryDetails.extras);
  batterDetails.fours = isABoundary(deliveryDetails.runs, 4);
  batterDetails.sixes = isABoundary(deliveryDetails.runs, 6);
  return batterDetails;
};

const fielderfunction = (something) =>
  something?.fielders ? something.fielders.map(({ name }) => name) : [];

const updateDismissal = (batterList, ballDetail) => {
  if ("wickets" in ballDetail) {
    const something = ballDetail.wickets[0];
    batterList[something.player_out].dismissal = {
      kind: something.kind,
      // console.log("kind", kind)

      fielders: fielderfunction(something),
      bowler: ballDetail.bowler,
    };
  }
  // return {
  //   caught: `c ${fielderName} b ${bowlerName}`,
  //   bowled: `b ${bowlerName}`,
  //   "run out": `c ${fielderName}`,
  // }[type];
};

const countOvers = (ballDetail) => {
  return (ballDetail?.extras ? "wides" in ballDetail.extras : false) ? 0 : 1;
};

const convertIntoOvers = (totalBalls) =>
  Math.floor(totalBalls / 6) + 0.1 * (totalBalls % 6);

const updateRunsGiven = (extras) => {
  const wides = extras?.wides ? extras.wides : 0;
  const no_ball = extras?.no_ball ? extras.no_ball : 0;
  const byes = extras?.byes ? extras.byes : 0;
  const legbyes = extras?.legbyes ? extras.legbyes : 0;
  return wides + no_ball + byes + legbyes;
};

const checkWicket = (wickets) => {
  return wickets[0].kind === "run out" ? 0 : 1;
};

const updateBowler = (ballDetail) => {
  const bowlerDetails = {};
  bowlerDetails.balls = countOvers(ballDetail);
  bowlerDetails.runsgiven =
    ballDetail.runs.batter + updateRunsGiven(ballDetail.extras);
  bowlerDetails.wicketsTaken = ballDetail?.wickets
    ? checkWicket(ballDetail.wickets)
    : 0;
  return bowlerDetails;
};

const mergeWith = (o1, o2, f) => {
  const res = { ...o1 };
  for (const [k, v] of Object.entries(o2)) {
    res[k] = res[k] ? f(res[k], v) : v;
  }
  return res;
};

const add = (a, b) => a + b;

const getScoreCard = (innings, name) => {
  const teamCardList = team();
  const batterList = {};
  const bowlerList = {};
  teamCardList.teamName = name;
  innings.forEach((ball) => {
    if (!(ball.batter in batterList)) {
      batterList[ball.batter] = batter(ball.batter);
    }
    if (!(ball.non_striker in batterList)) {
      batterList[ball.non_striker] = batter(ball.non_striker);
    }
    if (!(ball.bowler in bowlerList)) {
      bowlerList[ball.bowler] = bowler(ball.bowler);
    }
    updateDismissal(batterList, ball);
    const batterStats = updateBatter(ball);
    batterList[ball.batter] = mergeWith(
      batterList[ball.batter],
      batterStats,
      add
    );
    const bowlerStats = updateBowler(ball);
    bowlerList[ball.bowler] = mergeWith(
      bowlerList[ball.bowler],
      bowlerStats,
      add
    );
    teamCardList.runs += ball.runs.total;
    teamCardList.wicketsTaken += ball?.wickets ? ball.wickets.length : 0;
    if ("extras" in ball)
      teamCardList.extras = mergeWith(teamCardList.extras, ball.extras, add);
  });
  return [teamCardList, batterList, bowlerList];
};

export const generateScoreCard = (ballByBall) => {
  const innings = ballByBall.innings;
  const ballsData = getAllDeliveries(innings);

  return ballsData.map((inning, index) =>
    getScoreCard(inning, innings[index].team)
  );
};
