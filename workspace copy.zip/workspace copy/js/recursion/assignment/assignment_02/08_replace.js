function replacedString(text, target, replacement, index) {
  if (index > text.length - 1) {
    return "";
  }

  let nextCharacter = text[index] === target ? replacement : text[index];

  return nextCharacter + replacedString(text, target, replacement, index + 1);
}

function replace(text, target, replacement) {
  if (text.length === 0 || target.length === 0) {
    return text;
  }

  return replacedString(text, target, replacement, 0);
}

function makeMessage(string, target, replacement, expected, actual) {
  let message = "the string '" + string + "' character " + target;
  
  message = message + " replaced with '" + replacement
  message = message + "' is expected to be '" + expected;
  message = message + "' and it is '" + actual + "'";

  return message;
}

function testReplaceString(string, target, replacement, expected) {
  const actual = replace(string, target, replacement);
  const getMark  = actual === expected ? '✅' : '❌';
  const note = makeMessage(string, target, replacement, expected, actual);
  
  console.log(getMark + note);
}

function testAll() {
  testReplaceString("hello world", " ", "_", "hello_world");
  testReplaceString("hello world", "l", "z", "hezzo worzd");
  testReplaceString("hello world", " ", "", "helloworld");
  testReplaceString("hello world", "", "hello", "hello world");
}

testAll();

