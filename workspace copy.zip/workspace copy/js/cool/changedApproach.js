function convertIntoArray(string) {
  return string.split();
}

function createRow(size) {
  const contentInRow = [];

  for (let length = 1; length <= size; length++) {
    contentInRow.push(convertIntoArray(" "));
  }

  return contentInRow;
}

function screenForShape(height, width) {
  const screen = [];
  for (let row = 1; row <= height; row++) {
    screen.push(createRow(width));
  }

  return screen;
}

function screen(shape1Dimensions, shape2Dimensions) {
  let shape1Outline = screenForShape(shape1Dimensions[0], shape1Dimensions[1]);
  const shape2Outline = screenForShape(shape2Dimensions[0], shape2Dimensions[1]);
  const screen = [];

  for (let index = 0; index < shape1Dimensions[0]; index++) {
    let row = shape1Outline[index];
    row.push([" "]);
    row = row.concat(shape2Outline[index]);
    screen.push(row);
  }

  return screen;
}

function testScreenForShape() {
  console.log(screenForShape(3, 3));
  console.log(screenForShape(2, 2));
  console.log(screenForShape(1, 1));
  console.log(screenForShape(0, 0));
  console.log(screenForShape(0, 1));
  console.log(screenForShape(1, 0));
  console.log(screenForShape(1, 3));
}

// console.log(screen([3, 3], [3,3]))
// console.log(screen([4, 4], [4,4]))
// console.log(screen([4, 4], [4,3]))

// testScreenForShape();