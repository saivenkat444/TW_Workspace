const parseTransactionLines = (allCustomers) =>
  allCustomers
    .split("\n")
    // .map((line) => line.trim())
    // .filter((line) => line !== "")
    .map(Number);

const parseCustomers = (customerData) => {
  return customerData.split("\n").map((customerEntry) => {
    const [name, ...filePaths] = customerEntry.split(",");
    return { name, filePaths };
  });
};

const generateBalanceAndCount = (fileTransactions) => {
  const totalTransactions = fileTransactions.length;
  const balance = fileTransactions.reduce((total, amount) => total + amount, 0);
  return { totalTransactions, balance };
};

//is naming for the below function is good?
const generateSummaryForFile = (filePath) =>
  Deno.readTextFile(filePath)
    .then(parseTransactionLines)
    .then(generateBalanceAndCount);

const fetchCustomerTransactions = ({ name, filePaths }) => {
  return Promise.all(
    filePaths.map((filePath) => generateSummaryForFile(filePath))
  ).then((customerTransactions) => {
    return { name, customerTransactions };
  });
};

const fetchAllCustomerTransactions = (customers) =>
  Promise.all(customers.map(fetchCustomerTransactions));

const convertToCSV = (allSummary) => {
  return allSummary
    .map(({ name, totalTransactions, balance }) => {
      return [name, totalTransactions, balance].join(",");
    })
    .join("\n");
};

const pushToCSV = (filePath, CSVText) => Deno.writeTextFile(filePath, CSVText);

const loadIntoFile = (filePath) => (allTransactionSummaries) => {
  return Promise.all(allTransactionSummaries)
    .then(convertToCSV)
    .then((CSVText) => pushToCSV(filePath, CSVText));
};

const mergeTransactions = (total, transaction) => {
  return {
    totalTransactions: total.totalTransactions + transaction.totalTransactions,
    balance: total.balance + transaction.balance,
  };
};

const aggregateTransactions = (transactions) =>
  transactions.reduce(mergeTransactions, {
    totalTransactions: 0,
    balance: 0,
  });

const summarizeAllTransactions = ({ name, customerTransactions }) => {
  return Promise.all(customerTransactions).then((transactions) => {
    const summary = aggregateTransactions(transactions);
    return { name, ...summary };
  });
};

const summarizeAllCustomers = (allCustomersData) => {
  const transactionSummaries = allCustomersData.map(summarizeAllTransactions);
  return Promise.all(transactionSummaries);
};

const main = () => {
  Deno.readTextFile("./data/small_data/customers.csv")
    .then(parseCustomers)
    .then(fetchAllCustomerTransactions)
    .then(summarizeAllCustomers)
    // .then(loadIntoFile("./results.csv"));
    .then(console.log);
};

main();
