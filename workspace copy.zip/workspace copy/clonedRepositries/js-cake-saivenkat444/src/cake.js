import { Ratio } from './ratio.js';
const r1 = new Ratio;
const test = (r1 instanceof Ratio)
console.log(test);

function main() {
  const sugarPart = new Ratio(1, 3);
  const eggPart = new Ratio(1, 4);
  console.log(sugarPart, eggPart)
  const totalMixture = new Ratio(2, 2);
  console.log(sugarPart.add(eggPart))
  console.log(sugarPart.sub(eggPart))
  const flourPart = totalMixture.sub(sugarPart.add(eggPart));
  console.log('flour part:', flourPart.simplify().toString());
  // Answer is 5/12
}

main();
