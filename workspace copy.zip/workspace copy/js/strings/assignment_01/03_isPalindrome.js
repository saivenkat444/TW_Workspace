// Do not rename string, use it as input for your program.
// While testing we will change it's value.
const string = "aba";
// Print true if the given string is palindrome otherwise false
// START YOUR CODE AFTER THIS LINE. DO NOT REMOVE THIS LINE

let reversedString = "";

for (let lengthOfString = (string.length - 1); lengthOfString >= 0; lengthOfString--) {
    reversedString = reversedString + string[lengthOfString];
}

const output = string === reversedString;
console.log(output);