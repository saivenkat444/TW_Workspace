// function reverse(string, index, revString) {
//   if (index === string.length) {
//     return revString;
//   }
//   revString = string[index] + revString;

//   return reverse(string, index + 1, revString);
// }

function reverse(string, index = 0) {
  if (index === string.length) {
    return "";
  }
  
  return reverse(string, index + 1) + string[index];
}
// function assignString() {
//   return "hello";
// }

console.log(reverse ("salaamwaalequm"));
// console.log(reverse ("racecar", startIndex, ""));
// console.log(reverse ("", startIndex, ""));
// console.log(reverse (" ", startIndex, ""));
// console.log(reverse ("  ", startIndex, ""));
// console.log(reverse ("a   b     ", startIndex, ""));
// console.log(reverse ("      a      b     ", startIndex, ""));