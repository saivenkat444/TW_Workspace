const myPromise = new Promise((resolve, reject) => {
  return setTimeout(() => {
    reject(2);
  }, 1000);
});

console.log(myPromise);
