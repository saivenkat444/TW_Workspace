const packOrder = (order) => {
  new Promise((resolve) => {
    order.details = "biryani";
    resolve(order);
  });
};

const prepareOrder = (order) => {
  new Promise((resolve) => {
    order.id = "123";
    resolve(order);
  });
};

const createOrder = (order) => {
  new Promise((resolve) => {
    order.time = '05:36 am';
    resolve(order);
  });
};

const order = createOrder({});

then(prepareOrder).then(packOrder);

console.log(food);
