// concat the given arrays.
// concat([1, 2, 3], [4, 5, 6]) => [1, 2, 3, 4, 5, 6]

function clone(array) {
  const copyOfArray = [];

  for (let index = 0; index < array.length; index++) {
    copyOfArray.push(array[index]);
  }

  return copyOfArray;
}

function concat(array1, array2) {
  const concatenated = clone(array1);

  for (let index = 0; index < array2.length; index++) {
    concatenated.push(array2[index]);
  }

  return concatenated;
}

function makeMessage(array1, array2, expected, actual) {
  let message = "the array1: '" + array1 + "' the array2 : '" + array2;

  message = message + "' are '" + expected;
  message = message + "' and it is '" + actual + "'";

  return message;
}

function areEqual(array1, array2) {
  if (array1.length !== array2.length) {
    return false;
  }

  for (let index = 0; index < array1.length; index++) {
    if (array1[index] !== array2[index]) {
      return false;
    }
  }

  return true;
}

function testConcat(array1, array2, expected) {
  const actual = concat(array1, array2);
  const getMark = areEqual(actual, expected) ? '✅' : '❌';

  console.log(getMark + makeMessage(array1, array2, expected, actual));
}

function testAll() {
  testConcat([1, 2, 3], [4, 5, 6], [1, 2, 3, 4, 5, 6]);
  testConcat([], [], []);
  testConcat([1], [], [1]);
  testConcat([], [1], [1]);
  testConcat([1], [1], [1, 1]);
}

testAll();