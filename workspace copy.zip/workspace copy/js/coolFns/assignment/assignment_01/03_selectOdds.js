// Given an array of numbers return a new array containing only odd elements
// original array.
// selectOdds([3, 2, 4, 5, 7]) => [3, 5, 7]
// selectOdds([2, 4, 6]) => []
// Do not modify the input array.
function selectOdds(numbers) {
  const odds = [];

  for (let index = 0; index < numbers.length; index++) {
    if (numbers[index] % 2 === 1) {
      odds[odds.length] = numbers[index];
    }
  }

  return odds;
}

function makeMessage(array, expected, actual) {
  let message = "the odds in the array: '" + array;

  message = message + "' are '" + expected;
  message = message + "' and it is '" + actual + "'";

  return message;
}

function areEqual(array1, array2) {
  if (array1.length !== array2.length) {
    return false;
  }

  for (let index = 0; index < array1.length; index++) {
    if (array1[index] !== array2[index]) {
      return false;
    }
  }

  return true;
}

function testSelectOdds(array, expected) {
  const actual = selectOdds(array);
  const getMark = areEqual(actual, expected) ? '✅' : '❌';

  console.log(getMark + makeMessage(array, expected, actual));
}

function testAll() {
  testSelectOdds([1, 2, 3], [1, 3]);
  testSelectOdds([1, 5, 7, 9], [1, 5, 7, 9]);
  testSelectOdds([], []);
  testSelectOdds(["aakash"], []);
  testSelectOdds(["aakash", 1, 2, 3, "5"], [1, 3, "5"]);
}

testAll();