// Return true if all elements are present in the array regardless of their order.
// Otherwise, return false.
// containsAll([1, 2, 3], [2, 1]) => true
// containsAll([1, 2, 3], [2, 1, 4]) => false

function isPresent(array, target) {
  for (let index = 0; index < array.length; index++) {
    if (array[index] === target) {
      return true;
    }
  }

  return false;
}

function containsAll(array, elements) {
  for (let index = 0; index < array.length; index++) {
    if (!isPresent(array, elements[index])) {
      return false;
    }
  }

  return true;
}

function areEqual(array1, array2) {
  if (array1.length !== array2.length) {
    return false;
  }

  for (let index = 0; index < array1.length; index++) {
    if (array1[index] !== array2[index]) {
      return false;
    }
  }

  return true;
}

function makeMessage(array1, terms, expected, actual) {
  let message = "the array1: '" + array1 + "' dropped times : '" + terms;

  message = message + "' are '" + expected;
  message = message + "' and it is '" + actual + "'";

  return message;
}


function testContainsAll(array1, terms, expected) {
  const actual = containsAll(array1, terms);
  const getMark = areEqual(actual, expected) ? '✅' : '❌';

  console.log(getMark + makeMessage(array1, terms, expected, actual));
}

function testAll() {
  testContainsAll([1, 2, 3], [3, 1], true);
  testContainsAll([1, 2, 3], [2, 1, 4], false);
  testContainsAll([], [], true);
  testContainsAll([1, 2, 3], [], true);
}

testAll();