const format = 'yyyy-mm-dd';
const date = '2001-02-29';

// Validate the given date against the format string

// START YOUR CODE AFTER THIS LINE. DO NOT REMOVE THIS LINE

const dateToBeChecked = date + "#";

let year = 0;
let month = 0;
let dateInDate = 0;
let isValidDate = "invalid";

if (format === 'yyyy-mm-dd') {
    year = dateToBeChecked[0] + dateToBeChecked[1] + dateToBeChecked[2] + dateToBeChecked[3];
    month = dateToBeChecked[5] + dateToBeChecked[6];
    dateInDate = dateToBeChecked[8] + dateToBeChecked[9];

    if (dateToBeChecked[4] !== "-" || dateToBeChecked[7] !== "-") {
        year = 0;
    }
}

if (format === 'dd-mm-yyyy') {
    year = dateToBeChecked[6] + dateToBeChecked[7] + dateToBeChecked[8] + dateToBeChecked[9];
    month = dateToBeChecked[3] + dateToBeChecked[4];
    dateInDate = dateToBeChecked[0] + dateToBeChecked[1];

    if (dateToBeChecked[5] !== "-" || dateToBeChecked[2] !== "-") {
        year = 0;
    }
}

if (format === 'mm-dd-yyyy') {
    year = dateToBeChecked[6] + dateToBeChecked[7] + dateToBeChecked[8] + dateToBeChecked[9];
    month = dateToBeChecked[0] + dateToBeChecked[1];
    dateInDate = dateToBeChecked[3] + dateToBeChecked[4];

    if (dateToBeChecked[4] !== "-" || dateToBeChecked[7] !== "-") {
        year = 0;
    }
}

if (dateToBeChecked[10] === "#") {

    if (year > 0 && month > 0 && month < 13) {
        let dateinmonth = 30;

        if (month === "01" || month === "03" || month === "05" || month === "07" || month === "08" || month === "10" || month === "12") {
            dateinmonth = 31;
        }

        if (month === "02") {
            const isLeapYear = (year % 400 === 0) || ((year % 4 === 0) && !(year % 100 === 0));
            dateinmonth = isLeapYear ? 29 : 28;
        }
        
        if (dateInDate > 0 && dateInDate <= dateinmonth) {
            isValidDate = "valid";
        
    } 
}
}
console.log(isValidDate);