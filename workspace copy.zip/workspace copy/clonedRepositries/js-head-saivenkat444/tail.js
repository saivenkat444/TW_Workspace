import { parseArgs } from "./src/parse_args.js";
import { tail } from "./src/tail_lib.js";
import { display } from "./src/print.js";

const main = () => {
  const parsedArgs = parseArgs(Deno.args);
  const content = tail(parsedArgs);
  const exitValue = display(content, "tail");
  Deno.exit(exitValue);
};

main();
