// Do not rename string, use it as input for your program.
// While testing we will change it's value.
const string = '';
// Print the no.of words in given string. Consider multiple spaces.
// If string = "multiple words" then output should be 2
// START YOUR CODE AFTER THIS LINE. DO NOT REMOVE THIS LINE

let numberOfWords = 0;
const spacedString = " " + string + " ";

for (let index = 1; index  < spacedString.length; index++) {
    if (spacedString[index - 1] === " " && spacedString[index] !== " ") {
        numberOfWords = numberOfWords + 1;
    }

}

console.log(numberOfWords);