/*
  Implement the below function that tells if a string is substring of another string

  Usage:
    isSubstring('hello world', 'wo') => true
    isSubstring('repeating iiiiiiii', 'iii') => true
    isSubstring('not found', 'for') => false

  **Your function must return a value**

  It's not necessary to print the result on screen, 
  however to test your function you are free to print the result
*/

function slice(index, length, string) {
  let slicedString = "";

  for (let subStringIndex = index; subStringIndex < length; subStringIndex++) {
    slicedString = slicedString + string[subStringIndex];
  }

  return slicedString;
}

function isSubstring(string, subString) {
  if (subString.length === 0) {
    return false;
  }

  for (let stringIndex = 0; stringIndex < string.length; stringIndex++) {
    const length = stringIndex + subString.length;
    if (slice(stringIndex, length, string) === subString) {
      return true;
    }
  }

  return false;
}

function message(target, expect, evaluatingTo) {
  const isPassing = evaluatingTo === expect ? "✅" : "❌";

  const context = " the target is " + target;
  const expected = " is found " + expect;
  const actual = " but is " + evaluatingTo;
  return isPassing + context + expected + actual;
}

function testIsSubStirng(text,target, expect) {
  const evaluatingTo = isSubstring(text, target);
  console.log(message(target, expect, evaluatingTo));
}

function testCases() {
  testIsSubStirng("hello world", "l", true);
  testIsSubStirng("hello world ", "d", true);
  testIsSubStirng("hello world", "", false);
  testIsSubStirng("hello world", " ", true);
  testIsSubStirng("hello world", "z", false);
}

testCases();