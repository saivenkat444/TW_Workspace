// let cards = "n0111122223444455556666";

// function slice(text, start, end) {
//   const startIndex = start < 0 ? 0 : start;
//   const endIndex = text.length <= end ? text.length - 1 : end;

//   return sliceIfInRange(text, startIndex, endIndex);
// }

// function sliceIfInRange(text , currentIndex, endIndex) {
//   if (currentIndex > endIndex) {
//     return ""; 
//   }

//   return text[currentIndex] + slice(text, currentIndex + 1, endIndex);
// }

// function replace(cards, index) {
//   let updated = sliceIfInRange(cards, 0, index - 1);
//   updated = updated + "n";
//   return updated + sliceIfInRange(cards, index + 1, cards.length);
// }

// function find(cards, target) {
//   for (let index = 0; index < cards.length; index++) {
//     if (cards[index] === target) {
//       return replace(cards, index);
//     }
//   }
// }

// cards = (find(cards, "2"));
// console.log(cards);

// // find and replace
// /* 0 for diffuse
//   1 for tacocat
//   2 for godcat
//   3 for bomb
//   4 for catermelon
//   5 for hairypotato cat
//   6 for rainbow*/


function generateCard() {
  const calling = Math.floor((Math.random() * 10) % 7);
  console.log(calling);
  return calling;
}

function pickCard(player) {
  if (prompt(player + " pick the next card raa....", "✅") === "✅") {
    return generateCard();
  }
  console.log("(press enter to continue)");
  return pickCard(player);
}

console.log(pickCard("ajay"));