function sliceIfInRange(text , currentIndex, endIndex) {
  if (currentIndex > endIndex) {
    return ""; 
  }

  return text[currentIndex] + slice(text, currentIndex + 1, endIndex);
}

function slice(text, start, end) {
  const startIndex = start < 0 ? 0 : start;
  const endIndex = text.length <= end ? text.length - 1 : end;

  return sliceIfInRange(text, startIndex, endIndex);
}

function makeMessage(string, from, to, expected, actual) {
  let message = "the string '" + string + "' sliced from " + from;
  
  message = message + " to '" + to + "' times is expected to be '" + expected;
  message = message + "' and it is '" + actual + "'";

  return message;
}

function testReplaceString(string, from, to, expected) {
  const actual = slice(string, from, to);
  const getMark  = actual === expected ? '✅' : '❌';
  
  console.log(getMark + makeMessage(string, from, to, expected, actual));
}

function testAll() {
  testReplaceString("hello", 2, 3, "ll");
  testReplaceString("hello", 5, 3, "");
  testReplaceString("hello", 6, 6, "");
  testReplaceString("hello", 2, 3, "ll");
  testReplaceString("hello", -3, 4, "hello");

}

testAll();