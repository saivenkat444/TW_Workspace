/*
  Write a function that takes an integer as input and returns a string.

  If the integer is divisible by 3, return "fizz".
  If the integer is divisible by 5, return "buzz".
  If the integer is divisible by both 3 and 5, return "fizzbuzz".
  Otherwise, return the integer as a string.

  Examples:
    fizzBuzz(3) => "fizz"
    fizzBuzz(5) => "buzz"
    fizzBuzz(15)=> "fizzbuzz"
    fizzBuzz(7) => "7"
  
  **There won't be any negative numbers**

  It's not necessary to print the result on screen, 
  however to test your function you are free to print the result
*/

function division(number, divisor) {
  return number % divisor === 0;
}

function fizzBuzz(number) {
  if (division(number, 15)) {
    return "fizzbuzz";
  }

  if (division(number, 3)) {
    return "fizz";
  }

  if (division(number, 5)) {
    return "buzz";
  }

  return "" + number;
}

function message(number, expect, evaluatingTo) {
  const isPassing = evaluatingTo === expect ? "✅" : "❌";

  const context = " number " + number;
  const expected = " should be " + expect;
  const actual = " it is " + evaluatingTo;
  return isPassing + context + expected + actual;
}

function testfizzbuzz(number, expect) {
  const evaluatingTo = fizzBuzz(number);
  console.log(message(number, expect, evaluatingTo));
}

function testCases() {
  testfizzbuzz(3, "fizz");
  testfizzbuzz(5, "buzz");
  testfizzbuzz(15, "fizzbuzz");
  testfizzbuzz(0, "fizzbuzz");
  testfizzbuzz(7, "7");
}

testCases();