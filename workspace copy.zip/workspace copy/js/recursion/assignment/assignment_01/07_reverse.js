function reverseOfString(string, index) {
  if (index === string.length) {
    return "";
  }
  
  return reverseOfString(string, index + 1) + string[index];
}

function reverse(string) {
  return reverseOfString(string, 0);
}

  function makeMessage(string, expected, actual) {
    let message = "the string " + string;
    
    message = message + " expected to be " + expected;
    message = message + " and it is " + actual;

    return message;
  }

  function testIsPalindrome(string, expected) {
    const actual = reverse(string);
    const getMark  = actual === expected ? '✅' : '❌';
    
    console.log(getMark + makeMessage(string, expected, actual));
  }

  function testAll() {
    testIsPalindrome("1990", "0991");
    testIsPalindrome("1991", "1991");
    testIsPalindrome("MOM", "MOM");
    testIsPalindrome("racecar", "racecar");
    testIsPalindrome("hello", "olleh");
    testIsPalindrome("a", "a");
    testIsPalindrome("9", "9");
    testIsPalindrome("", "");
  }

  testAll();