const isOption = (candidate) => candidate.startsWith("-");

const isValidOption = (candidate) => ["-n", "-c"].includes(candidate);

const isValidCount = (candidate) => candidate > 0;

const createErrorFormat = (type, token) => ({
  // out this above where uts accesssed from
  type,
  token,
  isError: true,
});

const defaultParsedArgs = () => {
  return { option: "n", count: 10, filepaths: [], isError: false };
};

export const parseArgs = (args) => {
  const parsedArgs = defaultParsedArgs();

  let index = 0;
  while (isOption(args[index])) {
    const option = args[index].slice(0, 2);
    if (!isValidOption(option)) {
      return createErrorFormat("invalid option", option[1]);
    }

    const count = args[index].length > 2 ? args[index].slice(2) : args[++index]; //can use or
    if (!isValidCount(count)) {
      return createErrorFormat("invalid count", count);
    }

    parsedArgs.option = option[1];
    parsedArgs.count = +count;
    index++;
  }
  return { ...parsedArgs, filepaths: args.slice(index) };
  // split(string, index) => [string.slice(0, index), string.slice(2)]xq
  // const parsedArgs = defaultParsedArgs();
  // try {
  //   const argsToParse = validateArgsLength(args);
  //   let index = 0;

  //   while (isOption(argsToParse[index])) {
  //     const option = extractOptionFromArgs(argsToParse, index);
  //     parsedArgs.option = validateOption(option);
  //     const [count, indexIncrementBy] = extractCountFromArgs(
  //       argsToParse,
  //       index
  //     );
  //     index = index + indexIncrementBy;
  //     parsedArgs.count = validateCount(count);// Number(validateCoiunt)
  //     index++;
  //   }

  //   return { ...parsedArgs, filepaths: argsToParse.slice(index) };
  // } catch (error) {
  //   return error;
  // }
};