// Given array1 and array2 returns true if both array are equal else false.
// Examples:
// areEqual([1, 2, 3, 4], [1, 2, 3, 4]) => true
// areEqual([1, 2, 3], [1, 2, 3, 4]) => false
// areEqual([1, 2, 3], [1, 3, 2]) => false
// areEqual([], []) => true
// do not modify input parameters

const areElementsEqual = function (array2, elementOf1, index) {
  return elementOf1 === array2[index];  
}

function areEqual(array1, array2) {
  // if (array1.length !== array2.length) {
  //   return false;
  // }

  return array1.reduce(areElementsEqual, array2);

  // for (let index = 0; index < array1.length; index++) {
  //   if (areElementsEqual(array1[index], array2[index])) {
  //     return false;
  //   }
  // }

  // return true;
}

function makeMessage(array1, array2, expected, actual) {
  let message = "the array 1: '" + array1;

  message = message + " the array2: '" + array2;
  message = message + "' are expected to be '" + expected;
  message = message + "' and it is '" + actual + "'";

  return message;
}

function testAreEqual(array1, array2, expected) {
  const actual = areEqual(array1, array2);
  const getMark = actual === expected ? '✅' : '❌';

  console.log(getMark + makeMessage(array1, array2, expected, actual));
}

function testAll() {
  testAreEqual([1, 2, 3], [1, 2, 3], true);
  testAreEqual([1, 2, 3], [1, 2, 3, 4], false);
  testAreEqual([1, 2, 3, 4], [1, 2, 3], false);
  testAreEqual([1, 2, 3], [1, 3, 2], false);
  testAreEqual(["sai"], ["sai"], true);
  testAreEqual(["1", "2"], ["1", "2"], true);
  testAreEqual(["1", "2"], [1, 2], false);
  testAreEqual(["sai"], ["aakash"], false);
  testAreEqual(["sai", "aakash"], ["aakash"], false);
  testAreEqual(["aakash"], ["sai", "aakash"], false);
  testAreEqual([], [], true);
}

testAll();