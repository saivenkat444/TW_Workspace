function HCF(number1, number2) {
  if (number1 === 0) {
    return number2;
  }
  return (HCF(number2 % number1, number1))
}

// console.log(HCF(1, 0));
console.log(HCF(24, 36));
console.log(HCF(36, 24));

// 12 , 24  return output of line 12
// 0, 12 -- 12 
// if true 
// 12 output  