//make the things shown in class 
Methods 
Area
Perimeter
fielids private
Define a method to change the private fields 
