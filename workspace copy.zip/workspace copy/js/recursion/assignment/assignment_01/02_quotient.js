function quotient(dividend, divisor) {
  if (dividend < divisor) {
    return 0;
  }

  return 1 + quotient(dividend - divisor, divisor);
}

function makeMessage(dividend, divisor, expected, actual) {
  let message = "the dividend is " + dividend;

  message = message + " the divisor is " + divisor;
  message = message + " expected to be " + expected;
  message = message + " and it is " + actual;

  return message;
}

function testQuotinet(dividend, divisor, expected) {
  const actual = quotient(dividend, divisor);
  const getMark  = actual === expected ? '✅' : '❌';
  
  console.log(getMark + makeMessage(dividend, divisor, expected, actual));
}

function testAll() {
  testQuotinet(2, 1, 2);
  testQuotinet(1, 2, 0);
  testQuotinet(6, 2, 3);
  testQuotinet(3, 2, 1);
  testQuotinet(0, 2, 0);
  testQuotinet(10, 20, 0);
  testQuotinet(20, 10, 2);
  testQuotinet(20, 20, 1);
}

testAll();  
