import { generateScoreCard } from '../src/scorecard.js';
import { assertEquals } from 'jsr:@std/assert';

Deno.test('should generate scorecard', () => {
  const sampleData = [];
  const expectedOutput = ``;
  assertEquals(generateScoreCard(sampleData), expectedOutput);
});
