const string = "hi i am sai venkat\nhi";

const reverse = function (result, element) {
  return element + result;
}

const reversedArray = function (array) {
  return array.reduce(reverse, "");
}

const converIntoArray = function (string) {
  const array = string.split("");
  const revString = reversedArray(array);

  return revString;
}

console.log(converIntoArray(string));
