/*
  Write a function that tells if a string ends with a specific substring

  Examples:
    endsWith('hello world', 'ld') => true
    endsWith('hello world', 'wor') => false
    endsWith('hello world', 'hello') => false

  **Your function must return a value**

  It's not necessary to print the result on screen, 
  however to test your function you are free to print the result
*/

function endsWith(string, substring) {
  return endOfString(string, substring.length) === substring;
}

function endOfString(string, subLength) {
  let slicedString = "";
  let index = string.length - 1;

  for (subLength = subLength - 1; subLength >= 0; subLength--) {
    slicedString = string[index] + slicedString;
    index = index - 1;
  }

  return slicedString;
}

function message(string, substring, expected, actual) {
  const isPassing = actual === expected ? "✅" : "❌";

  const context = " Ending of " + string;
  const expected = " is expected to be '" + expected;
  const finalResult = "' but it is '" + actual + "'";

  return isPassing + context + "'" + substring + "'" + expected + finalResult;
}

function testEndWith(string, substring, expect) {
  const evaluatingTo = endsWith(string, substring);
  console.log(message(string, substring, expect, evaluatingTo));
}
  
function testCases() {
  testEndWith("hello world", "ld", true);
  testEndWith("hello World", "hello World", true);
}

testCases();

