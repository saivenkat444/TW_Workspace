# HTML/CSS Assignment - The Pokemon Daily 📰

## Welcome to the Pokémon Daily!

Get ready to report the latest discoveries in the world of Pokémon! Your mission is to build a [daily news article page](the-pokemon-daily-page.png) about a **newly discovered Pokémon species** found in the wild. Who knows, you might just become the next big reporter in the Pokémon universe! 🌟

## Goal

Your task is to design a **news article page** using HTML and CSS that highlights this new Pokémon species. You will need to:
- Practice using **padding, margins**, and the **box model** to structure your page properly.
- There are various sections such as a headline, article content, images of the Pokémon, and some fun details like where it was found and what makes it special.


## Good luck!

Have fun. You got this! 💪
