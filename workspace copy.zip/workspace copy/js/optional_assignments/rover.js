const roverX = 0;
const roverY = 0;
const heading = 0;
const instructions = 332331;

// The above input should leave the Mars Rover at 2 2 0

// START YOUR CODE AFTER THIS LINE. DO NOT REMOVE THIS LINE

let headingTowards = heading;
let XCordinate = roverX;
let YCordinate = roverY;

const mainInstruction = "" + instructions;


for (let digit = 0; digit < mainInstruction.length; digit++) {
    if (+mainInstruction[digit] < 3) {
        const noOfRightTurn = +mainInstruction[digit] === 1 ? 3 : 1;
        headingTowards = (headingTowards + noOfRightTurn) % 4;
        
    }
    if (+mainInstruction[digit] === 3) {
    let XOffset = 0;
    let YOffset  = 0;
    switch (headingTowards) {
    case 0:
        //move north
        YOffset = 1;
        
        break;
    case 1:
        //move east
        XOffset = 1;
        break;
    case 2:
        //move south
        YOffset = -1;
        break;
    case 3:
        //move west
        XOffset = -1;
        break;
    }
    XCordinate = XCordinate + XOffset;
    YCordinate = YCordinate + YOffset;
    }
}
console.log(XCordinate, YCordinate, headingTowards);