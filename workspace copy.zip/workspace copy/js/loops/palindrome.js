let value=0;
let num=value
let palindrome=0;
while(num>0){
    palindrome = (palindrome*10) + num%10;
    num=(num-num%10)/10;
}
if(value===palindrome){
    console.log(1)
}
else{console.log(0)}