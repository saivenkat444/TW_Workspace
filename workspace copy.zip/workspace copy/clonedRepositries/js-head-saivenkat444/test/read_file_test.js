import { afterEach, beforeEach, describe, it } from "jsr:@std/testing/bdd";
import { assertEquals } from "jsr:@std/assert";
import { readFile } from "../src/read_file.js";
const oldProperty = Deno.readTextFileSync;

const testingFiles = {
  "tenLines.txt": "1\n2\n3\n4\n5\n6\n7\n8\n9\n10",
  "fiveLines.txt": "1\n2\n3\n4\n5",
  "twentyLines.txt":
    "1\n2\n3\n4\n5\n6\n7\n8\n9\n10\n11\n12\n13\n14\n15\n16\n17\n18\n19\n20",
  "emptyFile.txt": "",
  "charFile.txt": "sai1\nsai2\nsai3\nsai4\nsai5\nsai6\nsai7\nsai8\nsai9\nsai10",
};

describe("cat (filePath)", () => {
  beforeEach(() => {
    Deno.readTextFileSync = (filePath) => testingFiles[filePath];
  });
  afterEach(() => {
    Deno.readTextFileSync = oldProperty;
  });
  it("should give the full content of the existing file", () => {
    const actual = readFile("tenLines.txt");
    const expected = "1\n2\n3\n4\n5\n6\n7\n8\n9\n10";
    assertEquals(actual, expected);
  });
  it("should give empty when empty file is given", () => {
    const actual = readFile("emptyFile.txt");
    const expected = "";
    assertEquals(actual, expected);
  });
  // it("should give error when invalid file path is given", () => {
  //   const actual = cat("something.js");
  //   const expected = {
  //     error: { type: "invaild file", token: ["something.js"] },
  //   };
  //   assertEquals(actual, expected);
  // });
});
