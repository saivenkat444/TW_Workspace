import * as Assertion from "jsr:@std/assert";
import { difference } from "./05_difference.js";

Deno.test("one element is missing:", Assertion);
