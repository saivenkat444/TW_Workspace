function isMultiplicationPossible(matrixA, matrixB) {
  for (let index = 0; index < matrixB.length; index++) {
  if (matrixA.length !== matrixB[index].length) {
    return false;
    }
  }

  for (let index = 0; index < matrixA.length; index++) {
    if (matrixA[index].length !== matrixB.length) {
      return false;
    }
  }

  return true;
}

function getColoumn(matrix, entries) {
  const coloumn = [];
  for (let index = 0; index < matrix.length; index++) {
    coloumn.push(matrix[index][entries]);
  }

  return coloumn;
}

function multiplyRowAndColoumn(row, coloumn) {
  let entry = 0;
  for (let index = 0; index < row.length; index++) {
    entry = entry + (row[index] * coloumn[index]);
  }

  return entry;
}

function multiplyWithRow(row, matrixB) {
  const multipliedRow = [];
  const coloumnLength = matrixB[0].length;

  for (let index = 0; index < coloumnLength; index++) {
    const coloumn = getColoumn(matrixB, index);

    multipliedRow.push(multiplyRowAndColoumn(row, coloumn));
  }

  return multipliedRow;
}

function multiplyMatrices(matrixA, matrixB) {
  if(!isMultiplicationPossible(matrixA, matrixB)) {
    return NaN;
  }

  let multipliedMatrix = [];

  for (let index = 0; index < matrixA.length; index++) {
    const row = matrixA[index];
    multipliedMatrix.push(multiplyWithRow(row, matrixB));
  }

  return multipliedMatrix;
}

function makeMessage(matrixA, matrixB, expected, actual) {
  let message = "the matrix A: '" + matrixA;

  message = message + "' the matrix B: '" + matrixB; 
  message = message + "' are multiplied: '" + expected; 
  message = message + "' and it is: '" + actual + "'";

  return message;
}

function areIndexArrayEqual(array1, array2) {
  if (array1.length !== array2.length) {
    return false;
  }

  for (let index = 0; index < array1.length; index++) {
    if (array1[index] !== array2[index]) {
      return false;
    }
  }

  return true;
}

function areEqual(array1, array2) { 
  for (let index = 0; index < array1.length; index++) {
    if (!areIndexArrayEqual(array1[index], array2[index])) {
      return false;
    }
  }

  return true;
}

function testMultiplyMatrices(matrixA, matrixB, expected) {
  const actual = multiplyMatrices(matrixA, matrixB);
  const getMark = areEqual(actual, expected) ? '✅' : '❌';

  console.log(getMark + makeMessage(matrixA, matrixB, expected, actual));
}

function testAll() {
  testMultiplyMatrices([[1, 2], [3, 4]], [[4, 3], [2, 1]], [[8, 5], [20, 13]]);
  testMultiplyMatrices([[1, 2], [3, 4]], [[5, 6], [7, 8]], [[19, 22], [43, 50]]);
  testMultiplyMatrices([[1]], [[5]], [[5]]);
  testMultiplyMatrices([[3, 12, 4], [5, 6, 8], [1, 0, 2]], [[7, 3, 8], [11, 9, 5], [6, 8, 4]], [[177, 149, 100], [149, 133, 102], [19, 19 , 16]]);
  testMultiplyMatrices([], [], []);
  testMultiplyMatrices([[1, 2, 3], [3, 2, 1]], [[1, 2, 3]], NaN);
  testMultiplyMatrices([[1, 2, 3], [4, 5, 6]], [[7, 8], [9, 10], [11, 12]], [[58, 64], [139, 154]]);
  testMultiplyMatrices([[1, 0], [-1, 2], [3, 4]], [[1, -2, 3], [4, 5, 7]], [[1, -2, 3], [7, 12, 11], [19, 14, 37]]);
  testMultiplyMatrices([[2, 3], [2, 1], [5, 3]], [[5, 3, 2], [2, 1, 4]], [[16, 9, 16], [12, 7, 8], [31, 18, 22]]);
  testMultiplyMatrices([], [[1]], NaN);
  testMultiplyMatrices([[1, 2, 3], [4, 5, 6]], [[1, 2], [3, 4]], NaN);
  testMultiplyMatrices([[1, 2], [3, 4], [5, 6], [7, 8]], [[9, 8, 5], [4, 6, 8]], [[17, 20, 21], [43, 48, 47], [69, 76, 73], [95, 104, 99]]);
}

testAll();