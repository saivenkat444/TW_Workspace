function sumOfAP(a, d, n) {
  if (n < 1) {
    return 0;
  }
  
  const nthTerm = a + ((n - 1) * d);

  if (n === 1) {
    return nthTerm;
  }

  return nthTerm + sumOfAP(a, d, n - 1);
}

function makeMessage(terms, expected, actual) {
  let message = "the sum upto " + terms + " terms is";
  
  message = message + " expected to be " + expected;
  message = message + " and it is " + actual;

  return message;
}

function testSumOfGP(a, d, n, expected) {
  const actual = sumOfAP(a, d, n);
  const getMark  = actual === expected ? '✅' : '❌';
  
  console.log(getMark + makeMessage(n, expected, actual));
}

function testAll() {
  testSumOfGP(1, 1, 0, 0);
  testSumOfGP(1, 1, 1, 1);
  testSumOfGP(1, 1, 2, 3);
  testSumOfGP(1, 1, 3, 6);
  testSumOfGP(3, 5, 10, 255);
  testSumOfGP(3, 0, 10, 30);
  testSumOfGP(0, 0, 10, 0);
  testSumOfGP(0, 1, 10, 45);
}

testAll();