// Given an array of numbers and a threshold value, return a new array
// that contains all the numbers which are below threshold.
// filterBelow([6, 2, 3, 1, 4, 7], 3) => [2, 1]
// filterBelow([1, 2, 3], 0) => []
// do not modify input parameters
function filterBelow(array, threshold) {
  const filteredBelow = [];

  for (let index = 0; index < array.length; index++) {
    if (array[index] < threshold) {
      filteredBelow[filteredBelow.length] = array[index];
    }
  }

  return filteredBelow;
}

function makeMessage(array, expected, actual) {
  let message = "the numbers above the threshold: '" + array;

  message = message + "' are '" + expected;
  message = message + "' and it is '" + actual + "'";

  return message;
}

function areEqual(array1, array2) {
  if (array1.length !== array2.length) {
    return false;
  }

  for (let index = 0; index < array1.length; index++) {
    if (array1[index] !== array2[index]) {
      return false;
    }
  }

  return true;
}

function testFilterBelow(array, threshold, expected) {
  const actual = filterBelow(array, threshold);
  const getMark = areEqual(actual, expected) ? '✅' : '❌';

  console.log(getMark + makeMessage(array, threshold, expected, actual));
}

function testAll() {
  testFilterBelow([6, 2, 3, 1, 4, 7], 3, [2, 1]);
  testFilterBelow([1, 2, 3], 0, []);
  testFilterBelow([8, 9, 10], 6, []);
  testFilterBelow([8, 9, 10], 11, [8, 9, 10]);

}

testAll(); 