### **Type 1: Explanation**

1. What does the expression `"cat, bat, rat".match(/b\w+/)` do?  
   [ "bat", index: 5, input: "cat, bat, rat", groups: undefined ], isExpected: true
2. What will `"123-456-7890".match(/\d{3}/)` return?  
   [ "123", index: 0, input: "123-456-7890", groups: undefined ], isExpected: true
3. What does `"hello\nworld".match(/.\n./)` return?  
   [ "o\nw", index: 4, input: "hello\nworld", groups: undefined ], isExpected: true
4. What will `"name@example.com".match(/\w+@\w+\.\w+/)` return?  
   [
   "name@example.com", index: 0, input: "name@example.com", groups: undefined], isExpected: true
5. What does `"file.txt".match(/\.txt/)` do?
   [ ".txt", index: 4, input: "file.txt", groups: undefined ], isExpected: true
6. What does `"red green blue".match(/green/)` do?
   [ "green", index: 4, input: "red green blue", groups: undefined ], isExpected: true
7. What will `"abcdef".match(/[a-c]/)` return?
   [ "a", index: 0, input: "abcdef", groups: undefined ], isExpected: true
8. What does `"The quick brown fox".match(/q.+?k/)` return?
   [ "quick", index: 4, input: "The quick brown fox", groups: undefined ], isExpected: true
9. What does `"apple".match(/a[a-z]+/)` return?
   [ "apple", index: 0, input: "apple", groups: undefined ], isExpected: true
10. What will `"a1b2c3".match(/\d+/)` return?
    [ "1", index: 1, input: "a1b2c3", groups: undefined ], isExpected: true
11. What does `"good food mood".match(/o+o/)` do?
    [ "oo", index: 1, input: "good food mood", groups: undefined ], isExpected: false, learnt: true
12. What does `"@username".match(/@\w+/)` return?
    [ "@username", index: 0, input: "@username", groups: undefined ], isExpected: true
13. What does `"path/to/file".match(/\/to\//)` do?
    [ "/to/", index: 4, input: "path/to/file", groups: undefined ], isExpected: true
14. What does `"1.23".match(/\d\.\d+/)` return?
    [ "1.23", index: 0, input: "1.23", groups: undefined ], isExpected: true
15. What will `"AB123CD".match(/[A-Z]+\d+/)` return?
    [ "AB123", index: 0, input: "AB123CD", groups: undefined ], isExpected: true
16. What does `"hello_world".match(/\w+_\w+/)` return?
    [ "hello_world", index: 0, input: "hello_world", groups: undefined ], isExpected: true, learnt: true
17. What does `"123abc456".match(/\d{3}/)` return?
    [ "123", index: 0, input: "123abc456", groups: undefined ], isExpected: true
18. What does `"My name is John".match(/name\s\w+/)` return?
    [ "name is", index: 3, input: "My name is John", groups: undefined ], isExpected: true
19. What will `"https://example.com".match(/https?:\/\/\w+\.\w+/)` return?
    ["https://example.com", index: 0, input: "https://example.com", groups: undefined] , isExpected: true
20. What does `"abcdEFGH".match(/[A-Z]+/)` return?
    [ "EFGH", index: 4, input: "abcdEFGH", groups: undefined ], isExpected: true
21. What does `"abc123".match(/(\w)(\d)/)` return?
    [ "c1", "c", "1", index: 2, input: "abc123", groups: undefined ], isExpected: false, learnt: yes
22. What will `"hello world".match(/(\w+)\s(\w+)/)` return?
    [
    "hello world",
    "hello",
    "world",
    index: 0,
    input: "hello world",
    groups: undefined
    ], isExpected: true

23. What does `"1234".match(/\d{2,3}/)` return?
    [ "123", index: 0, input: "1234", groups: undefined ], isExpected: true
24. What will `"aaaabbb".match(/a{2,}/)` return?
    [ "aaaa", index: 0, input: "aaaabbb", groups: undefined ], isExpected: true
25. What does `"hello".match(/[aeiou]{2}/)` return?
    null, isExpected: true
26. What does `"ABCD1234".match(/[A-Z]+\d+/)` return?
    [ "ABCD1234", index: 0, input: "ABCD1234", groups: undefined ], isExpected: true
27. What does `"file_name.ext".match(/(\w+)\.(\w+)/)` return?
    [
    "file_name.ext",
    "file_name",
    "ext",
    index: 0,
    input: "file_name.ext",
    groups: undefined
    ], isExpected: true
28. What does `"Mississippi".match(/s{2,}/)` return?
    [ "ss", index: 2, input: "Mississippi", groups: undefined ], isExpected: true
29. What will `"hello world".match(/(\w)(?=\s\w)/)` return?
    [ "o", "o", index: 4, input: "hello world", groups: undefined ], isExpected: false, learnt: true
30. What does `"2025-01-01".match(/\d{4}-(\d{2})-(\d{2})/)[2]` return?
    "01", isExpected: true
31. What does `"abc123".match(/(\d+)(\w+)/)` return?
    [ "123", "12", "3", index: 3, input: "abc123", groups: undefined ], isExpected: true
32. What does `"hello123".match(/\D+/)` return?
    [ "hello", index: 0, input: "hello123", groups: undefined ], isExpected: true
33. What will `"yes no maybe".match(/(\w+)\s(\w+)\s(\w+)/)` return?
    [
    "yes no maybe",
    "yes",
    "no",
    "maybe",
    index: 0,
    input: "yes no maybe",
    groups: undefined
    ], isExpected: true
34. What does `"color: #123456".match(/#[0-9a-fA-F]{6}/)` return?
    [ "#123456", index: 7, input: "color: #123456", groups: undefined ], isExpected: true
35. What does `"aaa111bbb222".match(/([a-z]+)(\d+)/)` return?
    [
    "aaa111",
    "aaa",
    "111",
    index: 0,
    input: "aaa111bbb222",
    groups: undefined
    ], isExpected: true
36. What will `"1,234.56".match(/\d{1,3}(,\d{3})*\.\d{2}/)` return?
    [ "1,234.56", ",234", index: 0, input: "1,234.56", groups: undefined ], isExpected: true
37. What does `"aabbcc".match(/a(b{2})c/)` return?
    [ "abbc", "bb", index: 1, input: "aabbcc", groups: undefined ], isExpected: true
38. What does `"xyzz".match(/x(y(z))/)` return?
    [ "xyz", "yz", "z", index: 0, input: "xyzz", groups: undefined ], isExpected: true
39. What does `"abab".match(/(ab)\1/)` return?
    [ "abab", "ab", index: 0, input: "abab", groups: undefined ], isExpected: true
40. What will `"abc123abc".match(/(abc)\d+\1/)` return?
    [ "abc123abc", "abc", index: 0, input: "abc123abc", groups: undefined ], isExpected: true

---

### **Type 2: Task**

1. Match any string that contains a number.
2. Find all lowercase letters in a string.
3. Match a string that ends with "ed".
4. Match the word "yes" in a string.
5. Find any two consecutive vowels in a string.
6. Match any string containing the word "hello".
7. Find a string that contains exactly two spaces.
8. Find a string that starts with "abc".
9. Match any string that contains the digit `7`.
10. Find all occurrences of the letter `e`.
11. Match a string that has at least one uppercase letter.
12. Find a string with a period (`.`) in it.
13. Match a string that contains a single space.
14. Match all words that start with the letter `c`.
15. Match a string that contains the sequence "123".
16. Match a string that contains a forward slash (`/`).
17. Find all strings that contain "and".
18. Match a string that starts and ends with the same letter.
19. Match all lowercase letters except "x" and "y".
20. Find all words in a string that are exactly 5 letters long.
21. Match all words starting with a vowel.
22. Find all sequences of two or more consecutive digits.
23. Match all words that contain exactly three letters.
24. Find all occurrences of the word "cat" or "dog".
25. Capture the first and last name from a string like `"John Doe"`.
26. Match strings with repeating characters (e.g., `"aa"`, `"bb"`).
27. Extract all the hashtags from a tweet.
28. Validate a 24-hour time format like `"23:59"`.
29. Capture the area code and phone number from `(123) 456-7890`.
30. Find sequences of whitespace followed by a word.
31. Match strings containing at least one uppercase and one digit.
32. Find all non-alphanumeric characters in a string.
33. Match email addresses.
34. Validate dates in the format `YYYY-MM-DD`.
35. Extract the filename and extension from a path like `/path/to/file.txt`.
36. Find all duplicate words in a sentence.
37. Match words that do not contain the letter "e".
38. Extract the domain name from a URL like `https://www.example.com`.
39. Match strings containing three consecutive vowels.
40. Find all 4-letter palindromes in a string.
