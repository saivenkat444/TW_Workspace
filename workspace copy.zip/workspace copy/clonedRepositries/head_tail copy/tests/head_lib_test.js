import {
  afterEach,
  before,
  beforeEach,
  describe,
  it,
} from "jsr:@std/testing/bdd";
import { assertEquals } from "jsr:@std/assert";
import { head, fetchContent } from "../src/head_lib.js";

const oldProperty = Deno.readTextFileSync;

const testingFiles = {
  "tenLines.txt": "1\n2\n3\n4\n5\n6\n7\n8\n9\n10",
  "fiveLines.txt": "1\n2\n3\n4\n5",
  "twentyLines.txt":
    "1\n2\n3\n4\n5\n6\n7\n8\n9\n10\n11\n12\n13\n14\n15\n16\n17\n18\n19\n20",
  "emptyFile.txt": "",
  "charFile.txt": "sai1\nsai2\nsai3\nsai4\nsai5\nsai6\nsai7\nsai8\nsai9\nsai10",
};

describe("head(count, filePath, separator) for n option ", () => {
  beforeEach(() => {
    Deno.readTextFileSync = (filePath) => {
      if (testingFiles[filePath] !== undefined) {
        return testingFiles[filePath];
      }
      throw "error";
    };
  });

  afterEach(() => {
    Deno.readTextFileSync = oldProperty;
  });

  it("should exit with zero when there is valid file", () => {
    const actual = head({
      output: { option: "n", count: 10, filepaths: ["tenLines.txt"] },
    });
    const expected = 0;
    assertEquals(actual, expected);
  });

  it("should exit with zero when there are valid multiple files", () => {
    const actual = head({
      output: {
        option: "n",
        count: 10,
        filepaths: ["tenLines.txt", "fiveLines.txt"],
      },
    });
    const expected = 0;
    assertEquals(actual, expected);
  });

  it("should exit with non zero when there is invalid file", () => {
    const actual = head({
      output: { option: "n", count: 10, filepaths: ["tenlines.txt"] },
    });
    const expected = 1;
    assertEquals(actual, expected);
  });

  it("should exit with non zero when there is one invalid file", () => {
    const actual = head({
      output: {
        option: "n",
        count: 10,
        filepaths: ["tenLines.txt", "fivelines.txt", "fiveLines.txt"],
      },
    });
    const expected = 1;
    assertEquals(actual, expected);
  });

  it("should exit with non zero when there is invalid option", () => {
    const actual = head({
      error: { type: "invalid option", token: "something" },
    });
    const expected = 1;
    assertEquals(actual, expected);
  });
  it("should exit with no zero when there is invalid count", () => {
    const actual = head({
      error: { type: "invalid count", token: "something" },
    });
    const expected = 1;
    assertEquals(actual, expected);
  });
});

describe("fetchContent(optionType, count, filePath)", () => {
  beforeEach(() => {
    Deno.readTextFileSync = (filePath) => {
      if (testingFiles[filePath] !== undefined) {
        return testingFiles[filePath];
      }
      throw "error";
    };
  });

  afterEach(() => {
    Deno.readTextFileSync = oldProperty;
  });

  it("should give content for the valid file for option n", () => {
    const actual = fetchContent("n", 10, ["tenLines.txt"]);
    const expected = {
      fileName: ["tenLines.txt"],
      content: "1\n2\n3\n4\n5\n6\n7\n8\n9\n10",
    };
    assertEquals(actual, expected);
  });
  it("should give content for the valid file for option c", () => {
    const actual = fetchContent("c", 10, ["tenLines.txt"]);
    const expected = {
      fileName: ["tenLines.txt"],
      content: "1\n2\n3\n4\n5\n",
    };
    assertEquals(actual, expected);
  });
  it("should give invalid file when file is missing for option n", () => {
    const actual = fetchContent("n", 10, ["missing.txt"]);
    const expected = {
      error: { type: "invalid file", token: ["missing.txt"] },
    };
    assertEquals(actual, expected);
  });
  it("should give invalid file when file is missing for option c", () => {
    const actual = fetchContent("c", 10, ["missing.txt"]);
    const expected = {
      error: { type: "invalid file", token: ["missing.txt"] },
    };
    assertEquals(actual, expected);
  });
});
