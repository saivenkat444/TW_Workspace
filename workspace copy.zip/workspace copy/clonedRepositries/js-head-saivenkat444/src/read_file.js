export const readFile = (filePath) => {
  try {
    return Deno.readTextFileSync(filePath);
  } catch {
    throw { type: "invalid file", token: filePath, isError: true};
  }
};
