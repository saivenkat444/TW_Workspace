// Do not rename sentence, use it as input for your program.
// While testing we will change it's value.
const sentence = "this is c";
//  Reverse the sentence
// If sentence = "this is cool" then Output should be "cool is this"
// START YOUR CODE AFTER THIS LINE. DO NOT REMOVE THIS LINE

const SPACE = " ";
let reversedSentence = "";
let currentWord = "";

for (let lastIndex = sentence.length - 1; lastIndex >= 0; lastIndex--) {
    if (sentence[lastIndex] === SPACE) {
        reversedSentence = reversedSentence + currentWord;
        reversedSentence = reversedSentence + SPACE;
        currentWord = "";
    } else {
        currentWord = sentence[lastIndex] + currentWord;
    }

}

reversedSentence = reversedSentence + currentWord;

console.log(reversedSentence);