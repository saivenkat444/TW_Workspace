console.clear();
let PWD = "~";

const ownerMessage = function () {
  return "kamanasaivenkat@Kamanas-MacBook-Pro " + curentDirectory() + " %";
}

const curentDirectory = function () {
  if (PWD === "~") {
    return PWD;
  }

  return PWD.slice((PWD.lastIndexOf("/") + 1));
}

const performEcho = function (args) {
  if (args[0][0] === "$") {
    return "local/bin/" + PWD;
  } 
  
  return args.join(" ")
}

const performcurrentDirectory = function (args) {
  PWD = args.join("");
  return"NOTHING"
}
 
const commandRun = function ([command, ...args]) {
  switch (command) {
    case "echo" : return performEcho(args);
    case "cd" : return performcurrentDirectory(args);
    case "pwd" : return "/" + PWD;

  }
  return "zsh: command not found: " + command;
}

while (true) {
  const command = prompt(ownerMessage());
  const result = commandRun(command.split(" "));


  if (result === "NOTHING") {
    continue;
  }
  
  console.log(result);
}