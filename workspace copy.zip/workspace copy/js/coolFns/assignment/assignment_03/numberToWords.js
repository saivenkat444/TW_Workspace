function oneSeries(digit) {
  const words = ["ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen"];

  return words[digit];
}

function convertTens(number, unitDigit) {
  const words = ["", oneSeries(unitDigit), "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety"];

  return words[number];
}

function convertUnitAndHundred(number) {
  const words = ["", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine"];

  return words[number];
}

function giveInWords(unitDigit, tenDigit, hundredDigit) {
  const add = tenDigit > 1 ? " " : "";
  let inWords = convertTens(tenDigit, unitDigit) + add;

  if (tenDigit !== 1) {
    inWords = inWords + convertUnitAndHundred(unitDigit);
  }

  if (hundredDigit === 0) {
    return inWords;
  }

  return (convertUnitAndHundred(hundredDigit) + " hundred " + inWords).trim();
}

function giveDigit(num) {
  return num % 10;
}

function removeDigit(num, digit) {
  return (num - digit) / 10;
}

function convertToWords(number) {
  let inWords = "";
  let num = number;

  if (number > 0) {
    const unitDigit = giveDigit(num);
    num = removeDigit(num, unitDigit);
    const tenDigit = giveDigit(num);
    num = removeDigit(num, tenDigit);
    const hundredDigit = giveDigit(num);

    inWords = giveInWords(unitDigit, tenDigit, hundredDigit);
  }

  return inWords;
}

function givePlaceValue(count) {
  const words = ["", "thousand", "million", "billion"];

  return words[count];
}

function addPlaceValue(count, inWords, digits) {
  if (digits > 0) {
    return " " + givePlaceValue(count) + " " + inWords;
  }

  return "" + inWords;
}

function numberToWords(num) {
  let number = num;
  let inWords = "";
  let count = 0;

  while (number > 0) {
    const digits = number % 1000;

    inWords = convertToWords(digits) + addPlaceValue(count, inWords, digits);
    number = (number - digits) / 1000;
    count = count + 1;
  }

  return inWords.trim() === "" ? "zero" : inWords.trim();
}

function makeMessage(number, expected, actual) {
  let message = "the number is: '" + number;

  message = message + "' are '" + expected;
  message = message + "' and it is '" + actual + "'";

  return message;
}

function testNumberToWords(number, expected) {
  const actual = numberToWords(number);
  const getMark = actual === expected ? '✅' : '❌';

  console.log(getMark + makeMessage(number, expected, actual));
}

function testAll() {
  testNumberToWords(0, "zero");
  testNumberToWords(1, "one");
  testNumberToWords(11, "eleven");
  testNumberToWords(22, "twenty two");
  testNumberToWords(123, "one hundred twenty three");
  testNumberToWords(4123, "four thousand one hundred twenty three");
  testNumberToWords(54123, "fifty four thousand one hundred twenty three");
  testNumberToWords(654123, "six hundred fifty four thousand one hundred" + " twenty three");
  testNumberToWords(7654123, "seven million six hundred fifty four thousand" + " one hundred twenty three");
  testNumberToWords(67654123, "sixty seven million six hundred fifty four" + " thousand one hundred twenty three");
  testNumberToWords(897654123, "eight hundred ninety seven million six hundred" + " fifty four thousand one hundred twenty three");
  testNumberToWords(9067654123, "nine billion sixty seven million six hundred" + " fifty four thousand one hundred twenty three");
  testNumberToWords(19067654123, "nineteen billion sixty seven million six" + " hundred fifty four thousand one hundred twenty three");
  testNumberToWords(321897654123, "three hundred twenty one billion eight" + " hundred ninety seven million six hundred fifty four thousand one hundred" + " twenty three");
  testNumberToWords(311, "three hundred eleven");
  testNumberToWords(118, "one hundred eighteen");
  testNumberToWords(110, "one hundred ten");
  testNumberToWords(10, "ten");
  testNumberToWords(100, "one hundred");
  testNumberToWords(1000, "one thousand");
  testNumberToWords(10000, "ten thousand");
  testNumberToWords(100000, "one hundred thousand");
  testNumberToWords(1000000, "one million");
  testNumberToWords(1000001, "one million one");
  testNumberToWords(10000001, "ten million one");
  testNumberToWords(100000001, "one hundred million one");
  testNumberToWords(1000000001, "one billion one");
  testNumberToWords(10000000001, "ten billion one");
  testNumberToWords(100000000001, "one hundred billion one");
  testNumberToWords(10000000, "ten million");
  testNumberToWords(100000000, "one hundred million");
  testNumberToWords(1000000000, "one billion");
  testNumberToWords(10000000000, "ten billion");
  testNumberToWords(100000000000, "one hundred billion");
  testNumberToWords(999999999999, "nine hundred ninety nine billion nine" + 
    " hundred ninety nine million nine hundred ninety nine thousand nine" + 
    " hundred ninety nine");
}

testAll();