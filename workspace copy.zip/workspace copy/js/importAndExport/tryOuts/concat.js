const sub = (a, b) => a - b;
const add = (a, b) => a + b;
const mul = (a, b) => a * b;
const div = (a, b) => a / b;

export const allOperations = { add, sub, mul, div };


const test = function () {
  export const anothernumber = 10;
  return (number) => number + anothernumber;
};

export const incrementBy10 = test();