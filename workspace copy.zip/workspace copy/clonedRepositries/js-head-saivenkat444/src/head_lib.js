import { fetchContent } from "./fetch_content.js";

export const head = (parsedArgs) => {
  if (parsedArgs.isError) {
    return [parsedArgs];
  }

  const { filepaths, option, count } = parsedArgs;
  const contents = filepaths.map((filePath) =>
    fetchContent(option, count, filePath)
  );

  return contents;
};
